﻿using Azure.Core;
using PeirLoanSystem.Core.Security;
using PeirLoanSystem.Data;
using PeirLoanSystem.Data.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System.Net.Mail;
using PeirLoanSystem.Data.ViewModels;

namespace PeirLoanSystem.Api.Controllers
{
    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IUnitOfWork _unitOfWork;

        public AuthController(IConfiguration configuration, IUnitOfWork unitOfWork)
        {
            _configuration = configuration;
            _unitOfWork = unitOfWork;
        }

        [HttpPost]
        [Route("validate")]
        public async Task<IActionResult> ValidateAsync(LoginRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var jwtIssuer = _configuration["Jwt:Issuer"] ?? "";
                var jwtKey = _configuration["Jwt:Key"] ?? "";

                var jwtCredentials = new JwtCred { JwtIssuer = jwtIssuer, JwtKey = jwtKey };
                var sessionMinutes = string.IsNullOrEmpty(_configuration["AppSettings:SessionMinutes"]) ? 30 : int.Parse(_configuration["AppSettings:SessionMinutes"]);

                var response = await _unitOfWork.Users.ValidateAsync(request, sessionMinutes);
                if (response == null)
                {
                    return BadRequest($"User: {request.UserName} not found");
                }

                return Ok(response);
            }
            catch (Exception ex)
            {

                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet]
        [Route("otp-info/{vtoken}")]
        public async Task<IActionResult> GetOtpInfoAsync(string vtoken)
        {
            var otpInfo = await _unitOfWork.Users.GetSessionOtpVerifyAsync(vtoken);
            if (otpInfo == null)
            {
                return BadRequest("User Session details not found");
            }

            return Ok(otpInfo);
        }


        [HttpGet]
        [Route("unlock-user/{userId}")]
        public async Task<IActionResult> UnlockUser(Guid userId)
        {
            var result = await _unitOfWork.Users.UnlockUser(userId);

            return Ok(result);
        }

        [HttpGet]
        [Route("generate-captcha")]
        public async Task<IActionResult> GetInitialCaptcha()
        {
            var result = await _unitOfWork.Users.GenerateCaptcha();

            return Ok(result);
        }

        [HttpGet]
        [Route("refresh-captcha/{id}")]
        public async Task<IActionResult> RefreshCaptcha(Guid id)
        {
            var result = await _unitOfWork.Users.ReGenerateCaptcha(id);

            return Ok(result);
        }

        [HttpGet]
        [Route("logOut")]
        public async Task<IActionResult> LogOut()
        {
            var authHeaderValues = HttpContext.Request.Headers["Authorization"];
            var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
            var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
            var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);

            var result = await _unitOfWork.Users.LogOut(userId, jwtToken);

            return Ok(result);
        }


        [HttpGet]
        [Route("allow-user-login/{userId}")]
        public async Task<IActionResult> AllowUserLogin(Guid userId)
        {

            var sessionMinutes = string.IsNullOrEmpty(_configuration["AppSettings:SessionMinutes"]) ? 30 : int.Parse(_configuration["AppSettings:SessionMinutes"]);
            var response = await _unitOfWork.Users.AllowUserLogin(userId, sessionMinutes);

            return Ok(response);
        }

        [HttpPost]
        [Route("verify")]
        public async Task<IActionResult> VerifyAsync(VerificationRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            try
            {
                if (_configuration == null)
                {
                    throw new ArgumentNullException($"JWT Credentials not set");
                }

                var jwtIssuer = _configuration["Jwt:Issuer"] ?? "";
                var jwtKey = _configuration["Jwt:Key"] ?? "";

                var jwtCredentials = new JwtCred { JwtIssuer = jwtIssuer, JwtKey = jwtKey };
                var tokenValidHours = string.IsNullOrEmpty(_configuration["AppSettings:TokenValidHours"]) ? 6 : int.Parse(_configuration["AppSettings:TokenValidHours"]);
                var verifyResponse = await _unitOfWork.Users.VerifyAsync(request, jwtCredentials, tokenValidHours).ConfigureAwait(false);
                if (verifyResponse == null)
                {
                    return BadRequest(string.Format("Invalid OTP", request.VerifyToken));
                }

                return Ok(verifyResponse);
            }
            catch (Exception)
            {

                throw;
            }
        }

        [HttpPost]
        [Route("verify-otp")]
        public async Task<IActionResult> VerifyOTPAsync(VerificationRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            try
            {
                if (_configuration == null)
                {
                    throw new ArgumentNullException($"JWT Credentials not set");
                }

                var jwtIssuer = _configuration["Jwt:Issuer"] ?? "";
                var jwtKey = _configuration["Jwt:Key"] ?? "";

                var jwtCredentials = new JwtCred { JwtIssuer = jwtIssuer, JwtKey = jwtKey };
                var tokenValidHours = string.IsNullOrEmpty(_configuration["AppSettings:TokenValidHours"]) ? 6 : int.Parse(_configuration["AppSettings:TokenValidHours"]);
                var verifyResponse = await _unitOfWork.Users.VerifyOTPAsync(request, jwtCredentials, tokenValidHours).ConfigureAwait(false);

                if (verifyResponse == null)
                {
                    return BadRequest(string.Format("Invalid OTP", request.VerifyToken));
                }

                return Ok(verifyResponse);
            }
            catch (Exception)
            {

                throw;
            }
        }

        [HttpPost]
        [Route("resend-otp")]
        public async Task<IActionResult> ResendOTPAsync(ResendOTPRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            try
            {
                var otpResponse = await _unitOfWork.Users.ResendOTPAsync(request.VerifyToken).ConfigureAwait(false);
                if (otpResponse == null)
                {
                    return BadRequest(string.Format("Failed to send OTP", request.VerifyToken));
                }

                return Ok(otpResponse);
            }
            catch (Exception)
            {

                throw;
            }
        }

        [HttpPost]
        [Route("forgot-password")]
        public async Task<IActionResult> ForgotPaswordAsync(UserNameRequest request)
        {
            var user = await _unitOfWork.Users.UserByUserNameAsync(request);
            if (user == null)
            {
                return BadRequest("User Not Found");
            }
            try
            {

                var sessionMinutes = string.IsNullOrEmpty(_configuration["AppSettings:SessionMinutes"]) ? 30 : int.Parse(_configuration["AppSettings:SessionMinutes"]);
                var existingSession = await _unitOfWork.Users.HasAnySession(user.Id, sessionMinutes).ConfigureAwait(false);
                if (existingSession == null)
                {
                    return BadRequest("");
                }

                if (user.Mobile != "" || user.Mobile != null)
                {
                    var otpInfo = await _unitOfWork.Users.UserOtpCreationAsync(user.Id);

                    if (otpInfo == null)
                    {
                        return BadRequest("User Session details not found");
                    }

                    return Ok(otpInfo);
                }
                else
                {
                    return BadRequest(string.Format("User {0} have no mobile no.", user.UserName));
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }


        [HttpPost]
        [Route("reset-password")]
        public async Task<IActionResult> ResetPasswordAsync(ResetPassword resetPassword)
        {
            try
            {
                //var authHeaderValues = HttpContext.Request.Headers["Authorization"];
                //var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
                //var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
                //var userType = JwtParser.GetUserType(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);
                //var referenceId = JwtParser.GetUserMappingId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);
                //var roleAlias = JwtParser.GetRoleAlias(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);
                //var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);

                //resetPassword.UserId = userId;
                var result = await _unitOfWork.Users.ResetPasswordAsync(resetPassword);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Route("change-password")]
        public async Task<IActionResult> ChangePasswordAsync(ChangePassword model)
        {
            try
            {
                var authHeaderValues = HttpContext.Request.Headers["Authorization"];
                var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
                var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
                var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);

                var result = await _unitOfWork.Users.ChangePasswordAsync(model, userId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
