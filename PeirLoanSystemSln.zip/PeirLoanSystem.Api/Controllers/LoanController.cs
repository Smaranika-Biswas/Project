﻿
using PeirLoanSystem.Data;
using PeirLoanSystem.Data.Models;
using PeirLoanSystem.Core.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PeirLoanSystem.Data.ViewModels;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;
using System.Net;
using AutoWrapper.Filters;

namespace PeirLoanSystem.Api.Controllers
{
    [Route("api/loan")]
    [ApiController]
   // [Authorize]
    public class LoanController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IHostingEnvironment _environment;
        public LoanController(IConfiguration configuration, IUnitOfWork unitOfWork, IHostingEnvironment environment)
        {
            _configuration = configuration;
            _unitOfWork = unitOfWork;
            _environment = environment;
        }

        [HttpPost]
        [Route("create")]
        public async Task<IActionResult> Create([FromForm] Loan model)
        {
            if (model == null)
            {
                return BadRequest();
            }

            //TimeZoneInfo tzi = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");

            //model.DisbursedDate = TimeZoneInfo.ConvertTimeFromUtc(model.DisbursedDate, tzi);

            var authHeaderValues = HttpContext.Request.Headers["Authorization"];
            var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
            var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
            var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);

            var baseUploadPath = Path.Combine(_environment.WebRootPath, "resources", "Loan");

            var files = Request.Form.Files;

             
            if(files != null && files.Any())
            {
                foreach(var file in files)
                {
                    if(file.Length > 0)
                    {
                        var fileName = file.FileName.Trim();
                        var fileExtension = fileName.Substring(fileName.IndexOf('.'));
                        var fileSequence = fileName.Replace(fileExtension, "_" + DateTime.Now.Ticks.ToString() + fileExtension);
                        var fullPath = Path.Combine(baseUploadPath, fileSequence);

                        if (!Directory.Exists(baseUploadPath))
                        {
                            Directory.CreateDirectory(baseUploadPath);
                        }
                        using (var stream = new FileStream(fullPath, FileMode.Create))
                        {
                            file.CopyTo(stream);
                        }

                        if(model.Documents != null && model.Documents.Count != 0)
                        {
                            var docModel = model.Documents.FirstOrDefault(m => !string.IsNullOrEmpty(m.DocFileName) && m.DocFileName.Trim() == fileName);
                            if(docModel != null)
                            {
                                docModel.DocFileSeq = fileSequence.Trim();
                                docModel.DocFileName = fileName;
                            }
                        }

                    }
                }
            }

            try
            {
                var result = await _unitOfWork.Loan.CreateAsync(model, userId).ConfigureAwait(false);
                return StatusCode(StatusCodes.Status201Created, result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet]
        [Route("getById/{id}")]
        public async Task<IActionResult> Get(Guid id)
        {
            try
            {
                var result = await _unitOfWork.Loan.GetAsync(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet]
        [Route("getByPaymentId/{id}")]
        public async Task<IActionResult> GetByPaymentId(Guid id)
        {
            try
            {
                var result = await _unitOfWork.Loan.GetPaymentById(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet]
        [Route("getAmmortizationSchedule/{id}")]
        public async Task<IActionResult> GetSchedule(Guid id)
        {
            try
            {
                var result = await _unitOfWork.Loan.GenerateAmmoritizationSchedule(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet]
        [Route("deleteDoc/{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            try
            {
                var result = await _unitOfWork.Loan.DeleteDocument(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }

           
        }

        [HttpGet]
        [Route("getAllPaymentByLoan/{id}")]
        public async Task<IActionResult> GetAllPayments(Guid id)
        {

            var result = await _unitOfWork.Loan.GetAllPaymentByLoan(id);
            return Ok(result);
        }


        [HttpPost]
        [Route("update")]
        public async Task<IActionResult> UpdateAsync([FromForm]Loan model)
        {
            try
            {
                var authHeaderValues = HttpContext.Request.Headers["Authorization"];
                var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
                var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
                var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);
                var baseUploadPath = Path.Combine(_environment.WebRootPath, "resources", "Loan");

                var files = Request.Form.Files;

                if (files != null && files.Any())
                {
                    foreach (var file in files)
                    {
                        if (file.Length > 0)
                        {
                            var fileName = file.FileName.Trim();
                            var fileExtension = fileName.Substring(fileName.IndexOf('.'));
                            var fileSequence = fileName.Replace(fileExtension, "_" + DateTime.Now.Ticks.ToString() + fileExtension);
                            var fullPath = Path.Combine(baseUploadPath, fileSequence);

                            if (!Directory.Exists(baseUploadPath))
                            {
                                Directory.CreateDirectory(baseUploadPath);
                            }
                            using (var stream = new FileStream(fullPath, FileMode.Create))
                            {
                                file.CopyTo(stream);
                            }

                            if (model.Documents != null && model.Documents.Count != 0)
                            {
                                var docModel = model.Documents.FirstOrDefault(m => !string.IsNullOrEmpty(m.DocFileName) && m.DocFileName.Trim() == fileName);
                                if (docModel != null)
                                {
                                    docModel.DocFileSeq = fileSequence.Trim();
                                    docModel.DocFileName = fileName;
                                }
                            }

                        }
                    }
                }

                var result = await _unitOfWork.Loan.UpdateAsync(model, userId).ConfigureAwait(false);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Route("filter")]
        public async Task<IActionResult> Filter(LoanFilterParam param)
        {
            try
            {
                var authHeaderValues = HttpContext.Request.Headers["Authorization"];
                var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
                var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
                var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);
          
                var results = await _unitOfWork.Loan.FilterAsync(param, userId).ConfigureAwait(false);


                return Ok(results);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Route("calculate-interest")]
        public async Task<IActionResult> CalculateInterest(InterestModel param)
        {
            try
            {              
                var results = await _unitOfWork.Loan.CalculateInterest(param).ConfigureAwait(false);
                return Ok(results);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Route("add-payment")]
        public async Task<IActionResult> AddPayment([FromForm] Payment model)
        {
            if (model == null)
            {
                return BadRequest();
            }

            var authHeaderValues = HttpContext.Request.Headers["Authorization"];
            var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
            var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
            var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);

            var baseUploadPath = Path.Combine(_environment.WebRootPath, "resources", "Loan");

            var files = Request.Form.Files;


            if (files != null && files.Any())
            {
                var file = files[0];
                if (file.Length > 0)
                {
                    var fileName = file.FileName.Trim();
                    var fileExtension = fileName.Substring(fileName.IndexOf('.'));
                    var fileSequence = fileName.Replace(fileExtension, "_" + DateTime.Now.Ticks.ToString() + fileExtension);
                    var fullPath = Path.Combine(baseUploadPath, fileSequence);

                    if (!Directory.Exists(baseUploadPath))
                    {
                        Directory.CreateDirectory(baseUploadPath);
                    }
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }

                    model.ChallanFileNo = fileSequence.Trim();
                    model.ChallanFileName = fileName;

                }
            }

            try
            {
                var result = await _unitOfWork.Loan.ReceivePayment(model, userId, Path.Combine(_environment.WebRootPath, "resources", "EmailHtml")).ConfigureAwait(false);
                return StatusCode(StatusCodes.Status201Created, result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Route("update-payment")]
        public async Task<IActionResult> UpdatePayment([FromForm] Payment model)
        {
            if (model == null)
            {
                return BadRequest();
            }

            var authHeaderValues = HttpContext.Request.Headers["Authorization"];
            var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
            var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
            var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);

            var baseUploadPath = Path.Combine(_environment.WebRootPath, "resources", "Loan");

            var files = Request.Form.Files;


            if (files != null && files.Any())
            {
                var file = files[0];
                if (file.Length > 0)
                {
                    var fileName = file.FileName.Trim();
                    var fileExtension = fileName.Substring(fileName.IndexOf('.'));
                    var fileSequence = fileName.Replace(fileExtension, "_" + DateTime.Now.Ticks.ToString() + fileExtension);
                    var fullPath = Path.Combine(baseUploadPath, fileSequence);

                    if (!Directory.Exists(baseUploadPath))
                    {
                        Directory.CreateDirectory(baseUploadPath);
                    }
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }

                    model.ChallanFileNo = fileSequence.Trim();
                    model.ChallanFileName = fileName;

                }
            }

            try
            {
                var result = await _unitOfWork.Loan.UpdatePayment(model, userId).ConfigureAwait(false);
                return StatusCode(StatusCodes.Status201Created, result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Route("filter-payment")]
        public async Task<IActionResult> FilterPayment(PaymentFilterParam param)
        {
            try
            {
                var authHeaderValues = HttpContext.Request.Headers["Authorization"];
                var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
                var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
                var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);

                var results = await _unitOfWork.Loan.FilterPaymentAsync(param, userId).ConfigureAwait(false);


                return Ok(results);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Route("payment-note")]
        public async Task<IActionResult> AddPaymentNote(ValidatePayment model)
        {
            try
            {
                var authHeaderValues = HttpContext.Request.Headers["Authorization"];
                var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
                var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
                var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);

                var results = await _unitOfWork.Loan.ValidatePayment(model, userId, Path.Combine(_environment.WebRootPath, "resources", "EmailHtml")).ConfigureAwait(false);

                return Ok(results);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Route("update-status")]
        public async Task<IActionResult> UpdateStatus(LoanStatusUpdate model)
        {
            try
            {
                var authHeaderValues = HttpContext.Request.Headers["Authorization"];
                var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
                var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
                var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);

                var results = await _unitOfWork.Loan.UpdateLoanStatus(model, userId).ConfigureAwait(false);

                return Ok(results);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet]
        [AutoWrapIgnore]
        [Route("getLoanAccountStatement/{id}")]
        public async Task<Stream> GetAllLoanAccountStatement(Guid id)
        {
            try
            {               
                var credCache = new CredentialCache
                {
                    { new Uri(_configuration["ReportServer:Host"]), "NTLM", new NetworkCredential(_configuration["ReportServer:UserId"], _configuration["ReportServer:Password"], _configuration["ReportServer:Domain"]) }
                };

                var ssrsClient = new HttpClient(new HttpClientHandler { Credentials = credCache, AllowAutoRedirect = true, AutomaticDecompression = DecompressionMethods.Deflate, PreAuthenticate = true });
                Stream fileStream = await ssrsClient.GetStreamAsync(new Uri(_configuration["ReportServer:Host"] + "?/" + _configuration["ReportServer:Folder"] + "/Rpt_LoanDetails&LoaneeId=" + id + "&rs:command=render&rs:format=PDF"));

                return fileStream;
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpPost]
        [Route("update-accounthead")]
        public async Task<IActionResult> UpdateAccountHead(ChangeAccountHead model)
        {
            try
            {
                var authHeaderValues = HttpContext.Request.Headers["Authorization"];
                var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
                var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
                var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);

                var results = await _unitOfWork.Loan.UpdateAccountHead(model, userId).ConfigureAwait(false);

                return Ok(results);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
