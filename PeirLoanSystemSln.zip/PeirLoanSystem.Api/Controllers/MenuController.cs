﻿using Microsoft.AspNetCore.Mvc;
using PeirLoanSystem.Data.Models;
using PeirLoanSystem.Data.Repositories;
using System.Net;
using PeirLoanSystem.Core.Security;
using PeirLoanSystem.Data;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PeirLoanSystem.Api.Controllers
{


    [Route("api/menus")]
    [ApiController]
    public class MenuController : ControllerBase
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMenuService _menuService;
        private readonly IConfiguration _configuration;
        public MenuController(IUnitOfWork unitOfWork, IMenuService menuService, IConfiguration configuration)
        {
            _unitOfWork = unitOfWork;
            _menuService = menuService;
            _configuration = configuration;
        }

        [HttpGet]
        [Route("getAllMenus")]
        public async Task<IActionResult> GetAll()
        {
            var result = await _menuService.GetAllAsync().ConfigureAwait(false);
            return Ok(result);
        }

        [HttpGet]
        [Route("get-auth-menu")]

        public async Task<IActionResult> GetAuthorizedMenu()
        {
            var jwtToken = HttpContext.Request.Headers["Authorization"].First()[7..];
            var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);

            try
            {
                var result = await _menuService.GetAuthorizedUserMenu(userId).ConfigureAwait(false);
                return new JsonResult(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("getById/{id}")]
        public async Task<IActionResult> GetById(Guid id)
        {
            try
            {
                var result = await _menuService.GetByIdAsync(id).ConfigureAwait(false);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet]
        [Route("getAllParentMenu")]
        public async Task<IActionResult> GetAllParentMenu()
        {
            var result = await _menuService.GetAllParentMenuAsync().ConfigureAwait(false);
            return Ok(result);
        }

        //[HttpGet]
        //[Route("getAllMenuWithPermission/{roleId}/{userId}")]
        //public async Task<IActionResult> GetAllMenuWithPermission(Guid roleId, Guid userId)
        //{
        //    var result = await _menuService.GetAllMenuWithPermission(roleId, userId).ConfigureAwait(false);
        //    return Ok(result);
        //}

        [HttpPost]
        [Route("filter")]
        public async Task<IActionResult> Filter(MenuFilterParam param)
        {
            try
            {

                var roles = await _menuService.FilterAsync(param).ConfigureAwait(false);
                return Ok(roles);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Route("create")]
        public async Task<IActionResult> Create(Menu model)
        {
            if (model == null)
            {
                return BadRequest();
            }

            try
            {
                var jwtToken = HttpContext.Request.Headers["Authorization"].First()[7..];
                var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);

                var result = await _menuService.CreateAsync(model, userId).ConfigureAwait(false);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Route("update")]
        public async Task<IActionResult> Update(Menu model)
        {
            try
            {

                var result = await _menuService.UpdateAsync(model).ConfigureAwait(false);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
        [HttpGet]
        [Route("getPermissionTokens/{menuPath}")]
        public async Task<IActionResult> GetAllMenuWithPermission(string menuPath)
        {
            var jwtToken = HttpContext.Request.Headers["Authorization"].First()[7..];
            var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);

            var menus = await _menuService.GetPermissionTokens(userId, WebUtility.UrlDecode(menuPath)).ConfigureAwait(false);

            return Ok(menus);
        }

        [HttpGet]
        [Route("getallheader")]
        public async Task<IActionResult> GetAllHearderPermission()
        {
            var jwtToken = HttpContext.Request.Headers["Authorization"].First()[7..];
            var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);

            var menus = await _menuService.GetHeaderPermission().ConfigureAwait(false);

            return Ok(menus);
        }


        [HttpPost]
        [Route("save-role-menu-permission")]
        public async Task<IActionResult> SaveRoleMenuPermission(RoleUserMenuPermission model)
        {
            try
            {
                var result = await _menuService.SaveRoleMenuPermission(model);
                return new JsonResult(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("save-menu-user-permission")]
        public async Task<IActionResult> SaveUserMenuPermission(RoleUserMenuPermission model)
        {
            try
            {
                var result = await _menuService.SaveUserMenuPermission(model);
                return new JsonResult(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }






        #region ROLE SECTION


        [HttpGet]
        [Route("all-role")]
        public async Task<IActionResult> GetAllRole()
        {
            var result = await _menuService.GetAllRoleAsync();
            return new JsonResult(result);
        }

        [HttpGet]
        [Route("get-role/{id}")]
        public async Task<IActionResult> GetRoleById(Guid id)
        {
            var result = await _unitOfWork.MenuService.GetRoleByIdAsync(id);
            return new JsonResult(result);
        }

        [HttpGet]
        [Route("get-user-by-role/{id}")]
        public async Task<IActionResult> GetUserByRole(Guid id)
        {
            var result = await _unitOfWork.MenuService.GetUserByRoleIdAsync(id);
            return new JsonResult(result);
        }

        [HttpPost]
        [Route("create-role")]
        public async Task<IActionResult> CreateRole(Role model)
        {
            if (model == null)
            {
                return BadRequest();
            }
            try
            {
                var result = await _unitOfWork.MenuService.CreateRoleAsync(model).ConfigureAwait(false);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }



        [HttpPut]
        [Route("update-role/{id}")]
        public async Task<IActionResult> UpdateRole(Guid id, Role model)
        {
            try
            {
                var role = await _unitOfWork.MenuService.GetRoleByIdAsync(id).ConfigureAwait(false);
                if (role == null)
                {
                    return NotFound();
                }
                var result = await _unitOfWork.MenuService.UpdateRoleAsync(id, model).ConfigureAwait(false);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }


        [HttpGet]
        [Route("get-role-menu-permission/{menuId}")]
        public async Task<IActionResult> Getpermission(Guid menuId)
        {
            var result = await _unitOfWork.MenuService.Get(menuId);
            return new JsonResult(result);
        }

        [HttpGet]
        [Route("allMenuWithPermission/{roleId}/{userId}")]
        public async Task<MenuPermissionModel> GetAllMenuWithPermission(Guid roleId, Guid userId) => await _unitOfWork.MenuService.GetAllMenuWithPermission(roleId, userId).ConfigureAwait(false);


        [HttpPost]
        [Route("update-role-menu-permission")]
        public async Task<IActionResult> UpdateRoleMenuPermissionToken(RoleWiseMenuPermissionCheckBox model)
        {
            try
            {
                var result = await _unitOfWork.MenuService.UpdateRoleMenuPermissionToken(model);
                return new JsonResult(result);
            }
            catch (Exception ex)
            {

                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("update-user-menu-permission")]
        public async Task<IActionResult> UpdateUserMenuPermissionToken(RoleWiseMenuPermissionCheckBox model)
        {
            var authHeaderValues = HttpContext.Request.Headers["Authorization"];
            var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
            var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
            var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);


            try
            {
                var result = await _unitOfWork.MenuService.UpdateUserMenuPermissionToken(model, userId);
                return new JsonResult(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }


        #endregion
    }

}
