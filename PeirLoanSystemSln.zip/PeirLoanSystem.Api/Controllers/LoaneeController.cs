﻿
using PeirLoanSystem.Data;
using PeirLoanSystem.Data.Models;
using PeirLoanSystem.Core.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PeirLoanSystem.Data.ViewModels;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;

namespace PeirLoanSystem.Api.Controllers
{
    [Route("api/loanee")]
    [ApiController]
    [Authorize]
    public class LoaneeController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IHostingEnvironment _environment;
        public LoaneeController(IConfiguration configuration, IUnitOfWork unitOfWork, IHostingEnvironment environment)
        {
            _configuration = configuration;
            _unitOfWork = unitOfWork;
            _environment = environment;
        }

        [HttpPost]
        [Route("create")]
        public async Task<IActionResult> Create([FromForm] Loanee model)
        {
            if (model == null)
            {
                return BadRequest();
            }

            var authHeaderValues = HttpContext.Request.Headers["Authorization"];
            var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
            var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
            var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);

            var baseUploadPath = Path.Combine(_environment.WebRootPath, "resources", "Loanee");

            var files = Request.Form.Files;

             
            if(files != null && files.Any())
            {
                foreach(var file in files)
                {
                    if(file.Length > 0)
                    {
                        var fileName = file.FileName.Trim();
                        var fileExtension = fileName.Substring(fileName.IndexOf('.'));
                        var fileSequence = fileName.Replace(fileExtension, "_" + DateTime.Now.Ticks.ToString() + fileExtension);
                        var fullPath = Path.Combine(baseUploadPath, fileSequence);

                        if (!Directory.Exists(baseUploadPath))
                        {
                            Directory.CreateDirectory(baseUploadPath);
                        }
                        using (var stream = new FileStream(fullPath, FileMode.Create))
                        {
                            file.CopyTo(stream);
                        }

                        if(model.Documents != null && model.Documents.Count != 0)
                        {
                            var docModel = model.Documents.FirstOrDefault(m => !string.IsNullOrEmpty(m.DocFileName) && m.DocFileName.Trim() == fileName);
                            if(docModel != null)
                            {
                                docModel.DocFileSeq = fileSequence.Trim();
                                docModel.DocFileName = fileName;
                            }
                        }

                    }
                }
            }

            try
            {
                var result = await _unitOfWork.Loanee.CreateAsync(model, userId).ConfigureAwait(false);
                return StatusCode(StatusCodes.Status201Created, result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet]
        [Route("deleteDirector/{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            try
            {
                var result = await _unitOfWork.Loanee.DeleteDirector(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }


        }

        [HttpGet]
        [Route("getById/{id}")]
        public async Task<IActionResult> Get(Guid id)
        {
            try
            {
                var result = await _unitOfWork.Loanee.GetAsync(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
            
        }

        [HttpGet]
        [Route("getCompanyProfile")]
        public async Task<IActionResult> GetCompanyProfile()
        {
            try
            {
                var authHeaderValues = HttpContext.Request.Headers["Authorization"];
                var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
                var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
                var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);

                var result = await _unitOfWork.Loanee.GetCompanyProfile(userId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }

        }

        [HttpGet]
        [Route("getAllLoanee")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var result = await _unitOfWork.Loanee.GetAllAsync();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
          
        }


        [HttpPost]
        [Route("update")]
        public async Task<IActionResult> UpdateAsync([FromForm] Loanee model)
        {
            try
            {
                var authHeaderValues = HttpContext.Request.Headers["Authorization"];
                var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
                var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
                var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);

                var baseUploadPath = Path.Combine(_environment.WebRootPath, "resources", "Loanee");

                var files = Request.Form.Files;


                if (files != null && files.Any())
                {
                    foreach (var file in files)
                    {
                        if (file.Length > 0)
                        {
                            var fileName = file.FileName.Trim();
                            var fileExtension = fileName.Substring(fileName.IndexOf('.'));
                            var fileSequence = fileName.Replace(fileExtension, "_" + DateTime.Now.Ticks.ToString() + fileExtension);
                            var fullPath = Path.Combine(baseUploadPath, fileSequence);

                            if (!Directory.Exists(baseUploadPath))
                            {
                                Directory.CreateDirectory(baseUploadPath);
                            }
                            using (var stream = new FileStream(fullPath, FileMode.Create))
                            {
                                file.CopyTo(stream);
                            }

                            if (model.Documents != null && model.Documents.Count != 0)
                            {
                                var docModel = model.Documents.FirstOrDefault(m => !string.IsNullOrEmpty(m.DocFileName) && m.DocFileName.Trim() == fileName);
                                if (docModel != null)
                                {
                                    docModel.DocFileSeq = fileSequence.Trim();
                                    docModel.DocFileName = fileName;
                                }
                            }

                        }
                    }
                }
                var result = await _unitOfWork.Loanee.UpdateAsync(model, userId).ConfigureAwait(false);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Route("filter")]
        public async Task<IActionResult> Filter(LoaneeFilterParam param)
        {
            try
            {
                var authHeaderValues = HttpContext.Request.Headers["Authorization"];
                var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
                var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
                var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);
          
                var results = await _unitOfWork.Loanee.FilterAsync(param, userId).ConfigureAwait(false);


                return Ok(results);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
