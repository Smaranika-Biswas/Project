﻿
using PeirLoanSystem.Data;
using PeirLoanSystem.Data.Models;
using PeirLoanSystem.Core.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PeirLoanSystem.Data.ViewModels;

namespace PeirLoanSystem.Api.Controllers
{
    [Route("api/dashBoard")]
    [ApiController]
    [Authorize]
    public class DashboardController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IUnitOfWork _unitOfWork;

        public DashboardController(IConfiguration configuration, IUnitOfWork unitOfWork)
        {
            _configuration = configuration;
            _unitOfWork = unitOfWork;
        }

        [HttpGet]
        [Route("get")]
        public async Task<IActionResult> Get()
        {
            try
            {
                var authHeaderValues = HttpContext.Request.Headers["Authorization"];
                var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
                var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
                var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);
                var result = await _unitOfWork.Dashboard.GetDashboard(userId);

                return Ok(result);
            }
            catch(Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
               
        }
    }
}
