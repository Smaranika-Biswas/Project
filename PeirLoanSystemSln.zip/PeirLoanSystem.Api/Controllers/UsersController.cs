﻿
using PeirLoanSystem.Data;
using PeirLoanSystem.Data.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PeirLoanSystem.Core.Security;
using PeirLoanSystem.Data.ViewModels;

namespace PeirLoanSystem.Api.Controllers
{
    [Route("api/users")]
    [ApiController]
    [Authorize]
   
    public class UsersController : ControllerBase
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IConfiguration _configuration;
        public UsersController(IUnitOfWork unitOfWork, IConfiguration configuration)
        {
            _unitOfWork = unitOfWork;
            _configuration = configuration;
        }

        #region USER SECTION

        [HttpGet]
        [Route("all-user")]
        public async Task<IActionResult> GetAllUser()
        {
            var tokenValidHours = !string.IsNullOrEmpty(_configuration["AppSettings:TokenValidHours"]) ? 6 : int.Parse(_configuration["AppSettings:TokenValidHours"]);
            var result = await _unitOfWork.Users.GetAllUserAsync(tokenValidHours);
            return new JsonResult(result);
        }

        [HttpGet]
        [Route("get-user/{id}")]
        public async Task<IActionResult> GetUserById(Guid id)
        {
            var result = await _unitOfWork.Users.GetUserByIdAsync(id);
            return new JsonResult(result);
        }

        [HttpPost]
        [Route("create-user")]
        public async Task<IActionResult> CreateUser(User model)
        {
            if (model == null)
            {
                return BadRequest();
            }
            try
            {
                var result = await _unitOfWork.Users.CreateUserAsync(model).ConfigureAwait(false);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPut]
        [Route("update-user/{id}")]
        public async Task<IActionResult> UpdateUser(Guid id, User model)
        {
            try
            {
                var usr = await _unitOfWork.Users.GetUserByIdAsync(id).ConfigureAwait(false);
                if (usr == null)
                {
                    return NotFound();
                }
                var result = await _unitOfWork.Users.UpdateUserAsync(id, model).ConfigureAwait(false);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        [Route("filter")]
        public async Task<IActionResult> Filter(UserFilterParam param)
        {
            try
            {
                var sessionMinutes = !string.IsNullOrEmpty(_configuration["AppSettings:SessionMinutes"]) ? 30 : int.Parse(_configuration["AppSettings:SessionMinutes"]);
                var authHeaderValues = HttpContext.Request.Headers["Authorization"];
                var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
                var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
                var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);


                param.tokenValidHours = sessionMinutes;
                var results = await _unitOfWork.Users.FilterAsync(param).ConfigureAwait(false);


                return Ok(results);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        #endregion


        #region ROLE SECTION


        //[HttpGet]
        //[Route("all-role")]
        //public async Task<IActionResult> GetAllRole()
        //{
        //    var result = await _unitOfWork.Users.GetAllRoleAsync();
        //    return new JsonResult(result);
        //}

        //[HttpGet]
        //[Route("get-role/{id}")]
        //public async Task<IActionResult> GetRoleById(Guid id)
        //{
        //    var result = await _unitOfWork.Users.GetRoleByIdAsync(id);
        //    return new JsonResult(result);
        //}

        //[HttpGet]
        //[Route("get-user-by-role/{id}")]
        //public async Task<IActionResult> GetUserByRole(Guid id)
        //{
        //    var result = await _unitOfWork.Users.GetUserByRoleIdAsync(id);
        //    return new JsonResult(result);
        //}

        //[HttpPost]
        //[Route("create-role")]
        //public async Task<IActionResult> CreateRole(Role model)
        //{
        //    if (model == null)
        //    {
        //        return BadRequest();
        //    }
        //    try
        //    {
        //        var result = await _unitOfWork.Users.CreateRoleAsync(model).ConfigureAwait(false);
        //        return Ok(result);
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, ex.Message);
        //    }
        //}



        //[HttpPut]
        //[Route("update-role/{id}")]
        //public async Task<IActionResult> UpdateRole(Guid id, Role model)
        //{
        //    try
        //    {
        //        var role = await _unitOfWork.Users.GetRoleByIdAsync(id).ConfigureAwait(false);
        //        if (role == null)
        //        {
        //            return NotFound();
        //        }
        //        var result = await _unitOfWork.Users.UpdateRoleAsync(id, model).ConfigureAwait(false);
        //        return Ok(result);
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, ex.Message);
        //    }
        //}


        //[HttpGet]
        //[Route("get-role-menu-permission/{menuId}")]
        //public async Task<IActionResult> Getpermission(Guid menuId)
        //{
        //    var result = await _unitOfWork.Users.Get(menuId);
        //    return new JsonResult(result);
        //}

        //[HttpGet]
        //[Route("allMenuWithPermission/{roleId}/{userId}")]
        //public async Task<MenuPermissionModel> GetAllMenuWithPermission(Guid roleId, Guid userId) => await _unitOfWork.Users.GetAllMenuWithPermission(roleId, userId).ConfigureAwait(false);


        //[HttpPost]
        //[Route("update-role-menu-permission")]
        //public async Task<IActionResult> UpdateRoleMenuPermissionToken(RoleWiseMenuPermissionCheckBox model)
        //{
        //    try
        //    {
        //        var result = await _unitOfWork.Users.UpdateRoleMenuPermissionToken(model);
        //        return new JsonResult(result);
        //    }
        //    catch (Exception ex)
        //    {
               
        //        return StatusCode(500);
        //    }
        //}

        //[HttpPost]
        //[Route("update-user-menu-permission")]
        //public async Task<IActionResult> UpdateUserMenuPermissionToken(RoleWiseMenuPermissionCheckBox model)
        //{
        //    var authHeaderValues = HttpContext.Request.Headers["Authorization"];
        //    var authHeaderValue = authHeaderValues.Any() ? string.IsNullOrEmpty(authHeaderValues.First()) ? "" : authHeaderValues.First() : "";
        //    var jwtToken = string.IsNullOrEmpty(authHeaderValue) ? "" : authHeaderValue[7..];
        //    var userId = JwtParser.GetUserId(jwtToken, _configuration["Jwt:Issuer"], _configuration["Jwt:Key"]);


        //    try
        //    {
        //        var result = await _unitOfWork.Users.UpdateUserMenuPermissionToken(model, userId);
        //        return new JsonResult(result);
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500);
        //    }
        //}


        #endregion
    }
}
