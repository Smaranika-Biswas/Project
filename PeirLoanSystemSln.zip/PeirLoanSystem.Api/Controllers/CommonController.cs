﻿
using PeirLoanSystem.Data;
using PeirLoanSystem.Data.Models;
using PeirLoanSystem.Core.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PeirLoanSystem.Data.ViewModels;

namespace PeirLoanSystem.Api.Controllers
{
    [Route("api/common")]
    [ApiController]
    public class CommonController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IUnitOfWork _unitOfWork;

        public CommonController(IConfiguration configuration, IUnitOfWork unitOfWork)
        {
            _configuration = configuration;
            _unitOfWork = unitOfWork;
        }

    
        [HttpGet]
        [Route("getAllStates")]
        public async Task<IActionResult> GetAllStates()
        {

            var result = await _unitOfWork.Common.GetAllStateAsync();
            return Ok(result);
        }

        [HttpGet]
        [Route("getAllDistricts/{id}")]
        public async Task<IActionResult> GetAllDistricts(Guid id)
        {

            var result = await _unitOfWork.Common.GetAllDistrictAsync(id);
            return Ok(result);
        }

        [HttpGet]
        [Route("getAllDocumentTypes/{category}")]
        public async Task<IActionResult> GetAllDocumentTypes(string category)
        {

            var result = await _unitOfWork.Common.GetAllDocumentTypeAsync(category);
            return Ok(result);
        }
        [HttpGet]
        [Route("getAllSubDocumentTypes/{id}")]
        public async Task<IActionResult> GetAllSubDocumentTypes(Guid id)
        {

            var result = await _unitOfWork.Common.GetAllSubDocumentTypeAsync(id);
            return Ok(result);
        }
      
    }
}
