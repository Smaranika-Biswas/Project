﻿using AutoWrapper;

namespace PeirLoanSystem.Api
{
    public class MapResponseObject
    {
        [AutoWrapperPropertyMap(Prop.Result)]
        public object Data { get; set; } = null!;
    }
}
