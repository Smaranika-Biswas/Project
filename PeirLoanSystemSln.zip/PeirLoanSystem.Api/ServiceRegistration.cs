﻿using PeirLoanSystem.Data.Repositories;
using PeirLoanSystem.Data;
using PeirLoanSystem.Data.Entities;
using Microsoft.EntityFrameworkCore;
using Binds.Repositories.Global;

namespace PeirLoanSystem.Api
{
    public static class ServiceRegistration
    {
        public static void Register(this IServiceCollection services, string dataConnectionString)
        {

            services.AddDbContext<PeirloanDataContext>(options => options.UseSqlServer(dataConnectionString, providerOptions => { providerOptions.CommandTimeout(300); }));

            services.AddTransient<IUserRepository, UserRepository>();
            services.AddTransient<IDashboardRepository, DashboardRepository>();
            services.AddTransient<ILoanRepository, LoanRepository>();
            services.AddTransient<ICommonRepository, CommonRepository>();
            services.AddTransient<ILoaneeRepository, LoaneeRepository>();
            services.AddTransient<IEmailService, EmailService>();
            services.AddTransient<INotificationRepository, NotificationRepository>();
            services.AddTransient<IUnitOfWork, UnitOfWork>();
            services.AddTransient<IMenuService, MenuRepository>();

        }
    }
}
