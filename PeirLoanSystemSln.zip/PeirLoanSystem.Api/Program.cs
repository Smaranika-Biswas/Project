using AutoWrapper;
using PeirLoanSystem.Api;
using Microsoft.Extensions.FileProviders;
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using PeirLoanSystem.Api;

var builder = WebApplication.CreateBuilder(args);

var allowSpecificOrigins = "PeirLoanCors";
// Add services to the container.
var dataConnectionString = builder.Configuration.GetConnectionString("DataConnection") ?? "";
builder.Services.Register(dataConnectionString);

builder.Services.AddCors(options =>
{
    options.AddPolicy(
        name: allowSpecificOrigins,
        builder =>
        {
            builder
                //.WithOrigins("http://localhost:4200")
                .AllowAnyOrigin()
                .AllowAnyHeader()
                .AllowAnyMethod()
                .WithExposedHeaders("Content-Disposition", "X-File-Name");
        });
});

var key = Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]);
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(options =>
{
    options.RequireHttpsMetadata = false;
    options.SaveToken = true;
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(key),
        ValidateIssuer = true,
        ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidateAudience = true,
        ValidAudience = builder.Configuration["Jwt:Issuer"],
        ValidateLifetime = true,
        ClockSkew = TimeSpan.Zero
    };
    options.Events = new JwtBearerEvents
    {
        OnAuthenticationFailed = context =>
        {
            if (context.Exception.GetType() == typeof(SecurityTokenExpiredException))
            {
                context.Response.Headers.Add("Token-Expired", "true");
            }
            return Task.CompletedTask;
        }
    };
});
builder.Services.AddAuthorization();

builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.Converters.Add(new DateTimeConverter());
    });

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

//var storagePath = Path.Combine(builder.Configuration.GetSection("AppSettings")["ResourcesPath"]);
//if (!Directory.Exists(storagePath))
//{
//    Directory.CreateDirectory(storagePath);
//}
//app.UseStaticFiles(new StaticFileOptions
//{
//    RequestPath = "/resources",
//    FileProvider = new PhysicalFileProvider(storagePath)
//});

app.UseStaticFiles();

app.UseCors(allowSpecificOrigins);

app.UseHttpsRedirection();

app.UseApiResponseAndExceptionWrapper<MapResponseObject>(new AutoWrapperOptions { ShowApiVersion = true, ShowStatusCode = true });

app.UseAuthorization();

app.MapControllers();

app.Run();
