﻿
using PeirLoanSystem.Data.Entities;
using PeirLoanSystem.Data.Models;
using PeirLoanSystem.Data.ViewModels;
using Microsoft.EntityFrameworkCore;
using System.Globalization;
using static System.Runtime.InteropServices.JavaScript.JSType;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Text;
using Microsoft.Extensions.Configuration;
using PeirLoanSystem.Data.Repositories;

namespace PeirLoanSystem.Data.Repositories
{
    #region --- Interface : ILoanRepository ---
    public interface INotificationRepository
    {
        Task<FilterResult<Notification>> FilterAsync(NotificationFilterParam filterParam);
        Task<IReadOnlyList<Notification>> GetAllNonReadNotification(Guid UserId);
        Task<bool> MarkNotificationAsSeen(Guid NotificationId, Guid UserId);
    }
    #endregion

    #region --- Class : LoaneeRepository ---
    public class NotificationRepository : INotificationRepository
    {
        public readonly PeirloanDataContext _context;
        private readonly IConfiguration _configuration;
        public NotificationRepository(PeirloanDataContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        public async Task<FilterResult<Notification>> FilterAsync(NotificationFilterParam filterParam)
        {
            try
            {
                if (filterParam == null) return new FilterResult<Notification>();

                var skipCount = (filterParam.PageIndex - 1) * filterParam.PageSize;
                var filterEntitiesQuery = _context.TblNotifications.Include(m => m.TblNotificationUsers).Where(m => m.TblNotificationUsers.Where(a => a.UserId == filterParam.UserId).Any()).AsNoTracking().AsQueryable();

                if (!string.IsNullOrEmpty(filterParam.FilterText))
                {
                    filterEntitiesQuery = filterEntitiesQuery.Where(m => m.Subject.ToLower().Contains(filterParam.FilterText.Trim().ToLower())
                                          || (!string.IsNullOrEmpty(m.Description) && m.Description.ToLower().Contains(filterParam.FilterText.Trim().ToLower())));
                }

                filterEntitiesQuery = (filterParam.SortOn.ToUpper()) switch
                {
                    _ => filterParam.SortDirection.ToUpper() == "DESC" ? filterEntitiesQuery.OrderByDescending(m => m.NotificationDate) : filterEntitiesQuery.OrderBy(m => m.NotificationDate),
                };

                var totalCount = await filterEntitiesQuery.CountAsync().ConfigureAwait(false);
                var filterEntities = await filterEntitiesQuery.Skip(skipCount).Take(filterParam.PageSize).ToListAsync().ConfigureAwait(false);

                return new FilterResult<Notification>
                {
                    Records = filterEntities.ConvertAll(m => new Notification
                    {
                        Id = m.Id,
                        Subject = m.Subject,
                        Description = m.Description,
                        IsActive = m.IsActive,
                        NotificationDate = m.NotificationDate
                    }),
                    TotalCount = totalCount
                };
            }
            catch (Exception)
            {
                throw;
            }
        }


        public async Task<IReadOnlyList<Notification>> GetAllNonReadNotification(Guid UserId)
        {
            var notificationEntities = await _context.TblNotifications.Include(m => m.TblNotificationUsers).Where(m => m.TblNotificationUsers.Where(a => a.UserId == UserId && !a.IsSeen).Any()).ToListAsync().ConfigureAwait(false) ?? throw new Exception("No notification found !");

            return notificationEntities.ConvertAll(m => new Notification
            {
                Id = m.Id,
                Subject = m.Subject,
                Description = m.Description,
                Route = m.TblNotificationUsers.FirstOrDefault(m => m.UserId == UserId) != null ? m.TblNotificationUsers.FirstOrDefault(m => m.UserId == UserId).Route : "",
                IsActive = m.IsActive,
                NotificationDate = m.NotificationDate,
                Parameter = m.TblNotificationUsers.FirstOrDefault(m => m.UserId == UserId) != null ? m.TblNotificationUsers.FirstOrDefault(m => m.UserId == UserId).Parameter : "",
            });
        }

        public async Task<bool> MarkNotificationAsSeen(Guid NotificationId, Guid UserId)
        {
           
            var notificationEntity = await _context.TblNotifications.Include(m => m.TblNotificationUsers).FirstOrDefaultAsync(m => m.Id == NotificationId).ConfigureAwait(false) ?? throw new Exception("No record found");

            if(notificationEntity.TblNotificationUsers.FirstOrDefault(m => m.UserId == UserId) == null)
            {
                throw new Exception("No notification found");
            }

            notificationEntity.TblNotificationUsers.FirstOrDefault(m => m.UserId == UserId).IsSeen = true;
            notificationEntity.TblNotificationUsers.FirstOrDefault(m => m.UserId == UserId).SeenDate = DateTime.Now;  

            try
            {
                await _context.SaveChangesAsync().ConfigureAwait(false);
                return true;
            }
            catch
            {
                throw;
            }
        }

    }
    #endregion
}
