﻿
using PeirLoanSystem.Data.Entities;
using PeirLoanSystem.Data.Models;
using PeirLoanSystem.Data.ViewModels;
using Microsoft.EntityFrameworkCore;
using System.Globalization;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace PeirLoanSystem.Data.Repositories
{
    #region --- Interface : ILoaneeRepository ---
    public interface ILoaneeRepository
    {
        Task<string> CreateAsync(Loanee data, Guid UserId);
        Task<string> UpdateAsync(Loanee data, Guid UserId);
        Task<IReadOnlyList<Loanee>> GetAllAsync();
        Task<Loanee> GetAsync(Guid id);
        Task<FilterResult<Loanee>> FilterAsync(LoaneeFilterParam filterParam, Guid UserId);
        Task<bool> DeleteDirector(Guid id);
        Task<Loanee> GetCompanyProfile(Guid UserId);
    }
    #endregion

    #region --- Class : LoaneeRepository ---
    public class LoaneeRepository : ILoaneeRepository
    {
        public readonly PeirloanDataContext _context;

        public LoaneeRepository(PeirloanDataContext context) => _context = context;

        public async Task<string> CreateAsync(Loanee data, Guid UserId)
        {
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data), string.Format("{0} is null", nameof(data)));
            }
            var loaneeEntities = await _context.TblLoanees.ToListAsync().ConfigureAwait(false);

            var existingEntity = loaneeEntities.FirstOrDefault(m => data.Name.ToUpper(CultureInfo.InvariantCulture) == m.Name);

            if (existingEntity != null)
            {
                throw new Exception("Name " + data.Name + " already exists");
            }

            if (!string.IsNullOrEmpty(data.PanNo))
            {
                var existgEntity = loaneeEntities.FirstOrDefault(m => !string.IsNullOrEmpty(m.PanNo) && data.PanNo.ToUpper() == m.PanNo.ToUpper());

                if (existgEntity != null)
                {
                    throw new Exception("Pan " + data.PanNo + " already exists");
                }
            }
            if (!string.IsNullOrEmpty(data.GstNo))
            {
                var existgEntity = loaneeEntities.FirstOrDefault(m => !string.IsNullOrEmpty(m.GstNo) && data.GstNo.ToUpper() == m.GstNo.ToUpper());

                if (existgEntity != null)
                {
                    throw new Exception("Gst " + data.GstNo + " already exists");
                }
            }


            var loanee = new TblLoanee
            {
                Id = Guid.NewGuid(),
                Name = data.Name,
                AddressLine1 = data.AddressLine1,
                AddressLine2 = data.AddressLine2,
                AddressLine3 = data.AddressLine3,
                DistrictId = data.DistrictId,
                City = data.City,
                CreatedBy = UserId,
                CreatedOn = DateTime.Now,
                GstNo = data.GstNo,
                PanNo = data.PanNo,
                Pincode = data.PinCode,
                RegistrationNo = data.RegistrationNo,
                StateId = data.StateId,
                Catgeory = data.Category,
                Email = data.Email,
                ContactNo = data.ContactNo,
                PaidUpCapital = data.PaidUpCapital,
                AuthorizedCapital = data.AuthorizedCapital,
                Cin = data.Cin,
                CompanyStatus = data.CompanyStatus,
                LoanReflected = data.LoanReflected,
                BriefDescription = data.BriefDescription,
                RegisteredOffice = data.RegisteredOffice,
                FactoryAddress = data.FactoryAddress,
            };

            if (data.Documents != null && data.Documents.Any())
            {
                foreach (var doc in data.Documents)
                {
                    loanee.TblLoaneeDocuments.Add(new TblLoaneeDocument
                    {
                        Id = Guid.NewGuid(),
                        LoaneeId = loanee.Id,
                        DocumentTypeId = doc.DocumentTypeId,
                        SubDocumentTypeId = doc.SubDocumentTypeId != Guid.Empty ? doc.SubDocumentTypeId : null,
                        DocFileName = doc.DocFileName,
                        DocFileSeq = doc.DocFileSeq,
                        UploadedBy = UserId,
                        UploadedOn = DateTime.Now
                    });
                }

            }
            if (data.Directors != null && data.Directors.Any())
            {
                foreach (var doc in data.Directors)
                {
                    loanee.TblLoaneeDirectors.Add(new TblLoaneeDirector
                    {
                        Id = Guid.NewGuid(),
                        LoaneeId = loanee.Id,
                        DirectorName = doc.DirectorName,
                        Address = doc.Address,
                        Din = doc.Din,
                        Email = doc.Email,
                        Mobile = doc.Mobile,
                    });
                }

            }

            try
            {
                _context.TblLoanees.Add(loanee);
                await _context.SaveChangesAsync().ConfigureAwait(false);
                return string.Format(CultureInfo.InvariantCulture, "{0} {1} added successfully", nameof(data), data.Name);
            }
            catch
            {
                throw;
            }
        }

        public async Task<string> UpdateAsync(Loanee data, Guid UserId)
        {
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data), string.Format("{0} is null", nameof(data)));
            }
            var loaneeEntities = await _context.TblLoanees.Where(m => m.Id != data.Id).ToListAsync().ConfigureAwait(false);


            var existingEntity = loaneeEntities.FirstOrDefault(m => data.Name.ToUpper(CultureInfo.InvariantCulture) == m.Name);

            if (existingEntity != null)
            {
                throw new Exception("Name " + data.Name + " already exists");
            }

            if (!string.IsNullOrEmpty(data.PanNo))
            {
                var existgEntity = loaneeEntities.FirstOrDefault(m => !string.IsNullOrEmpty(m.PanNo) && data.PanNo.ToUpper() == m.PanNo.ToUpper());

                if (existgEntity != null)
                {
                    throw new Exception("Pan " + data.PanNo + " already exists");
                }
            }
            if (!string.IsNullOrEmpty(data.GstNo))
            {
                var existgEntity = loaneeEntities.FirstOrDefault(m => !string.IsNullOrEmpty(m.GstNo) && data.GstNo.ToUpper() == m.GstNo.ToUpper());

                if (existgEntity != null)
                {
                    throw new Exception("Gst " + data.GstNo + " already exists");
                }
            }

            var loaneeEntity = await _context.TblLoanees.Include(m => m.TblLoaneeDirectors).FirstOrDefaultAsync(m => m.Id == data.Id).ConfigureAwait(false)?? throw new Exception("No record found !");
            if (loaneeEntity.TblLoaneeDirectors.Any())
            {

                _context.TblLoaneeDirectors.RemoveRange(loaneeEntity.TblLoaneeDirectors);
                await _context.SaveChangesAsync().ConfigureAwait(false);
            }

            loaneeEntity.Name = data.Name;
            loaneeEntity.AddressLine1 = data.AddressLine1;
            loaneeEntity.AddressLine2 = data.AddressLine2;
            loaneeEntity.AddressLine3 = data.AddressLine3;
            loaneeEntity.DistrictId = data.DistrictId;
            loaneeEntity.City = data.City;
            loaneeEntity.LastModifiedBy = UserId;
            loaneeEntity.LastModifiedOn = DateTime.Now;
            loaneeEntity.GstNo = data.GstNo;
            loaneeEntity.PanNo = data.PanNo;
            loaneeEntity.Pincode = data.PinCode;
            loaneeEntity.RegistrationNo = data.RegistrationNo;
            loaneeEntity.StateId = data.StateId;
            loaneeEntity.Catgeory = data.Category;
            loaneeEntity.Email = data.Email;
            loaneeEntity.ContactNo = data.ContactNo;
            loaneeEntity.PaidUpCapital = data.PaidUpCapital;
            loaneeEntity.AuthorizedCapital = data.AuthorizedCapital;
            loaneeEntity.Cin = data.Cin;
            loaneeEntity.CompanyStatus = data.CompanyStatus;
            loaneeEntity.BriefDescription = data.BriefDescription;
            loaneeEntity.LoanReflected = data.LoanReflected;
            loaneeEntity.RegisteredOffice = data.RegisteredOffice;
            loaneeEntity.FactoryAddress = data.FactoryAddress;

            var loaneeDocumentEntities = new List<TblLoaneeDocument>();
            var directorEntities = new List<TblLoaneeDirector>();

            if (data.Documents != null && data.Documents.Any())
            {
                foreach (var doc in data.Documents)
                {
                    loaneeDocumentEntities.Add(new TblLoaneeDocument
                    {
                        Id = Guid.NewGuid(),
                        LoaneeId = loaneeEntity.Id,
                        DocumentTypeId = doc.DocumentTypeId,
                        SubDocumentTypeId = doc.SubDocumentTypeId != Guid.Empty ? doc.SubDocumentTypeId : null,
                        DocFileName = doc.DocFileName,
                        DocFileSeq = doc.DocFileSeq,
                        UploadedBy = UserId,
                        UploadedOn = DateTime.Now
                    });
                }

            }

            if (data.Directors != null && data.Directors.Any())
            {
                foreach (var doc in data.Directors)
                {
                    directorEntities.Add(new TblLoaneeDirector
                    {
                        Id = Guid.NewGuid(),
                        LoaneeId = loaneeEntity.Id,
                        DirectorName = doc.DirectorName,
                        Address = doc.Address,
                        Din = doc.Din,
                        Email = doc.Email,
                        Mobile = doc.Mobile,
                    });
                }

            }
            try
            {
                _context.TblLoaneeDocuments.AddRange(loaneeDocumentEntities);
                _context.TblLoaneeDirectors.AddRange(directorEntities);
                await _context.SaveChangesAsync().ConfigureAwait(false);
                return string.Format(CultureInfo.InvariantCulture, "{0} {1} updated successfully", nameof(data), data.Name);
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> DeleteDirector(Guid id)
        {
            try
            {
                var directorEntity = await _context.TblLoaneeDirectors.FirstOrDefaultAsync(m => m.Id == id) ?? throw new Exception("No record found !");

            
                _context.TblLoaneeDirectors.Remove(directorEntity);
                await _context.SaveChangesAsync();
                return true;

            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IReadOnlyList<Loanee>> GetAllAsync()
        {
            try
            {
                var fieldStaffEntities = await _context.TblLoanees.OrderBy(m => m.Name).ToListAsync();
                return fieldStaffEntities.ConvertAll(m => new Loanee
                {
                    Id = m.Id,
                    Name = m.Name,
                });
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Loanee> GetAsync(Guid id)
        {
            try
            {
                var loaneeEntity = await _context.TblLoanees.Include(m => m.TblLoaneeDirectors).Include(m => m.TblLoaneeDocuments).ThenInclude(m => m.DocumentType).Include(m => m.TblLoaneeDocuments).ThenInclude(m => m.SubDocumentType).FirstOrDefaultAsync(m => m.Id == id) ?? throw new Exception("No record found !");

                return new Loanee
                {
                    Id = loaneeEntity.Id,
                    Name = loaneeEntity.Name,
                    AddressLine1 = loaneeEntity.AddressLine1,
                    AddressLine2 = loaneeEntity.AddressLine2,
                    AddressLine3 = loaneeEntity.AddressLine3,
                    DistrictId = loaneeEntity.DistrictId,
                    City = loaneeEntity.City,
                    GstNo = loaneeEntity.GstNo,
                    PanNo = loaneeEntity.PanNo,
                    PinCode = loaneeEntity.Pincode,
                    RegistrationNo = loaneeEntity.RegistrationNo,
                    StateId = loaneeEntity.StateId,
                    Category = loaneeEntity.Catgeory,
                    Email = loaneeEntity.Email,
                    ContactNo = loaneeEntity.ContactNo,
                    PaidUpCapital = loaneeEntity.PaidUpCapital,
                    AuthorizedCapital = loaneeEntity.AuthorizedCapital,
                    Cin = loaneeEntity.Cin,
                    CompanyStatus = loaneeEntity.CompanyStatus,
                    LoanReflected = loaneeEntity.LoanReflected,
                    BriefDescription = loaneeEntity.BriefDescription,
                    RegisteredOffice = loaneeEntity.RegisteredOffice,   
                    FactoryAddress = loaneeEntity.FactoryAddress,
                    Documents = loaneeEntity.TblLoaneeDocuments.Where(m => m.LoanId == null).Select(m => new LoanDocument
                    {
                        Id = m.Id,
                        DocFileName = m.DocFileName,
                        DocFileSeq = m.DocFileSeq,
                        DocumentTypeId = m.DocumentTypeId,
                        SubDocumentTypeId = m.SubDocumentTypeId,
                        DocumentTypeName = m.DocumentType.Name,
                        SubDocumentTypeName = m.SubDocumentType?.Name
                    }).ToList(),
                    Directors = loaneeEntity.TblLoaneeDirectors.Select(m => new Director
                    {
                        Id = m.Id,
                        DirectorName = m.DirectorName,
                        Din = m.Din,
                        LoaneeId = m.LoaneeId,
                        Address = m.Address,
                        Mobile = m.Mobile,
                        Email = m.Email
                    }).ToList(),
                };
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Loanee> GetCompanyProfile(Guid UserId)
        {
            try
            {
                var userEntity = await _context.TblUsers.FirstOrDefaultAsync(m => m.Id == UserId).ConfigureAwait(false) ?? throw new Exception("No record found !");

                if(userEntity.MappingId == null)
                {
                   throw new Exception("No record found !");
                }

                var loaneeEntity = await _context.TblLoanees.Include(m => m.TblLoaneeDirectors).Include(m => m.TblLoaneeDocuments).ThenInclude(m => m.DocumentType).Include(m => m.TblLoaneeDocuments).ThenInclude(m => m.SubDocumentType).FirstOrDefaultAsync(m => m.Id == userEntity.MappingId) ?? throw new Exception("No record found !");

                return new Loanee
                {
                    Id = loaneeEntity.Id,
                    Name = loaneeEntity.Name,
                    AddressLine1 = loaneeEntity.AddressLine1,
                    AddressLine2 = loaneeEntity.AddressLine2,
                    AddressLine3 = loaneeEntity.AddressLine3,
                    DistrictId = loaneeEntity.DistrictId,
                    City = loaneeEntity.City,
                    GstNo = loaneeEntity.GstNo,
                    PanNo = loaneeEntity.PanNo,
                    PinCode = loaneeEntity.Pincode,
                    RegistrationNo = loaneeEntity.RegistrationNo,
                    StateId = loaneeEntity.StateId,
                    Category = loaneeEntity.Catgeory,
                    Email = loaneeEntity.Email,
                    ContactNo = loaneeEntity.ContactNo,
                    PaidUpCapital = loaneeEntity.PaidUpCapital,
                    AuthorizedCapital = loaneeEntity.AuthorizedCapital,
                    Cin = loaneeEntity.Cin,
                    CompanyStatus = loaneeEntity.CompanyStatus,
                    LoanReflected = loaneeEntity.LoanReflected,
                    BriefDescription = loaneeEntity.BriefDescription,
                    RegisteredOffice = loaneeEntity.RegisteredOffice,
                    FactoryAddress = loaneeEntity.FactoryAddress,
                    Documents = loaneeEntity.TblLoaneeDocuments.Where(m => m.LoanId == null).Select(m => new LoanDocument
                    {
                        Id = m.Id,
                        DocFileName = m.DocFileName,
                        DocFileSeq = m.DocFileSeq,
                        DocumentTypeId = m.DocumentTypeId,
                        SubDocumentTypeId = m.SubDocumentTypeId,
                        DocumentTypeName = m.DocumentType.Name,
                        SubDocumentTypeName = m.SubDocumentType?.Name
                    }).ToList(),
                    Directors = loaneeEntity.TblLoaneeDirectors.Select(m => new Director
                    {
                        Id = m.Id,
                        DirectorName = m.DirectorName,
                        Din = m.Din,
                        LoaneeId = m.LoaneeId,
                        Address = m.Address,
                        Mobile = m.Mobile,
                        Email = m.Email
                    }).ToList(),
                };
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<FilterResult<Loanee>> FilterAsync(LoaneeFilterParam filterParam, Guid UserId)
        {
            try
            {
                if (filterParam == null) return new FilterResult<Loanee>();
                var userEntity = await _context.TblUsers.Include(m => m.Role).FirstOrDefaultAsync(m => m.Id == UserId);

                var skipCount = (filterParam.PageIndex - 1) * filterParam.PageSize;
                var filterEntitiesQuery = _context.TblLoanees.Include(m => m.TblLoans).ThenInclude(m => m.TblRepayments).Include(m => m.State).Include(m => m.District).Include(m => m.TblLoaneeDocuments).ThenInclude(m => m.DocumentType).Include(m => m.TblLoaneeDocuments).ThenInclude(m => m.SubDocumentType).AsNoTracking().AsQueryable();

                if (!string.IsNullOrEmpty(filterParam.FilterText))
                {
                    filterEntitiesQuery = filterEntitiesQuery.Where(m => m.Name.ToLower().Contains(filterParam.FilterText.Trim().ToLower())
                                          || (m.State != null && m.State.Name.ToLower().Contains(filterParam.FilterText.Trim().ToLower()))
                                          || (m.District != null && m.District.Name.ToLower().Contains(filterParam.FilterText.Trim().ToLower()))
                                          || (m.PanNo != null && m.PanNo.ToLower().Contains(filterParam.FilterText.Trim().ToLower()))
                                           || (m.GstNo != null && m.GstNo.ToLower().Contains(filterParam.FilterText.Trim().ToLower()))
                                           || (m.City != null && m.City.ToLower().Contains(filterParam.FilterText.Trim().ToLower()))
                                           || (m.AddressLine1 != null && m.AddressLine1.ToLower().Contains(filterParam.FilterText.Trim().ToLower()))
                                           || (m.AddressLine2 != null && m.AddressLine2.ToLower().Contains(filterParam.FilterText.Trim().ToLower()))
                                           || (m.AddressLine3 != null && m.AddressLine3.ToLower().Contains(filterParam.FilterText.Trim().ToLower()))
                                           || (m.RegistrationNo != null && m.RegistrationNo.ToLower().Contains(filterParam.FilterText.Trim().ToLower()))
                                           || (m.Pincode != null && m.Pincode.ToLower().Contains(filterParam.FilterText.Trim().ToLower())));
                }
                if (filterParam.DistrictId != null && filterParam.DistrictId != Guid.Empty)
                {
                    filterEntitiesQuery = filterEntitiesQuery.Where(m => m.DistrictId != null && m.DistrictId == filterParam.DistrictId);
                }
                if (!string.IsNullOrEmpty(filterParam.Category))
                {
                    filterEntitiesQuery = filterEntitiesQuery.Where(m => m.Catgeory.ToUpper() == filterParam.Category.ToUpper());
                }
                if (filterParam.StateId != null && filterParam.StateId != Guid.Empty)
                {
                    filterEntitiesQuery = filterEntitiesQuery.Where(m => m.StateId != null && m.StateId == filterParam.StateId);
                }
                if (userEntity != null && userEntity.MappingId != null && userEntity.Role.Name == "Vendor")
                {
                    filterEntitiesQuery = filterEntitiesQuery.Where(m => m.Id == userEntity.MappingId);
                }

                filterEntitiesQuery = (filterParam.SortOn.ToUpper()) switch
                {
                    _ => filterParam.SortDirection.ToUpper() == "DESC" ? filterEntitiesQuery.OrderByDescending(m => m.Name) : filterEntitiesQuery.OrderBy(m => m.Name),
                };

                var totalCount = await filterEntitiesQuery.CountAsync().ConfigureAwait(false);
                var filterEntities = await filterEntitiesQuery.Skip(skipCount).Take(filterParam.PageSize).ToListAsync().ConfigureAwait(false);

                return new FilterResult<Loanee>
                {
                    Records = filterEntities.ConvertAll(loaneeEntity => new Loanee
                    {
                        Id = loaneeEntity.Id,
                        Name = loaneeEntity.Name,
                        AddressLine1 = loaneeEntity.AddressLine1,
                        AddressLine2 = loaneeEntity.AddressLine2,
                        AddressLine3 = loaneeEntity.AddressLine3,
                        DistrictId = loaneeEntity.DistrictId,
                        City = loaneeEntity.City,
                        GstNo = loaneeEntity.GstNo,
                        PanNo = loaneeEntity.PanNo,
                        PinCode = loaneeEntity.Pincode,
                        RegistrationNo = loaneeEntity.RegistrationNo,
                        StateId = loaneeEntity.StateId,
                        StateName = loaneeEntity.State?.Name,
                        DistrictName = loaneeEntity.District?.Name,
                        Category = loaneeEntity.Catgeory,
                        LoanAmount = loaneeEntity.TblLoans.Select(a => a.LoanAmount).Sum(),
                        OutStandingAmount = CalculateOutStandingAmount(loaneeEntity.Id),
                        LoanCount = loaneeEntity.TblLoans.Count(),
                        Cin = loaneeEntity.Cin,
                        AuthorizedCapital = loaneeEntity.AuthorizedCapital,
                        PaidUpCapital = loaneeEntity.PaidUpCapital,
                        CompanyStatus = loaneeEntity.CompanyStatus,
                        Email = loaneeEntity.Email,
                        ContactNo = loaneeEntity.ContactNo,
                        LoanReflected = loaneeEntity.LoanReflected,
                        BriefDescription = loaneeEntity.BriefDescription,
                        FactoryAddress = loaneeEntity.FactoryAddress,
                        RegisteredOffice = loaneeEntity.RegisteredOffice,
                        Documents = loaneeEntity.TblLoaneeDocuments.Where(m => m.LoanId == null).Select(m => new LoanDocument
                        {
                            Id = m.Id,
                            DocFileName = m.DocFileName,
                            DocFileSeq = m.DocFileSeq,
                            DocumentTypeId = m.DocumentTypeId,
                            SubDocumentTypeId = m.SubDocumentTypeId,
                            DocumentTypeName = m.DocumentType.Name,
                            SubDocumentTypeName = m.SubDocumentType?.Name
                        }).ToList(),
                    }),
                    TotalCount = totalCount
                };
            }
            catch (Exception)
            {
                throw;
            }
        }

        private decimal CalculateOutStandingAmount(Guid LoaneeId)
        {
            var loanEntities = _context.TblLoans.Include(m => m.TblRepayments).Where(m => m.LoaneeId == LoaneeId).ToList();
            decimal OutstandingAmount = 0;

            foreach (var loanEntity in loanEntities)
            {
                OutstandingAmount = loanEntity.LoanAmount - loanEntity.TblRepayments.Select(m => m.PrincipalPaid + m.InterestPaid - m.InterestDue).Sum();
                bool IsDefaulter = loanEntity.IsDefaulter;

                if (!loanEntity.IsDefaulter)
                {
                    int countOfPayments = 1;

                    countOfPayments += loanEntity.TblRepayments.Count();

                    DateOnly dtExpecetedPaymentDate = loanEntity.DisbursedDate.AddYears(countOfPayments);
                    dtExpecetedPaymentDate = dtExpecetedPaymentDate.AddDays(1 - dtExpecetedPaymentDate.Day).AddMonths(1).AddDays(-1);

                    IsDefaulter = DateOnly.FromDateTime(DateTime.Now) > dtExpecetedPaymentDate;
                }

                var applicableInterestRate = IsDefaulter ? loanEntity.InterestRate : loanEntity.InterestRate - loanEntity.RebateInterest;
                var interestDueDate = loanEntity.TblRepayments.Any() ? loanEntity.TblRepayments.OrderByDescending(m => m.RepaymentDate).FirstOrDefault().RepaymentDate : loanEntity.DisbursedDate;

                OutstandingAmount += (((loanEntity.LoanAmount - loanEntity.TblRepayments.Select(m => m.PrincipalPaid).Sum()) * ((applicableInterestRate) / 100)) / 365) * (DateOnly.FromDateTime(DateTime.Now).DayNumber - interestDueDate.DayNumber + 1);
            }
           

            return OutstandingAmount;
        }

    
    }
    #endregion
}
