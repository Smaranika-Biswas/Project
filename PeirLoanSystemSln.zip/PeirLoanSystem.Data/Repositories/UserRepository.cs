﻿using PeirLoanSystem.Core.Crypto;
using PeirLoanSystem.Core.Security;
using PeirLoanSystem.Core.Extensions;
using PeirLoanSystem.Data.Entities;
using PeirLoanSystem.Data.Models;
using PeirLoanSystem.Data.ViewModels;
using Microsoft.EntityFrameworkCore;
using System.Globalization;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Net.WebRequestMethods;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Newtonsoft.Json;

namespace PeirLoanSystem.Data.Repositories
{
    public interface IUserRepository
    {
        Task<List<User>> GetAllUserAsync(int TokenValidHours);
        Task<User?> GetUserByIdAsync(Guid id);
        Task<string> CreateUserAsync(User user);
        Task<string> UpdateUserAsync(Guid id, User data);
        Task<FilterResult<User>> FilterAsync(UserFilterParam filterParam);
        //Task<List<Role>> GetRoleUserTypeWiseAsync();
        //Task<List<Role>> GetAllRoleAsync();
        //Task<Role?> GetRoleByIdAsync(Guid id);
        //Task<string> CreateRoleAsync(Role data);
        //Task<string> UpdateRoleAsync(Guid id, Role data);
        Task<string> UnlockUser(Guid userId);
        Task<LoginResponse> ValidateAsync(LoginRequest loginRequest, int sessionMinutes);
        Task<string> ResetPasswordAsync(ResetPassword resetPassword);
        Task<string> ChangePasswordAsync(ChangePassword model, Guid UserId);
        Task<Captcha> GenerateCaptcha();
        Task<Captcha> ReGenerateCaptcha(Guid Id);
        Task<OtpSessionResponse?> GetSessionOtpVerifyAsync(string verifyToken);
        Task<string> LogOut(Guid userId, string AccessToken);
        Task<User?> UserByUserNameAsync(UserNameRequest request);
        Task<LoginResponse> UserOtpCreationAsync(Guid id);
        Task<LoginResponse?> ResendOTPAsync(string vToken);
        Task<string?> HasAnySession(Guid userId, int sessionMinutes);
        Task<VerificationResponse> VerifyAsync(VerificationRequest verificationRequest, JwtCred jwtCredentials, int TokenValidHours);
        Task<bool> AllowUserLogin(Guid UserId, int sessionMinutes);
        Task<ForgotPasswordResponse> VerifyOTPAsync(VerificationRequest verificationRequest, JwtCred jwtCredentials, int TokenValidHours);
        //Task<List<User?>> GetUserByRoleIdAsync(Guid id);
        //Task<RoleMenuPermissionModel> Get(Guid menuId);
        //Task<MenuPermissionModel> GetAllMenuWithPermission(Guid RoleId, Guid UserId);
        //Task<bool> UpdateRoleMenuPermissionToken(RoleWiseMenuPermissionCheckBox model);

        //Task<bool> UpdateUserMenuPermissionToken(RoleWiseMenuPermissionCheckBox model, Guid UserId);
    }
    public class UserRepository : IUserRepository
    {
        private readonly PeirloanDataContext _context;

        public UserRepository(PeirloanDataContext context)
        {
            _context = context;
        }

        #region USER SECTION

        public async Task<List<User>> GetAllUserAsync(int TokenValidHours)
        {
            var userEntities = await _context.TblUsers.Include(m => m.Role).OrderBy(m => m.UserName).ToListAsync();
            return userEntities.Select(m => new User
            {
                Id = m.Id,
                UserName = m.UserName,
                Mobile = m.Mobile,
                Email = m.Email,
                RoleId = m.RoleId,
                IsActive = m.IsActive,
                FullName = m.FullName,
                IsLocked = m.IsLocked
            }).ToList();
        }

        public async Task<User?> GetUserByIdAsync(Guid id)
        {
            var userEntity = await _context.TblUsers.FirstOrDefaultAsync(m => m.Id == id);
            return userEntity == null ? null : new User
            {
                Id = userEntity.Id,
                FirstName = userEntity.FirstName,
                MiddleName = userEntity.MiddleName,
                LastName = userEntity.LastName,
                FullName = userEntity.FullName,
                UserName = userEntity.UserName,
                Mobile = userEntity.Mobile,
                Email = userEntity.Email,
                RoleId = userEntity.RoleId,
                MappingId = userEntity.MappingId,
                IsActive = userEntity.IsActive
            };
        }

        public async Task<string> CreateUserAsync(User user)
        {
            var existingUserEntity = await _context.TblUsers.FirstOrDefaultAsync(m => m.UserName == user.UserName).ConfigureAwait(false);
            if (existingUserEntity != null)
            {
                throw new Exception("This User Name has already been used by other user");
            }

            var existingMobileUserEntity = await _context.TblUsers.FirstOrDefaultAsync(m => m.Mobile == user.Mobile).ConfigureAwait(false);
            if (existingMobileUserEntity != null)
            {
                throw new Exception("This User Mobile No. has already been used by another user");
            }

            var salt = SaltGenerator.Generate();
            var userEntity = new TblUser
            {
                Id = Guid.NewGuid(),
                UserName = user.UserName,
                Password = salt + "~" + PBKDF2Crypto.Create(user.Password, salt),
                FirstName = user.FirstName,
                MiddleName = user.MiddleName,
                LastName = user.LastName,
                Mobile = user.Mobile,
                Email = user.Email,
                RoleId = user.RoleId,
                MappingId = user.MappingId,
                IsActive = true
            };

            try
            {
                await _context.TblUsers.AddAsync(userEntity);
                await _context.SaveChangesAsync();

                return $"User {user.UserName} is created successfully";
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<string> UpdateUserAsync(Guid id, User data)
        {
            var userEntity = await _context.TblUsers.FirstOrDefaultAsync(m => m.Id == data.Id).ConfigureAwait(false);
            if (userEntity == null)
            {
                return string.Format(CultureInfo.InvariantCulture, "{0} not found with the given id", nameof(data));
            }
            var existingUserEntity = await _context.TblUsers.FirstOrDefaultAsync(m => m.Id != data.Id && m.UserName == data.UserName).ConfigureAwait(false);
            if (existingUserEntity != null)
            {
                throw new Exception("This User Name has already been used by other user");
            }
            var existingMobileUserEntity = await _context.TblUsers.FirstOrDefaultAsync(m => m.Id != data.Id && m.Mobile == data.Mobile).ConfigureAwait(false);
            if (existingMobileUserEntity != null)
            {
                throw new Exception("This User Mobile No. has already been used by another user");
            }
            userEntity.UserName = data.UserName;
            userEntity.FirstName = data.FirstName;
            userEntity.MiddleName = data.MiddleName;
            userEntity.LastName = data.LastName;
            userEntity.Mobile = data.Mobile;
            userEntity.Email = data.Email;
            userEntity.RoleId = data.RoleId;
            userEntity.MappingId = data.MappingId;
            userEntity.IsActive = data.IsActive;

            try
            {
                await _context.SaveChangesAsync().ConfigureAwait(false);
                return string.Format(CultureInfo.InvariantCulture, "{0} {1} updated successfully", nameof(data), data.UserName);
            }
            catch
            {
                throw;
            }
        }




        public async Task<FilterResult<User>> FilterAsync(UserFilterParam filterParam)
        {
            try
            {
                var skipCount = (filterParam.PageIndex - 1) * filterParam.PageSize;
                var filterEntitiesQuery = await _context.TblUsers.Include(m => m.TblUserSessions).Include(m => m.Role).ToListAsync();

                if (filterParam.RoleId != null && filterParam.RoleId != Guid.Empty)
                {
                    filterEntitiesQuery = filterEntitiesQuery.Where(m => m.RoleId == filterParam.RoleId).ToList();

                }
                if (filterParam.FilterText != string.Empty)
                {
                    filterEntitiesQuery = filterEntitiesQuery.Where(m => m.UserName.ToUpper().Contains(filterParam.FilterText.ToUpper())).ToList();
                }

                if (filterParam.FullName != string.Empty)
                {
                    filterEntitiesQuery = filterEntitiesQuery.Where(m => m.FullName.ToUpper().Contains(filterParam.FullName.ToUpper())).ToList();
                }

                filterEntitiesQuery = (filterParam.SortOn.ToUpper()) switch
                {
                    _ => filterParam.SortDirection.ToUpper() == "ASC" ? filterEntitiesQuery.OrderBy(m => m.UserName).ToList() : filterEntitiesQuery.OrderByDescending(m => m.UserName).ToList(),
                };

                var totalCount = filterEntitiesQuery.Count();
                var filterEntities = filterEntitiesQuery.Skip(skipCount).Take(filterParam.PageSize).ToList();

                return new FilterResult<User>
                {
                    Records = filterEntities.ConvertAll(m => new User
                    {
                        Id = m.Id,
                        UserName = m.UserName,
                        Mobile = m.Mobile,
                        Email = m.Email,
                        RoleId = m.RoleId,
                        RoleName = m.Role.Name,
                        MappingId = m.MappingId,
                        IsActive = m.IsActive,
                        FullName = m.FullName,
                        IsLocked = m.IsLocked,
                        IsUserLoggedIn = m.TblUserSessions.FirstOrDefault(x => x.LoginTime != null && x.LogoutTime == null && (DateTime.Now - x.LoginTime.Value).TotalMinutes < filterParam.tokenValidHours) == null ? false : true,
                    }),
                    TotalCount = totalCount
                };
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion

        #region ROLE SECTION
        //public async Task<List<Role>> GetRoleUserTypeWiseAsync()
        //{
        //    var roleEntities = await _context.TblRoles.OrderBy(m => m.Name).ToListAsync();

        //    return roleEntities.Select(m => new Role
        //    {
        //        Id = m.Id,
        //        Name = m.Name,
        //        Alias = m.Alias,
        //    }).ToList();
        //}

        ////public async Task<List<Role>> GetAllRoleAsync()
        ////{
        ////    var roleEntities = await _context.TblRoles.OrderBy(m => m.Name).ToListAsync();
        ////    return roleEntities.Select(m => new Role
        ////    {
        ////        Id = m.Id,
        ////        Name = m.Name,
        ////        Alias = m.Alias,
        ////    }).ToList();
        ////}

        ////public async Task<Role?> GetRoleByIdAsync(Guid id)
        ////{
        ////    var roleEntity = await _context.TblRoles.FirstOrDefaultAsync(m => m.Id == id);
        ////    return roleEntity == null ? null : new Role
        ////    {
        ////        Id = roleEntity.Id,
        ////        Name = roleEntity.Name,
        ////        Alias = roleEntity.Alias,
        ////    };
        ////}

        ////public async Task<List<User?>> GetUserByRoleIdAsync(Guid id)
        ////{

        ////    var roleEntity = await _context.TblUsers.Where(m => m.RoleId==id && m.IsActive==true).ToListAsync();

        ////    return roleEntity.Select(m => new User
        ////    {
        ////        Id = m.Id,
        ////        FullName = m.FullName

        ////    }).ToList();
        ////}

        //public async Task<string> CreateRoleAsync(Role data)
        //{
        //    if (data == null)
        //    {
        //        throw new ArgumentNullException(nameof(data), string.Format("{0} is null", nameof(data)));
        //    }
        //    var existingEntity = await _context.TblRoles.FirstOrDefaultAsync(m => data.Name.ToUpper(CultureInfo.InvariantCulture) == m.Name).ConfigureAwait(false);
        //    if (existingEntity != null)
        //    {
        //        throw new ArgumentException(string.Format("{0} {1} already exists", nameof(data), data.Name));
        //    }

        //    var roleEntity = new TblRole
        //    {
        //        Id = Guid.NewGuid(),
        //        Name = data.Name,
        //        Alias = data.Alias,

        //    };

        //    try
        //    {
        //        _context.TblRoles.Add(roleEntity);
        //        await _context.SaveChangesAsync().ConfigureAwait(false);
        //        return string.Format(CultureInfo.InvariantCulture, "{0} {1} added successfully", nameof(data), data.Name);
        //    }
        //    catch
        //    {
        //        throw;
        //    }
        //}

        //public async Task<string> UpdateRoleAsync(Guid id, Role data)
        //{
        //    var existingEntity = await _context.TblRoles.FirstOrDefaultAsync(m => data.Name.ToUpper(CultureInfo.InvariantCulture) == m.Name && m.Id != id).ConfigureAwait(false);
        //    if (existingEntity != null)
        //    {
        //        return string.Format(CultureInfo.InvariantCulture, "{0} {1} already exists", nameof(data), data.Name);
        //    }

        //    var roleEntity = await _context.TblRoles.FirstOrDefaultAsync(m => m.Id == data.Id).ConfigureAwait(false);
        //    if (roleEntity == null)
        //    {
        //        return string.Format(CultureInfo.InvariantCulture, "{0} not found with the given id", nameof(data));
        //    }

        //    roleEntity.Name = data.Name;
        //    roleEntity.Alias = data.Alias;

        //    try
        //    {
        //        await _context.SaveChangesAsync().ConfigureAwait(false);
        //        return string.Format(CultureInfo.InvariantCulture, "{0} {1} updated successfully", nameof(data), data.Name);
        //    }
        //    catch
        //    {
        //        throw;
        //    }
        //}


        //public async Task<RoleMenuPermissionModel> Get(Guid menuId)
        //{
        //    var menuEntity = await _context.TblMenus.Include(m => m.TblMenuPermissionTokens).ThenInclude(m => m.PermissionToken).FirstOrDefaultAsync(m => m.Id == menuId);
        //    var roleEntities = await _context.TblRoles.OrderBy(p => p.Name).ToListAsync();
        //    var rolePermissionTokenEntities = await _context.TblRoleMenuPermissionTokens.ToListAsync();

        //    var model = new RoleMenuPermissionModel();
        //    var headers = new List<string>();
        //    model.MenuId = menuId;
        //    headers.AddRange(menuEntity.TblMenuPermissionTokens.Select(p => p.PermissionToken.Name).OrderBy(p => p));
        //    model.Headers = headers;

        //    var permissionList = new List<RolePermissionTokenModel>();
        //    foreach (var role in roleEntities)
        //    {
        //        var roleMenuPermissionEntites = rolePermissionTokenEntities.Where(m => m.RoleId == role.Id).ToList();

        //        permissionList.Add(new RolePermissionTokenModel
        //        {
        //            RoleId = role.Id,
        //            RoleName = role.Name,
        //            PermissionTokens = menuEntity.TblMenuPermissionTokens.OrderBy(m => m.PermissionToken.Name).Select(m => new PermissionTokenModel
        //            {
        //                Id = m.Id,
        //                Name = m.PermissionToken.Name,
        //                IsSelected = roleMenuPermissionEntites.Any(p => p.MenuPermissionTokenId == m.Id)
        //            }).ToList()
        //        });
        //    }

        //    model.Permissions = permissionList;
        //    return model;
        //}


        //public async Task<MenuPermissionModel> GetAllMenuWithPermission(Guid RoleId, Guid UserId)
        //{
        //    if (RoleId != Guid.Empty)
        //    {
        //        //var menuEntity = await _context.TblMenus.Include(m => m.TblMenuPermissionTokens).ThenInclude(m => m.PermissionToken).FirstOrDefaultAsync(m => m.Id == menuId);
        //        var MenuEntities = await _context.TblMenus.Include(m => m.TblMenuPermissionTokens).ThenInclude(m => m.PermissionToken).Where(m => !string.IsNullOrEmpty(m.TargetPath.Trim()) && m.TargetPath.Trim() != "#" && m.IsActive == true).OrderBy(m => m.Name).ToListAsync().ConfigureAwait(false);
        //        //var roleEntities = await _context.TblRoles.OrderBy(p => p.Name).ToListAsync();
        //        var rolePermissionTokenEntities = await _context.TblRoleMenuPermissionTokens.ToListAsync();

        //        var permissionTokens = await _context.TblPermissionTokens.ToListAsync().ConfigureAwait(false);

        //        var model = new MenuPermissionModel();
        //        var headers = new List<string>();
        //        model.RoleId = RoleId;
        //        headers.AddRange(permissionTokens.Select(p => p.Name).OrderBy(p => p).Distinct());
        //        model.Headers = headers;

        //        var permissionList = new List<MenuPermissionTokenModel>();
        //        foreach (var menu in MenuEntities)
        //        {
        //            var roleMenuPermissionEntites = rolePermissionTokenEntities.Where(m => m.RoleId == RoleId).ToList();

        //            permissionList.Add(new MenuPermissionTokenModel
        //            {
        //                MenuId = menu.Id,
        //                MenuName = menu.Name,
        //                PermissionTokens = menu.TblMenuPermissionTokens.OrderBy(m => m.PermissionToken.Name).Select(m => new PermissionTokenModel
        //                {
        //                    Id = m.Id,
        //                    Name = m.PermissionToken.Name,
        //                    IsSelected = roleMenuPermissionEntites.Any(p => p.MenuPermissionTokenId == m.Id)
        //                }).OrderBy(m => m.Name).ToList()
        //            });
        //        }

        //        model.Permissions = permissionList;
        //        return model;
        //    }
        //    else
        //    {
        //        var MenuEntities = await _context.TblMenus.Include(m => m.TblMenuPermissionTokens).ThenInclude(m => m.PermissionToken).Where(m => !string.IsNullOrEmpty(m.TargetPath.Trim()) && m.TargetPath.Trim() != "#"  && m.IsActive == true).OrderBy(m => m.Name).ToListAsync().ConfigureAwait(false);

        //        var userEntity = await _context.TblUsers.Where(m => m.Id == UserId).Include(m => m.TblUserMenuPermissionTokens).FirstOrDefaultAsync().ConfigureAwait(false);
        //        var userPermissionTokenEntities = userEntity.TblUserMenuPermissionTokens.ToList();
        //        var rolePermissionTokenEntities = await _context.TblRoleMenuPermissionTokens.ToListAsync();

        //        var permissionTokens = await _context.TblPermissionTokens.ToListAsync().ConfigureAwait(false);

        //        var model = new MenuPermissionModel();
        //        var headers = new List<string>();

        //        headers.AddRange(permissionTokens.Select(p => p.Name).OrderBy(p => p).Distinct());
        //        model.Headers = headers;

        //        var permissionList = new List<MenuPermissionTokenModel>();
        //        foreach (var menu in MenuEntities)
        //        {
        //            var userMenuPermissionEntites = userPermissionTokenEntities.Where(m => m.UserId == UserId).ToList();
        //            var roleMenuPermissionEntites = rolePermissionTokenEntities.Where(m => m.RoleId == userEntity.RoleId).ToList();
        //            permissionList.Add(new MenuPermissionTokenModel
        //            {
        //                MenuId = menu.Id,
        //                MenuName = menu.Name,
        //                PermissionTokens = menu.TblMenuPermissionTokens.OrderBy(m => m.PermissionToken.Name).Select(m => new PermissionTokenModel
        //                {
        //                    Id = m.Id,
        //                    Name = m.PermissionToken.Name,
        //                    IsSelected = userMenuPermissionEntites.Where(u => u.MenuPermissionTokenId == m.Id).Count() > 0 ? true :
        //                            roleMenuPermissionEntites.Where(p => p.MenuPermissionTokenId == m.Id).Count() > 0 ? true : false,
        //                    IsDisabled = roleMenuPermissionEntites.Any(p => p.MenuPermissionTokenId == m.Id)
        //                }).OrderBy(m => m.Name).ToList()
        //            });
        //        }

        //        model.Permissions = permissionList;
        //        return model;
        //    }

        //}

        //public async Task<bool> UpdateRoleMenuPermissionToken(RoleWiseMenuPermissionCheckBox model)
        //{
        //    if (model == null)
        //    {
        //        throw new ArgumentNullException(nameof(model), string.Format("{0} is null", nameof(model)));
        //    }
        //    if (model.IsChecked)
        //    {
        //        var roleMenuPermissionTokenCount = await _context.TblRoleMenuPermissionTokens.Where(m => m.RoleId == model.RoleId && m.MenuPermissionTokenId == model.MenuPermissionTokenId).CountAsync().ConfigureAwait(true);

        //        if (roleMenuPermissionTokenCount > 0)
        //        {
        //            return false;
        //        }
        //        else
        //        {
        //            var newRoleMenuPermissionTokenEntities = new List<TblRoleMenuPermissionToken>();

        //            var menuPermissionTokenEntity = await _context.TblMenuPermissionTokens.Include(m => m.PermissionToken).FirstOrDefaultAsync(m => m.Id == model.MenuPermissionTokenId).ConfigureAwait(false);

        //            if(menuPermissionTokenEntity != null && menuPermissionTokenEntity.PermissionToken.Name == "FULL")
        //            {
        //                var existingRoleMenuPermissionTokenEntites = await _context.TblRoleMenuPermissionTokens.Include(a => a.MenuPermissionToken).Where(a => a.RoleId == model.RoleId && a.MenuPermissionToken.MenuId == menuPermissionTokenEntity.MenuId).ToListAsync().ConfigureAwait(false);
        //                var menuPermissionTokenEntites = await _context.TblMenuPermissionTokens.Where(a => a.MenuId == menuPermissionTokenEntity.MenuId).ToListAsync().ConfigureAwait(false);



        //                foreach (var menuPermissionToken in menuPermissionTokenEntites)
        //                {
        //                    if (existingRoleMenuPermissionTokenEntites.FirstOrDefault(a => a.RoleId == model.RoleId && a.MenuPermissionTokenId == menuPermissionToken.Id) == null)
        //                    {
        //                        newRoleMenuPermissionTokenEntities.Add(new TblRoleMenuPermissionToken
        //                        {
        //                            Id = Guid.NewGuid(),
        //                            RoleId = model.RoleId,
        //                            MenuPermissionTokenId = menuPermissionToken.Id
        //                        });
        //                    }
        //                }
        //            }
        //            else
        //            {
        //                newRoleMenuPermissionTokenEntities.Add(new TblRoleMenuPermissionToken
        //                {
        //                    Id = Guid.NewGuid(),
        //                    RoleId = model.RoleId,
        //                    MenuPermissionTokenId = model.MenuPermissionTokenId,
        //                });
        //            }


        //            try
        //            {
        //                _context.TblRoleMenuPermissionTokens.AddRange(newRoleMenuPermissionTokenEntities);
        //                await _context.SaveChangesAsync();
        //                return true;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw;
        //            }
        //        }
        //    }
        //    else
        //    {
        //        var menuPermissionTokenEntity = await _context.TblRoleMenuPermissionTokens.Where(m => m.RoleId == model.RoleId && m.MenuPermissionTokenId == model.MenuPermissionTokenId).FirstOrDefaultAsync().ConfigureAwait(true);

        //        if (menuPermissionTokenEntity == null)
        //        {
        //            return false;
        //        }
        //        else
        //        {
        //            try
        //            {
        //                _context.TblRoleMenuPermissionTokens.Remove(menuPermissionTokenEntity);
        //                await _context.SaveChangesAsync();
        //                return true;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw;
        //            }
        //        }
        //    }

        //}


        //public async Task<bool> UpdateUserMenuPermissionToken(RoleWiseMenuPermissionCheckBox model, Guid UserId)
        //{
        //    if (model == null)
        //    {
        //        throw new ArgumentNullException(nameof(model), string.Format("{0} is null", nameof(model)));
        //    }
        //    if (model.IsChecked)
        //    {
        //        var menuPermissionTokenEntity = await _context.TblUserMenuPermissionTokens.Where(m => m.UserId == model.RoleId && m.MenuPermissionTokenId == model.MenuPermissionTokenId).CountAsync().ConfigureAwait(true);

        //        if (menuPermissionTokenEntity > 0)
        //        {
        //            return false;
        //        }
        //        else
        //        {
        //            var newMenuPermissionTokenEntity = new TblUserMenuPermissionToken
        //            {
        //                Id = Guid.NewGuid(),
        //                UserId = model.RoleId,
        //                MenuPermissionTokenId = model.MenuPermissionTokenId,
        //            };

        //            try
        //            {
        //                _context.TblUserMenuPermissionTokens.Add(newMenuPermissionTokenEntity);
        //                await _context.SaveChangesAsync();
        //                return true;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw;
        //            }
        //        }
        //    }
        //    else
        //    {
        //        var menuPermissionTokenEntity = await _context.TblUserMenuPermissionTokens.Where(m => m.UserId == model.RoleId && m.MenuPermissionTokenId == model.MenuPermissionTokenId).FirstOrDefaultAsync().ConfigureAwait(true);

        //        if (menuPermissionTokenEntity == null)
        //        {
        //            return false;
        //        }
        //        else
        //        {
        //            try
        //            {
        //                _context.TblUserMenuPermissionTokens.Remove(menuPermissionTokenEntity);
        //                await _context.SaveChangesAsync();
        //                return true;
        //            }
        //            catch (Exception ex)
        //            {
        //                throw;
        //            }
        //        }
        //    }

        //}

        #endregion

        #region USER VALIDATION SECTION


        public async Task<bool> AllowUserLogin(Guid UserId, int sessionMinutes)
        {
            var userEntity = await _context.TblUsers.Include(m => m.TblUserSessions).FirstOrDefaultAsync(m => m.Id == UserId);

            var userSessionEntity = userEntity.TblUserSessions.FirstOrDefault(m => m.LoginTime != null && m.LogoutTime == null && (DateTime.Now - m.LoginTime.Value).TotalMinutes < sessionMinutes) ?? throw new Exception("No Valid Login Session Found");

            userSessionEntity.LogoutTime = DateTime.Now;
            try
            {
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<OtpSessionResponse?> GetSessionOtpVerifyAsync(string verifyToken)
        {
            var actualToken = verifyToken[1..];
            var userSessionEntity = await _context.TblUserSessions.FirstOrDefaultAsync(m => m.VerificationToken == actualToken); //&& !m.IsOtpVerified
            if (userSessionEntity == null)
            {
                return null;
            }

            var formattedMobile = userSessionEntity.VerificationMobile.Mask(2, userSessionEntity.VerificationMobile.Length - 4, 'x');
            return new OtpSessionResponse
            {
                FormattedMonile = formattedMobile,
                OtpExpirationTime = userSessionEntity.OtpExpirationTime,
                OtpValidTime = Convert.ToInt32((userSessionEntity.OtpExpirationTime - DateTime.Now).TotalSeconds)
            };
        }

        public async Task<string> LogOut(Guid userId, string AccessToken)
        {
            var userSessionEntity = await _context.TblUserSessions.FirstOrDefaultAsync(m => m.UserId == userId && !string.IsNullOrEmpty(m.AuthToken) && m.AuthToken.Equals(AccessToken)).ConfigureAwait(false);
            if (userSessionEntity == null)
            {
                return $"Invalid Session";
            }

            userSessionEntity.LogoutTime = DateTime.Now;
            try
            {
                await _context.SaveChangesAsync();
                return $"Logout successfull";
            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<string> UnlockUser(Guid userId)
        {
            var userEntity = await _context.TblUsers.FirstOrDefaultAsync(m => m.Id == userId).ConfigureAwait(false);
            if (userEntity == null)
            {
                return $"Invalid Request";
            }
            else if (!userEntity.IsLocked)
            {
                return $"User account is already unlocked";
            }

            userEntity.IsLocked = false;
            userEntity.FailedLoginAttemptCount = 0;

            try
            {
                await _context.SaveChangesAsync();
                return $"Account unlocked";
            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<User?> UserByUserNameAsync(UserNameRequest request)
        {
            var userEntity = await _context.TblUsers.FirstOrDefaultAsync(m => m.UserName == request.UserName);
            return userEntity == null ? null : new User
            {
                Id = userEntity.Id,
                UserName = userEntity.UserName,
                FullName = userEntity.FullName,
                Mobile = userEntity.Mobile,
                Email = userEntity.Email,
                RoleId = userEntity.RoleId,
                MappingId = userEntity.MappingId,
                IsActive = userEntity.IsActive,
            };
        }

        public async Task<LoginResponse> UserOtpCreationAsync(Guid id)
        {
            var userEntity = await _context.TblUsers.FirstOrDefaultAsync(m => m.Id == id);
            var rawToken = OtpGenerator.Generate(16, true);
            var userSessionEntity = new TblUserSession
            {
                Id = Guid.NewGuid(),
                UserId = id,
                VerificationMobile = userEntity.Mobile,
                VerificationOtp = string.IsNullOrEmpty(userEntity.Mobile) ? "000000" : "000000" /*OtpGenerator.Generate(6, false)*/,
                OtpGenerationTime = DateTime.Now,
                OtpExpirationTime = DateTime.Now.AddMinutes(3),
                IsOtpVerified = false,
                VerificationToken = rawToken
            };

            try
            {
                _context.TblUserSessions.Add(userSessionEntity);
                await _context.SaveChangesAsync();

                //if (!string.IsNullOrEmpty(userEntity.Mobile))
                //{
                //    var templateId = "1107169296361598486";
                //    var msg = "One Time Password for your login is " + userSessionEntity.VerificationOtp + ". Please use the OTP to complete the login. Please do not share this with anyone -Farm Management WBFPIH";
                //    var res = await _smsService.SendSMS(userEntity.Mobile, templateId, msg);

                //    //var res = await _smsService.SendOTP(userEntity.Mobile, userSessionEntity.VerificationOtp);
                //}
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return new LoginResponse { VerifyToken = "S" + rawToken };

        }

        public async Task<LoginResponse?> ResendOTPAsync(string vToken)
        {
            var actualToken = vToken[1..];
            var userSessionEntity = await _context.TblUserSessions.FirstOrDefaultAsync(m => m.VerificationToken.Equals(actualToken)).ConfigureAwait(false);
            if (userSessionEntity == null)
            {
                return null;
            }

            var userEntity = await _context.TblUsers.Include(m => m.Role).FirstOrDefaultAsync(m => m.Id == userSessionEntity.UserId).ConfigureAwait(false);
            if (userEntity == null)
            {
                return null;
            }

            var rawToken = OtpGenerator.Generate(16, true);

            var tblUserSesssion = new TblUserSession
            {
                Id = Guid.NewGuid(),
                UserId = userEntity.Id,
                VerificationMobile = userEntity.Mobile,
                VerificationOtp = string.IsNullOrEmpty(userEntity.Mobile) ? "000000" : "000000" /*OtpGenerator.Generate(6, false)*/,
                OtpGenerationTime = DateTime.Now,
                OtpExpirationTime = DateTime.Now.AddMinutes(5),
                IsOtpVerified = false,
                VerificationToken = rawToken
            };


            try
            {
                _context.TblUserSessions.Add(tblUserSesssion);
                await _context.SaveChangesAsync();

                //if (!string.IsNullOrEmpty(userEntity.Mobile))
                //{
                //    var templateId = "1107169296361598486";
                //    var msg = "One Time Password for your login is " + tblUserSesssion.VerificationOtp + ". Please use the OTP to complete the login. Please do not share this with anyone -Farm Management WBFPIH";
                //    var res = await _smsService.SendSMS(userEntity.Mobile, templateId, msg);

                //    //var res = await _smsService.SendOTP(userEntity.Mobile, tblUserSesssion.VerificationOtp);
                //}

                return new LoginResponse { VerifyToken = "S" + rawToken };
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<LoginResponse> ValidateAsync(LoginRequest loginRequest, int sessionMinutes)
        {

            var captchaEntity = await _context.TblCaptchas.FirstOrDefaultAsync(m => m.Id == loginRequest.CaptchaId) ?? throw new Exception("Captcha validation error, please retry");

            if (!captchaEntity.Captcha.Equals(loginRequest.Captcha))
            {
                throw new Exception("Invalid Captcha");
            }

            try
            {
                loginRequest.Password = await DecryptPassword(loginRequest.Password);
            }
            catch
            {
                throw new Exception("Something went wrong ! please try again.");
            }

            var user = await _context.TblUsers.Include(m => m.TblUserSessions).Include(m => m.Role).Where(m => m.UserName.Equals(loginRequest.UserName)).FirstOrDefaultAsync() ?? throw new InvalidOperationException("User not found");


            var salt = user.Password.Substring(0, user.Password.IndexOf("~"));
            var hashed = user.Password.Substring(user.Password.IndexOf("~") + 1);
            var rawToken = OtpGenerator.Generate(16, true);

            string AuthToken = string.Empty;
            try
            {
                if (user.IsLocked)
                {
                    throw new Exception("Your account has been locked, please contact admin to unlock the same.");
                }

                if (!user.IsActive)
                {
                    throw new Exception("User is inactive. Please ask administrator to activate the user.");
                }

                if (!PBKDF2Crypto.Validate(loginRequest.Password, salt, hashed))
                {
                    user.FailedLoginAttemptCount++;
                    string returnMessage = string.Empty;

                    if (user.Role.Alias != "ADMIN")
                    {

                        if (user.FailedLoginAttemptCount == 1)
                        {
                            returnMessage = "Invalid password, you have 2 attempts left.";
                        }
                        else if (user.FailedLoginAttemptCount == 2)
                        {
                            returnMessage = "Invalid password, you have 1 attempt left."; ;
                        }
                        else
                        {
                            if (user.FailedLoginAttemptCount == 3)
                            {
                                user.IsLocked = true;
                                returnMessage = "Your account has been locked due to 3 failed attempts, please contact admin to unlock the same.";
                            }
                        }

                        try
                        {
                            await _context.SaveChangesAsync();
                        }
                        catch (Exception e)
                        {
                            throw;
                        }
                    }
                    else
                    {
                        returnMessage = "Invalid password"; ;
                    }

                    throw new Exception(string.Format(returnMessage));

                }

                //AuthToken = JwtBuilder.BuildToken(user.FullName, user.UserName, user.Id, user.RoleId, user.Role.Name, user.Role.Alias, jwtCredentials.JwtIssuer, jwtCredentials.JwtKey, TokenValidHours);

                //user.FailedLoginAttemptCount = 0;

                //return new LoginResponse { AccessToken = AuthToken, UserId = user.Id, UserName = user.FullName, RoleName = user.Role.Name   };

                var anyExistingOpenSession = user.TblUserSessions.FirstOrDefault(x => x.LogoutTime == null && x.LoginTime != null && (DateTime.Now - x.LoginTime.Value).TotalMinutes < sessionMinutes);

                if (anyExistingOpenSession != null && user.Role.Alias != "ADMIN")
                {
                    throw new Exception("You already have an active session, please logout or wait for next few minutes or ask admin to close your active session");
                }

                var userSessionEntity = new TblUserSession
                {
                    Id = Guid.NewGuid(),
                    UserId = user.Id,
                    VerificationMobile = user.Mobile,
                    VerificationOtp = string.IsNullOrEmpty(user.Mobile) ? "000000" : "000000"/*OtpGenerator.Generate(6, false)*/,
                    OtpGenerationTime = DateTime.Now,
                    OtpExpirationTime = DateTime.Now.AddMinutes(5),
                    IsOtpVerified = false,
                    VerificationToken = rawToken
                };
                _context.TblUserSessions.Add(userSessionEntity);
                await _context.SaveChangesAsync();

                user.FailedLoginAttemptCount = 0;

                if (!string.IsNullOrEmpty(user.Mobile))
                {

                    //var templateId = "1107169296361598486";
                    //var msg = "One Time Password for your login is " + userSessionEntity.VerificationOtp + ". Please use the OTP to complete the login. Please do not share this with anyone -Farm Management WBFPIH";
                    //var res = await _smsService.SendSMS(user.Mobile, templateId, msg);

                    //var res = await _smsService.SendOTP(user.Mobile, userSessionEntity.VerificationOtp);
                }
            }
            catch
            {
                throw;
            }
            return new LoginResponse
            {
                VerifyToken = "S" + rawToken
            };
        }


        public async Task<string?> HasAnySession(Guid userId, int sessionMinutes)
        {
            try
            {
                var user = await _context.TblUsers.Include(m => m.TblUserSessions).Include(m => m.Role).Where(m => m.Id == userId).FirstOrDefaultAsync() ?? throw new InvalidOperationException("User not found");

                var anyExistingOpenSession = user.TblUserSessions.FirstOrDefault(x => x.LogoutTime == null && x.LoginTime != null && (DateTime.Now - x.LoginTime.Value).TotalMinutes < sessionMinutes);

                if (anyExistingOpenSession != null && user.Role.Alias != "ADMIN")
                {
                    throw new Exception("You already have an active session, please logout or wait for next few minutes or ask admin to close your active session");
                }
                return "ok";
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public async Task<VerificationResponse> VerifyAsync(VerificationRequest verificationRequest, JwtCred jwtCredentials, int TokenValidHours)
        {
            var actualToken = verificationRequest.VerifyToken[1..];
            var userSessionEntity = await _context.TblUserSessions.FirstOrDefaultAsync(m => m.VerificationToken.Equals(actualToken) && m.VerificationOtp.Equals(verificationRequest.Otp) && m.OtpExpirationTime > DateTime.Now).ConfigureAwait(false);
            if (userSessionEntity == null)
            {
                return null;
            }

            var userEntity = await _context.TblUsers.Include(m => m.Role).FirstOrDefaultAsync(m => m.Id == userSessionEntity.UserId).ConfigureAwait(false);
            if (userEntity == null)
            {
                return null;
            }


            string AuthToken = JwtBuilder.BuildToken(userEntity.FullName, userEntity.UserName, userEntity.Id, userEntity.RoleId, userEntity.Role.Name, userEntity.Role.Alias, jwtCredentials.JwtIssuer, jwtCredentials.JwtKey, TokenValidHours);

            userSessionEntity.LoginTime = DateTime.Now;
            userSessionEntity.AuthToken = AuthToken;
            userSessionEntity.IsOtpVerified = true;
            userEntity.FailedLoginAttemptCount = 0;

            try
            {
                await _context.SaveChangesAsync();
                return new VerificationResponse
                {
                    AuthToken = AuthToken
                };
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task<ForgotPasswordResponse> VerifyOTPAsync(VerificationRequest verificationRequest, JwtCred jwtCredentials, int TokenValidHours)
        {
            var response = new ForgotPasswordResponse();

            var actualToken = verificationRequest.VerifyToken[1..];
            var userSessionEntity = await _context.TblUserSessions.FirstOrDefaultAsync(m => m.VerificationToken.Equals(actualToken) && m.VerificationOtp.Equals(verificationRequest.Otp) && m.OtpExpirationTime > DateTime.Now).ConfigureAwait(false);
            if (userSessionEntity == null)
            {
                response.Status = false;
                return response;
            }

            var userEntity = await _context.TblUsers.Include(m => m.Role).FirstOrDefaultAsync(m => m.Id == userSessionEntity.UserId).ConfigureAwait(false);
            if (userEntity == null)
            {
                response.Status = false;
                return response;
            }

            userSessionEntity.IsOtpVerified = true;

            try
            {
                await _context.SaveChangesAsync();
                response.UserId = userEntity.Id;
                response.Status = true;

                return response;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public async Task<string> ResetPasswordAsync(ResetPassword resetPassword)
        {
            var userEntity = await _context.TblUsers.FirstOrDefaultAsync(m => m.Id == resetPassword.UserId && m.IsActive).ConfigureAwait(false);
            if (userEntity == null)
            {
                return $"No User found";
            }
            if (resetPassword.NewPassword != resetPassword.ConfirmPassword)
            {
                return $"New Password does not match with Confirm Password.";
            }

            var salt = userEntity.Password.Substring(0, userEntity.Password.IndexOf("~"));
            var hashed = userEntity.Password.Substring(userEntity.Password.IndexOf("~") + 1);


            try
            {
                var newSalt = SaltGenerator.Generate();
                userEntity.Password = newSalt + "~" + PBKDF2Crypto.Create(resetPassword.NewPassword, newSalt);

                await _context.SaveChangesAsync();
                return $"Password updated successfully";
            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<string> ChangePasswordAsync(ChangePassword model, Guid UserId)
        {
            var userEntity = await _context.TblUsers.FirstOrDefaultAsync(m => m.Id == UserId && m.IsActive).ConfigureAwait(false);
            if (userEntity == null)
            {
                return $"No User found";
            }

            if (model.NewPassword != model.ConfirmPassword)
            {
                return $"New Password does not match with Confirm Password.";
            }

            var salt = userEntity.Password.Substring(0, userEntity.Password.IndexOf("~"));
            var hashed = userEntity.Password.Substring(userEntity.Password.IndexOf("~") + 1);

            if (!PBKDF2Crypto.Validate(model.CurrentPassword.Trim(), salt, hashed))
            {
                throw new Exception("Invalid current password.");
            }

            try
            {
                var newSalt = SaltGenerator.Generate();
                userEntity.Password = newSalt + "~" + PBKDF2Crypto.Create(model.NewPassword, newSalt);

                await _context.SaveChangesAsync();
                return $"Password changed successfully";
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<Captcha> GenerateCaptcha()
        {
            var captchaEntity = new TblCaptcha
            {
                Id = Guid.NewGuid(),
                Captcha = OtpGenerator.Generate(5, true)
            };

            try
            {
                _context.TblCaptchas.Add(captchaEntity);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw;
            }

            return new Captcha { Id = captchaEntity.Id, CaptchaCode = captchaEntity.Captcha };
        }

        public async Task<Captcha> ReGenerateCaptcha(Guid Id)
        {
            var captchaEntity = await _context.TblCaptchas.FirstOrDefaultAsync(m => m.Id == Id) ?? throw new Exception("Captcha not found");

            captchaEntity.Captcha = OtpGenerator.Generate(5, true);

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw;
            }


            return new Captcha { Id = captchaEntity.Id, CaptchaCode = captchaEntity.Captcha };
        }
        public async Task<string> DecryptPassword(string cipherText)
        {
            var keybytes = Encoding.UTF8.GetBytes("4512631236589784");
            var iv = Encoding.UTF8.GetBytes("4512631236589784");

            var encrypted = Convert.FromBase64String(cipherText);
            var decriptedFromJavascript = DecryptStringFromBytes(encrypted, keybytes, iv);
            return JsonConvert.DeserializeObject(decriptedFromJavascript).ToString();
        }
        private static string DecryptStringFromBytes(byte[] cipherText, byte[] key, byte[] iv)
        {

            string plaintext = null;
            using (var rijAlg = new RijndaelManaged())
            {
                rijAlg.Mode = CipherMode.CBC;
                rijAlg.Padding = PaddingMode.PKCS7;
                rijAlg.FeedbackSize = 128;

                rijAlg.Key = key;
                rijAlg.IV = iv;

                var decryptor = rijAlg.CreateDecryptor(rijAlg.Key, rijAlg.IV);

                try
                {
                    var msDecrypt = new MemoryStream(cipherText);
                    var csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read);
                    var srDecrypt = new StreamReader(csDecrypt);
                    plaintext = srDecrypt.ReadToEnd();
                }
                catch
                {
                    throw;
                }
            }

            return plaintext;
        }
        #endregion



    }
}
