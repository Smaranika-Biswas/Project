﻿using MailKit.Net.Smtp;
using MimeKit;
using System.Text;
using PeirLoanSystem.Data.Models;


namespace PeirLoanSystem.Data.Repositories
{
    public interface IEmailService
    {
        Task<bool> SendMail(StringBuilder body, string subject, EmailConfiguration _mailConfig);
        Task<bool> SendMailToMultipleUser(StringBuilder body, string subject, EmailConfiguration _mailConfig, List<string> ToEmail);
    }
    public class EmailService : IEmailService
    {
       
        public EmailService()
        {
            ;
        }

        public async Task<bool> SendMail(StringBuilder body, string subject, EmailConfiguration _mailConfig)
        {
            var emailMessage = new MimeMessage();

            emailMessage.From.Add(new MailboxAddress("PEIR", _mailConfig.From));
            emailMessage.To.Add(new MailboxAddress("ToUser", _mailConfig.ToMail));

            var bodyBuilder = new BodyBuilder();
            bodyBuilder.HtmlBody = body.ToString();
            
            emailMessage.Subject = subject;
            emailMessage.Body = bodyBuilder.ToMessageBody();
           
            using (var client = new SmtpClient())
            {
                try
                {
                    await client.ConnectAsync(_mailConfig.SmtpServer, _mailConfig.Port, MailKit.Security.SecureSocketOptions.StartTls);
                    client.AuthenticationMechanisms.Remove("XOAUTH2");
                    await client.AuthenticateAsync(_mailConfig.UserName, _mailConfig.Password);

                    await client.SendAsync(emailMessage);
                }
                catch
                {
                    return false;
                    throw;
                }
                finally
                {
                    await client.DisconnectAsync(true);
                    client.Dispose();
                }
            }
            return true;
        }

        public async Task<bool> SendMailToMultipleUser(StringBuilder body, string subject, EmailConfiguration _mailConfig, List<string>? ToEmail)
        {
            var emailMessage = new MimeMessage();

            emailMessage.From.Add(new MailboxAddress("PEIR", _mailConfig.From));

            foreach (var email in ToEmail)
            {
                emailMessage.To.Add(new MailboxAddress("ToUser", email));
            }
            var bodyBuilder = new BodyBuilder();
            bodyBuilder.HtmlBody = body.ToString();

            emailMessage.Subject = subject;
            emailMessage.Body = bodyBuilder.ToMessageBody();

            using (var client = new SmtpClient())
            {
                try
                {
                    await client.ConnectAsync(_mailConfig.SmtpServer, _mailConfig.Port, MailKit.Security.SecureSocketOptions.StartTls);
                    client.AuthenticationMechanisms.Remove("XOAUTH2");
                    await client.AuthenticateAsync(_mailConfig.UserName, _mailConfig.Password);

                    await client.SendAsync(emailMessage);
                }
                catch
                {
                    return false;
                    throw;
                }
                finally
                {
                    await client.DisconnectAsync(true);
                    client.Dispose();
                }
            }
            return true;
        }

    }
}
