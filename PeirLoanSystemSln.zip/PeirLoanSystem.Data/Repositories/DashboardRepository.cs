﻿
using PeirLoanSystem.Data.Entities;
using PeirLoanSystem.Data.Models;
using PeirLoanSystem.Data.ViewModels;
using Microsoft.EntityFrameworkCore;
using System.Globalization;


namespace PeirLoanSystem.Data.Repositories
{
    public interface IDashboardRepository
    {
        Task<Dashboard> GetDashboard(Guid UserId);
    }

    public class DashboardRepository : IDashboardRepository
    {
        public readonly PeirloanDataContext _context;

        public DashboardRepository(PeirloanDataContext context)
        {
            _context = context;
        }
        public async Task<Dashboard> GetDashboard(Guid UserId)
        {
            var userEntity = await _context.TblUsers.Include(m => m.Role).FirstOrDefaultAsync(m => m.Id == UserId).ConfigureAwait(false);

            var dashboard = new Dashboard();

            var loaneeEntities = await _context.TblLoanees.Include(m => m.TblLoans).ThenInclude(m => m.TblRepayments).ToListAsync().ConfigureAwait(false);

            if(userEntity != null && userEntity.Role.Alias == "VENDOR" && userEntity.MappingId != null)
            {
                loaneeEntities = loaneeEntities.Where(m => m.Id == userEntity.MappingId).ToList();
            }

            var loanEntities = loaneeEntities.SelectMany(m => m.TblLoans).ToList();
            var paymentEntities = loanEntities.SelectMany(m => m.TblRepayments).ToList();

            dashboard.CountOfLoanee = loaneeEntities.Count;
            dashboard.CountOfLoans = loanEntities.Count;
            dashboard.TotalLoanAmount = loanEntities.Select(m => m.LoanAmount).Sum();
            dashboard.PaymentReceived = paymentEntities.Select(m => m.PrincipalPaid + m.InterestPaid).Sum();

            decimal InterestAsOfNow = paymentEntities.Select(m => m.InterestDue).Sum();

            foreach (var loanEntity in loanEntities)
            {
                var lastPaymentDate = loanEntity.TblRepayments.Any() ? loanEntity.TblRepayments.OrderByDescending(m => m.RepaymentDate).FirstOrDefault().RepaymentDate : loanEntity.DisbursedDate;
                var principal = loanEntity.LoanAmount - (loanEntity.TblRepayments.Any() ? loanEntity.TblRepayments.Select(a => a.PrincipalPaid).Sum() : 0);

                decimal applicableInterestRate = 0;

                if (!loanEntity.IsDefaulter)
                {
                    int countOfPayments = 1;

                    countOfPayments += loanEntity.TblRepayments.Count();

                    DateOnly dtExpecetedPaymentDate = loanEntity.DisbursedDate.AddYears(countOfPayments);
                    dtExpecetedPaymentDate = dtExpecetedPaymentDate.AddDays(1 - dtExpecetedPaymentDate.Day).AddMonths(1).AddDays(-1);

                    if (DateOnly.FromDateTime(DateTime.Now) > dtExpecetedPaymentDate)
                    {
                        applicableInterestRate = loanEntity.InterestRate;
                    }
                    else
                    {
                        applicableInterestRate = loanEntity.InterestRate - loanEntity.RebateInterest;
                    }
                }
                else
                {
                    applicableInterestRate = loanEntity.InterestRate;
                }

                InterestAsOfNow += ((principal * (applicableInterestRate / 100)) / 365) * ((DateOnly.FromDateTime(DateTime.Now).DayNumber - lastPaymentDate.DayNumber) + 1);
            }

            dashboard.TotalDueAmount = Math.Round(loanEntities.Select(m => m.LoanAmount).Sum() + InterestAsOfNow - paymentEntities.Select(a => a.PrincipalPaid + a.InterestPaid).Sum(), 2);
            dashboard.TotalPrincipalDue = Math.Round(loanEntities.Select(m => m.LoanAmount).Sum() - paymentEntities.Select(a => a.PrincipalPaid).Sum(), 2); ;
            dashboard.TotalInterestDue = Math.Round(InterestAsOfNow - paymentEntities.Select(a => a.InterestPaid).Sum(), 2); 

            dashboard.LoaneeCategories = loaneeEntities.GroupBy(m => m.Catgeory).Select(a => new Category
            {
                Name = a.Key,
                Count = a.Count()
            }).ToList();

            dashboard.LoanCategories = loaneeEntities.GroupBy(m => m.Catgeory).Select(a => new AmountModel
            {
                Name = a.Key,
                Amount = a.Select(k => k.TblLoans.Select(loan => loan.LoanAmount).Sum()).Sum()
            }).ToList();

            var paymentCategories = new List<AmountModel>();

            paymentCategories.Add(new AmountModel
            {
                Name = "Principal Amount",
                Amount = paymentEntities.Select(m => m.PrincipalPaid).Sum()
            });

            paymentCategories.Add(new AmountModel
            {
                Name = "Interest Amount",
                Amount = paymentEntities.Select(m => m.InterestPaid).Sum()
            });

            dashboard.PaymentCategories = paymentCategories;

            var loanStatusCategories = new List<Category>();

            loanStatusCategories.Add(new Category
            {
                Name = "Active",
                Count = loanEntities.Where(m => !m.IsClosed && !m.IsWaived && !m.IsNclt).Count()
            });

            loanStatusCategories.Add(new Category
            {
                Name = "Closed",
                Count = loanEntities.Where(m => m.IsClosed).Count()
            });

            loanStatusCategories.Add(new Category
            {
                Name = "Waived",
                Count = loanEntities.Where(m => m.IsWaived).Count()
            });
            loanStatusCategories.Add(new Category
            {
                Name = "NCLT",
                Count = loanEntities.Where(m => m.IsNclt).Count()
            });

            dashboard.LoanStatusCategories = loanStatusCategories;
            return dashboard;
        }
    }
}
