﻿
using PeirLoanSystem.Data.Entities;
using PeirLoanSystem.Data.Models;
using PeirLoanSystem.Data.ViewModels;
using Microsoft.EntityFrameworkCore;
using System.Globalization;
using static System.Runtime.InteropServices.JavaScript.JSType;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Text;
using Microsoft.Extensions.Configuration;
using PeirLoanSystem.Data.Repositories;

namespace PeirLoanSystem.Data.Repositories
{
    #region --- Interface : ILoanRepository ---
    public interface ILoanRepository
    {
        Task<string> CreateAsync(Loan data, Guid UserId);
        Task<string> UpdateAsync(Loan data, Guid UserId);
        Task<Loan> GetAsync(Guid id);
        Task<Payment> GetPaymentById(Guid id);
        Task<FilterResult<Loan>> FilterAsync(LoanFilterParam filterParam, Guid UserId);
        Task<Loan> GetAllPaymentByLoan(Guid LoanId);
        Task<string> ReceivePayment(Payment data, Guid UserId, string HtmlPath);
        Task<bool> DeleteDocument(Guid id);
        Task<FilterResult<Payment>> FilterPaymentAsync(PaymentFilterParam filterParam, Guid UserId);
        Task<string> ValidatePayment(ValidatePayment model, Guid UserId, string HtmlPath);
        Task<string> UpdatePayment(Payment data, Guid UserId);
        Task<string> UpdateLoanStatus(LoanStatusUpdate model, Guid UserId);
        Task<InterestInfoModel> CalculateInterest(InterestModel model);
        Task<List<AmmoritizationSchedule>> GenerateAmmoritizationSchedule(Guid LoanId);
        Task<string> UpdateAccountHead(ChangeAccountHead model, Guid UserId);
    }
    #endregion

    #region --- Class : LoaneeRepository ---
    public class LoanRepository : ILoanRepository
    {
        public readonly PeirloanDataContext _context;
        private readonly IConfiguration _configuration;
        private readonly IEmailService _emailService;
        public LoanRepository(PeirloanDataContext context, IConfiguration configuration, IEmailService emailService)
        {
            _context = context;
            _configuration = configuration;
            _emailService = emailService;
        }

        public async Task<string> CreateAsync(Loan data, Guid UserId)
        {
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data), string.Format("{0} is null", nameof(data)));
            }
            var existingEntity = await _context.TblLoans.FirstOrDefaultAsync(m => m.LoaneeId == data.LoaneeId && m.SanctionNo.Trim().ToLower().Equals(data.SanctionNo.Trim().ToLower())).ConfigureAwait(false);

            if (existingEntity != null)
            {
                throw new Exception(string.Format("Loan with sanction no. {0} already exists" + data.SanctionNo));
            }


            var loanEntity = new TblLoan
            {
                Id = Guid.NewGuid(),
                LoaneeId = data.LoaneeId,
                SanctionNo = data.SanctionNo,
                AccountHead = data.AccountHead,
                DisbursedDate = data.DisbursedDate,
                InterestRate = data.InterestRate,
                CreatedBy = UserId,
                CreatedOn = DateTime.Now,
                LoanAmount = data.LoanAmount,
                LoanTenure = data.LoanTenure,
                MoratoriumPeriod = data.MoratoriumPeriod,
                RebateInterest = data.RebateInterest,
            };

            if (data.Documents != null && data.Documents.Any())
            {
                foreach (var doc in data.Documents)
                {
                    loanEntity.TblLoaneeDocuments.Add(new TblLoaneeDocument
                    {
                        Id = Guid.NewGuid(),
                        LoaneeId = loanEntity.LoaneeId,
                        LoanId = loanEntity.Id,
                        DocumentTypeId = doc.DocumentTypeId,
                        SubDocumentTypeId = doc.SubDocumentTypeId != Guid.Empty ? doc.SubDocumentTypeId : null,
                        DocFileName = doc.DocFileName,
                        DocFileSeq = doc.DocFileSeq,
                        UploadedBy = UserId,
                        UploadedOn = DateTime.Now
                    });
                }

            }

            var loaneeEntity = await _context.TblLoanees.FirstOrDefaultAsync(m => m.Id == data.LoaneeId).ConfigureAwait(false);

            var notificationEntity = new TblNotification
            {
                Id = Guid.NewGuid(),
                Subject = string.Format("New Loan"),
                Description = string.Format("New Loan account with sanction no {0} for the loanee company {1} of Rs.{2} has been created on {3}", loanEntity.SanctionNo, loaneeEntity.Name, loanEntity.LoanAmount, DateTime.Now.ToString("dd-MMM-yyyy")),
                NotificationDate = DateTime.Now,
                IsActive = true,
                
            };

            var userEntites = await _context.TblUsers.Include(m => m.Role).Where(m => m.Id != UserId && (m.Role.Alias != "VENDOR" || m.MappingId == data.LoaneeId)).ToListAsync().ConfigureAwait(false);

            userEntites.ForEach((m) =>
            {
                notificationEntity.TblNotificationUsers.Add(new TblNotificationUser
                {
                    Id = Guid.NewGuid(),
                    UserId = m.Id,
                    IsSeen = false,
                    NotificationId = notificationEntity.Id,
                    Route = m.Role.Alias == "ADMIN" || m.Role.Alias == "AG" ? "/secure/master/loan-master" : "",
                });
            });

            try
            {
                _context.TblLoans.Add(loanEntity);
                _context.TblNotifications.Add(notificationEntity);
                await _context.SaveChangesAsync().ConfigureAwait(false);
                return string.Format(CultureInfo.InvariantCulture, "{0} with sanction no. {1} added successfully", nameof(data), data.SanctionNo);
            }
            catch
            {
                throw;
            }
        }

        public async Task<string> UpdateAsync(Loan data, Guid UserId)
        {
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data), string.Format("{0} is null", nameof(data)));
            }
            var existingEntity = await _context.TblLoans.Include(m => m.TblRepayments).FirstOrDefaultAsync(m => m.Id != data.Id && m.LoaneeId == data.LoaneeId && m.SanctionNo.Trim().ToLower().Equals(data.SanctionNo.Trim().ToLower())).ConfigureAwait(false);

            if (existingEntity != null)
            {
                throw new Exception(string.Format("Loan with sanction no. {0} already exists" + data.SanctionNo));
            }

            //var repaymentEntity = await _context.TblRepayments.FirstOrDefaultAsync(m => m.LoanId == data.Id).ConfigureAwait(false);

            if (existingEntity != null)
            {
                throw new Exception(string.Format("Loan cant be edited as payment has already been received"));
            }

            var loanEntity = await _context.TblLoans.Include(m => m.TblRepayments).FirstOrDefaultAsync(m => m.Id == data.Id).ConfigureAwait(false) ?? throw new Exception(string.Format("No loan found"));
          
            if (loanEntity.IsClosed)
            {
                throw new Exception(string.Format("Loan is already closed"));
            }
            if (loanEntity.IsWaived)
            {
                throw new Exception(string.Format("Loan is already waived off"));
            }
            if (loanEntity.IsClosed)
            {
                throw new Exception(string.Format("Loan is already marked as NCLT"));
            }

            if(loanEntity.TblRepayments == null || loanEntity.TblRepayments.Count == 0)
            {
                loanEntity.InterestRate = data.InterestRate;
                loanEntity.LoanAmount = data.LoanAmount;
                loanEntity.SanctionNo = data.SanctionNo;
                loanEntity.MoratoriumPeriod = data.MoratoriumPeriod;
                loanEntity.RebateInterest = data.RebateInterest;
                loanEntity.DisbursedDate = data.DisbursedDate;
            }
        
            loanEntity.AccountHead = data.AccountHead;          
            loanEntity.LastModifiedBy = UserId;
            loanEntity.LastModifiedOn = DateTime.Now;          
            loanEntity.LoanTenure = data.LoanTenure;

           

            var loanDocumentEntities = new List<TblLoaneeDocument>();

            if (data.Documents != null && data.Documents.Any())
            {
                foreach (var doc in data.Documents)
                {
                    loanDocumentEntities.Add(new TblLoaneeDocument
                    {
                        Id = Guid.NewGuid(),
                        LoaneeId = loanEntity.LoaneeId,
                        LoanId = loanEntity.Id,
                        DocumentTypeId = doc.DocumentTypeId,
                        SubDocumentTypeId = doc.SubDocumentTypeId != Guid.Empty ? doc.SubDocumentTypeId : null,
                        DocFileName = doc.DocFileName,
                        DocFileSeq = doc.DocFileSeq,
                        UploadedBy = UserId,
                        UploadedOn = DateTime.Now
                    });
                }
            }

            try
            {
                _context.TblLoaneeDocuments.AddRange(loanDocumentEntities);
                await _context.SaveChangesAsync().ConfigureAwait(false);
                return string.Format(CultureInfo.InvariantCulture, "{0} with sanction no. {1} updated successfully", nameof(data), data.SanctionNo);
            }
            catch
            {
                throw;
            }
        }

        public async Task<List<AmmoritizationSchedule>> GenerateAmmoritizationSchedule(Guid LoanId)
        {
            var dt = new DataTable();
            var ammoritizationScheduleList = new List<AmmoritizationSchedule>();

            try
            {
                var sqlConnection = (Microsoft.Data.SqlClient.SqlConnection)_context.Database.GetDbConnection();
                SqlCommand cmd = new SqlCommand("SP_LoanAmmortizationSchedule", sqlConnection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@LoanId", SqlDbType.UniqueIdentifier) { Value = LoanId });
                DataSet ds = new();

                using SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
                dataAdapter.SelectCommand = cmd;
                dataAdapter.Fill(ds);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    ammoritizationScheduleList = ds.Tables[0].AsEnumerable()
                           .Select(r => new AmmoritizationSchedule
                           {
                               Id = r["Id"] != null ? int.Parse(r["Id"].ToString()) : 0,
                               InterestAmount = r["InterestAmount"] != null ? decimal.Parse(r["InterestAmount"].ToString()) : 0,
                               OutStandingAmount = r["OutstandingAmount"] != null ? decimal.Parse(r["OutstandingAmount"].ToString()) : 0,
                               InterestRate = r["InterestRate"] != null ? decimal.Parse(r["InterestRate"].ToString()) : 0,
                               PaymentDate = r["PaymentDate"] != null ? r["PaymentDate"].ToString() : "",
                               PrincipalAmount = r["PrincipalAmount"] != null ? decimal.Parse(r["PrincipalAmount"].ToString()) : 0
                           }).ToList();
                }
            }
            catch(Exception ex)
            {
                ;
            }          

            return ammoritizationScheduleList;

        }
        public async Task<Loan> GetAsync(Guid id)
        {
            try
            {
                var loaneEntity = await _context.TblLoans.Include(m => m.Loanee).Include(m => m.TblRepayments).Include(m => m.TblLoaneeDocuments).ThenInclude(m => m.DocumentType).Include(m => m.TblLoaneeDocuments).ThenInclude(m => m.SubDocumentType).FirstOrDefaultAsync(m => m.Id == id) ?? throw new Exception("No record found !");

                return new Loan
                {
                    Id = loaneEntity.Id,
                    LoaneeId = loaneEntity.LoaneeId,
                    LoaneeName = loaneEntity.Loanee.Name,
                    SanctionNo = loaneEntity.SanctionNo,
                    AccountHead = loaneEntity.AccountHead,
                    DisbursedDate = loaneEntity.DisbursedDate,
                    InterestRate = loaneEntity.InterestRate,
                    LoanAmount = loaneEntity.LoanAmount,
                    LoanTenure = loaneEntity.LoanTenure,
                    MoratoriumPeriod = loaneEntity.MoratoriumPeriod,
                    RebateInterest = loaneEntity.RebateInterest,
                    IsWaived = loaneEntity.IsWaived,
                    IsNclt = loaneEntity.IsNclt,
                    IsClosed = loaneEntity.IsClosed,
                    Status = loaneEntity.IsClosed ? "Closed" : loaneEntity.IsWaived ? "Waived" : loaneEntity.IsNclt ? "NCLT" : "",
                    Documents = loaneEntity.TblLoaneeDocuments.Where(a => a.LoanId != null && a.LoanId == loaneEntity.Id).Select(m => new LoanDocument
                    {
                        Id = m.Id,
                        DocFileName = m.DocFileName,
                        DocFileSeq = m.DocFileSeq,
                        DocumentTypeId = m.DocumentTypeId,
                        SubDocumentTypeId = m.SubDocumentTypeId,
                        DocumentTypeName = m.DocumentType.Name,
                        SubDocumentTypeName = m.SubDocumentType?.Name
                    }).ToList(),
                };
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Payment> GetPaymentById(Guid id)
        {
            try
            {
                var paymentEntity = await _context.TblRepayments.FirstOrDefaultAsync(m => m.Id == id) ?? throw new Exception("No record found !");

                return new Payment
                {
                    Id = paymentEntity.Id,
                    AccountHead = paymentEntity.AccountHead,
                    RepaymentDate = paymentEntity.RepaymentDate,
                    LoanId = paymentEntity.LoanId,
                    VendorNote = paymentEntity.VendorNote,
                    ChallanFileName = paymentEntity.ChallanFileName,
                    ChallanFileNo = paymentEntity.ChallanFileNo,
                    InterestPaid = paymentEntity.InterestPaid,
                    PrincipalPaid = paymentEntity.PrincipalPaid
                };
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> DeleteDocument(Guid id)
        {
            try
            {
                var documentEntity = await _context.TblLoaneeDocuments.Include(m => m.Loan).ThenInclude(m => m.TblRepayments).Include(m => m.Loanee).ThenInclude(m => m.TblLoans).FirstOrDefaultAsync(m => m.Id == id) ?? throw new Exception("No record found !");

                if(documentEntity.Loan != null)
                {
                    if(documentEntity.Loan.TblRepayments.Any())
                    {
                        throw new Exception("Loan document cant be deleted as payment has already been received");
                    }                    
                }
                else if(documentEntity.Loanee != null && documentEntity.Loanee.TblLoans.Any())
                {
                    throw new Exception("Loanee document cant be deleted as loan has already been sanctioned");
                }

                _context.TblLoaneeDocuments.Remove(documentEntity);
                await _context.SaveChangesAsync();
                return true;

            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<FilterResult<Loan>> FilterAsync(LoanFilterParam filterParam, Guid UserId)
        {
            try
            {
                if (filterParam == null) return new FilterResult<Loan>();
                var userEntity = await _context.TblUsers.Include(m => m.Role).FirstOrDefaultAsync(m => m.Id == UserId);

                var skipCount = (filterParam.PageIndex - 1) * filterParam.PageSize;
                var filterEntitiesQuery = _context.TblLoans.Include(m => m.Loanee).Include(m => m.TblRepayments).Include(m => m.TblLoaneeDocuments).ThenInclude(m => m.DocumentType).Include(m => m.TblLoaneeDocuments).ThenInclude(m => m.SubDocumentType).AsNoTracking().AsQueryable();

                if (!string.IsNullOrEmpty(filterParam.FilterText))
                {
                    filterEntitiesQuery = filterEntitiesQuery.Where(m => m.Loanee.Name.ToLower().Contains(filterParam.FilterText.Trim().ToLower())
                                          || m.SanctionNo.ToLower().Contains(filterParam.FilterText.Trim().ToLower())
                                          || m.LoanAmount.ToString().Contains(filterParam.FilterText.Trim().ToLower())
                                          || m.AccountHead.ToLower().Contains(filterParam.FilterText.Trim().ToLower()));
                }
                if (!string.IsNullOrEmpty(filterParam.Status))
                {
                    filterEntitiesQuery = filterParam.Status.ToLower() == "closed" ? filterEntitiesQuery.Where(m => m.IsClosed) 
                        : filterParam.Status.ToLower() == "waived" ? filterEntitiesQuery.Where(m => m.IsWaived) 
                        : filterParam.Status.ToLower() == "nclt" ? filterEntitiesQuery.Where(m => m.IsNclt)
                        : filterEntitiesQuery.Where(m => !m.IsClosed && !m.IsWaived && !m.IsNclt);
                }
                if (userEntity != null && userEntity.MappingId != null && userEntity.Role.Alias == "VENDOR")
                {
                    filterEntitiesQuery = filterEntitiesQuery.Where(m => m.LoaneeId == userEntity.MappingId);
                }
                if (filterParam.LoaneeId != Guid.Empty)
                {
                    filterEntitiesQuery = filterEntitiesQuery.Where(m => m.LoaneeId == filterParam.LoaneeId);
                }

                filterEntitiesQuery = (filterParam.SortOn.ToUpper()) switch
                {
                    _ => filterParam.SortDirection.ToUpper() == "DESC" ? filterEntitiesQuery.OrderByDescending(m => m.CreatedOn) : filterEntitiesQuery.OrderBy(m => m.CreatedOn),
                };

                var totalCount = await filterEntitiesQuery.CountAsync().ConfigureAwait(false);
                var filterEntities = await filterEntitiesQuery.Skip(skipCount).Take(filterParam.PageSize).ToListAsync().ConfigureAwait(false);

                return new FilterResult<Loan>
                {
                    Records = filterEntities.ConvertAll(m => new Loan
                    {
                        Id = m.Id,
                        LoaneeId = m.LoaneeId,
                        LoaneeName = m.Loanee.Name,
                        SanctionNo = m.SanctionNo,
                        AccountHead = m.AccountHead,
                        DisbursedDate = m.DisbursedDate,
                        InterestRate = m.InterestRate,
                        LoanAmount = m.LoanAmount,
                        LoanTenure = m.LoanTenure,
                        MoratoriumPeriod = m.MoratoriumPeriod,
                        RebateInterest = m.RebateInterest,
                        PrincipalPaidAsOfNow = m.TblRepayments.Select(a => a.PrincipalPaid).Sum(),
                        InterestPaidAsOfNow = m.TblRepayments.Select(a => a.InterestPaid).Sum(),
                        OutStandingAsOfNow = CalculateOutStandingAmount(m),
                        IsClosed = m.IsClosed,
                        IsNclt = m.IsNclt,
                        IsWaived = m.IsWaived,
                        Status = m.IsClosed ? "Closed" : m.IsWaived ? "Waived" : m.IsNclt ? "NCLT" : null,
                        Documents = m.TblLoaneeDocuments.Where(a => a.LoanId != null && a.LoanId == m.Id).Select(m => new LoanDocument
                        {
                            Id = m.Id,
                            DocFileName = m.DocFileName,
                            DocFileSeq = m.DocFileSeq,
                            DocumentTypeId = m.DocumentTypeId,
                            SubDocumentTypeId = m.SubDocumentTypeId,
                            DocumentTypeName = m.DocumentType.Name,
                            SubDocumentTypeName = m.SubDocumentType?.Name
                        }).ToList(),
                    }),
                    TotalCount = totalCount
                };
            }
            catch (Exception)
            {
                throw;
            }
        }

        private decimal CalculateOutStandingAmount(TblLoan loanEntity)
        {
            decimal OutstandingAmount = 0;

            OutstandingAmount = loanEntity.LoanAmount - loanEntity.TblRepayments.Select(m => m.PrincipalPaid + m.InterestPaid - m.InterestDue).Sum();
            bool IsDefaulter = loanEntity.IsDefaulter;

            if (!loanEntity.IsDefaulter)
            {
                int countOfPayments = 1;

                countOfPayments += loanEntity.TblRepayments.Count();

                DateOnly dtExpecetedPaymentDate = loanEntity.DisbursedDate.AddYears(countOfPayments);
                dtExpecetedPaymentDate = dtExpecetedPaymentDate.AddDays(1 - dtExpecetedPaymentDate.Day).AddMonths(1).AddDays(-1);

                IsDefaulter = DateOnly.FromDateTime(DateTime.Now) > dtExpecetedPaymentDate;
            }

            var applicableInterestRate = IsDefaulter ? loanEntity.InterestRate : loanEntity.InterestRate - loanEntity.RebateInterest;
            var interestDueDate = loanEntity.TblRepayments.Any() ? loanEntity.TblRepayments.OrderByDescending(m => m.RepaymentDate).FirstOrDefault().RepaymentDate : loanEntity.DisbursedDate;

            OutstandingAmount += (((loanEntity.LoanAmount - loanEntity.TblRepayments.Select(m => m.PrincipalPaid).Sum()) * ((applicableInterestRate) / 100)) / 365) * (DateOnly.FromDateTime(DateTime.Now).DayNumber - interestDueDate.DayNumber + 1);

            return OutstandingAmount;
        }

        public async Task<Loan> GetAllPaymentByLoan(Guid LoanId)
        {
            var loanEntity = await _context.TblLoans.Include(m => m.Loanee).Include(m => m.TblRepayments).FirstOrDefaultAsync(m => m.Id == LoanId).ConfigureAwait(false) ?? throw new Exception("No loan found !");


            decimal applicableInterestRate = 0;

            if (!loanEntity.IsDefaulter)
            {
                int countOfPayments = 1;

                countOfPayments += loanEntity.TblRepayments.Count();

                DateOnly dtExpecetedPaymentDate = loanEntity.DisbursedDate.AddYears(countOfPayments);
                dtExpecetedPaymentDate = dtExpecetedPaymentDate.AddDays(1 - dtExpecetedPaymentDate.Day).AddMonths(1).AddDays(-1);

                if (DateOnly.FromDateTime(DateTime.Now) > dtExpecetedPaymentDate)
                {
                    applicableInterestRate = loanEntity.InterestRate;
                }
                else
                {
                    applicableInterestRate = loanEntity.InterestRate - loanEntity.RebateInterest;
                }
            }
            else
            {
                applicableInterestRate = loanEntity.InterestRate;
            }
            return new Loan
            {
                Id = loanEntity.Id,
                LoaneeId = loanEntity.LoaneeId,
                LoaneeName = loanEntity.Loanee.Name,
                SanctionNo = loanEntity.SanctionNo,
                AccountHead = loanEntity.AccountHead,
                DisbursedDate = loanEntity.DisbursedDate,
                InterestRate = loanEntity.InterestRate,
                LoanAmount = loanEntity.LoanAmount,
                LoanTenure = loanEntity.LoanTenure,
                MoratoriumPeriod = loanEntity.MoratoriumPeriod,
                RebateInterest = loanEntity.RebateInterest,
                InterestPaidAsOfNow = loanEntity.TblRepayments.Select(a => a.InterestPaid).Sum(),
                PrincipalPaidAsOfNow = loanEntity.TblRepayments.Select(a => a.PrincipalPaid).Sum(),
                PrincipalDueAsOfNow = loanEntity.LoanAmount - loanEntity.TblRepayments.Select(a => a.PrincipalPaid).Sum(),
                Status = loanEntity.IsClosed ? "Closed" : loanEntity.IsWaived ? "Waived" : loanEntity.IsNclt ? "NCLT" : "",
                IsNclt = loanEntity.IsNclt,
                IsWaived = loanEntity.IsWaived,
                IsClosed = loanEntity.IsClosed,
                OutStandingAsOfNow = CalculateOutStandingAmount(loanEntity),
                InterestAsOnDate = loanEntity.TblRepayments.Select(m => m.InterestDue).Sum() + ((((loanEntity.LoanAmount - (loanEntity.TblRepayments.Any() ? loanEntity.TblRepayments.Select(a => a.PrincipalPaid).Sum() : 0)) * ((applicableInterestRate) / 100)) / 365) * (DateOnly.FromDateTime(DateTime.Now).DayNumber - (loanEntity.TblRepayments.Any() ? loanEntity.TblRepayments.OrderByDescending(m => m.RepaymentDate).FirstOrDefault().RepaymentDate : loanEntity.DisbursedDate).DayNumber + 1)),
                InterestDueAsOfNow = loanEntity.TblRepayments.Select(m => m.InterestDue).Sum() +
                                    ((((loanEntity.LoanAmount - (loanEntity.TblRepayments.Any() ? loanEntity.TblRepayments.Select(a => a.PrincipalPaid).Sum() : 0)) * ((applicableInterestRate) / 100)) / 365) * (DateOnly.FromDateTime(DateTime.Now).DayNumber - (loanEntity.TblRepayments.Any() ? loanEntity.TblRepayments.OrderByDescending(m => m.RepaymentDate).FirstOrDefault().RepaymentDate : loanEntity.DisbursedDate).DayNumber + 1)) - loanEntity.TblRepayments.Select(a => a.InterestPaid).Sum(),
                Payments = loanEntity.TblRepayments.OrderByDescending(m => m.RepaymentDate).Select(m => new Payment
                {
                    Id = m.Id,
                    LoanId = m.LoanId,
                    SanctionNo = loanEntity.SanctionNo,
                    LoanDisbursalDate = loanEntity.DisbursedDate,
                    AccountHead = m.AccountHead,
                    VendorNote = m.VendorNote,
                    FinanceNote = m.FinanceNote,
                    AuditorNote = m.AuditorNote,
                    FinanceComment = m.FinanceComment,
                    AuditorComment = m.AuditorComment,
                    RepaymentDate = m.RepaymentDate,
                    PrincipalPaid = m.PrincipalPaid,
                    InterestPaid = m.InterestPaid,
                    ChallanFileName = m.ChallanFileName,
                    ChallanFileNo = m.ChallanFileNo,
                    InterestDueAsOfNow = m.InterestDue - m.InterestPaid
                }).ToList()
            };
        }

        public async Task<string> ReceivePayment(Payment data, Guid UserId, string HtmlPath)
        {
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data), string.Format("{0} is null", nameof(data)));
            }
            //var duplicatePaymentEntity = await _context.TblRepayments.FirstOrDefaultAsync(m => m.LoanId == data.LoanId && m.RepaymentDate == data.RepaymentDate);
            //if (duplicatePaymentEntity != null)
            //{
            //    throw new Exception(string.Format("Already a payment has been received today"));
            //}
           
            var loanEntity = await _context.TblLoans.Include(m => m.Loanee).Include(m => m.TblRepayments).FirstOrDefaultAsync(m => m.Id == data.LoanId) ?? throw new Exception(string.Format("No such loan found"));

            if (data.RepaymentDate < loanEntity.DisbursedDate)
            {
                throw new Exception(string.Format("Payment date cant be earlier than loan disbursal date"));
            }
            if(loanEntity.IsClosed)
            {
                throw new Exception(string.Format("Loan is already closed"));
            }
            if (loanEntity.IsWaived)
            {
                throw new Exception(string.Format("Loan is already waived off"));
            }
            if (loanEntity.IsClosed)
            {
                throw new Exception(string.Format("Loan is already marked as NCLT"));
            }
            if (loanEntity.TblRepayments.FirstOrDefault(m => m.RepaymentDate > data.RepaymentDate) != null)
            {
                throw new Exception(string.Format("This loan already has the payment ealier than {0}", data.RepaymentDate.ToString("dd/MMM/yyyy")));
            }
          
            decimal existingPrincipalPaid = loanEntity.TblRepayments.Select(a => a.PrincipalPaid).Sum();
            decimal existingInterestPaid = loanEntity.TblRepayments.Select(a => a.InterestPaid).Sum();

            if (loanEntity.LoanAmount < existingPrincipalPaid + data.PrincipalPaid)
            {
                throw new Exception(string.Format("Principal payment amount should not exceed loan amount"));
            }

            if (!loanEntity.IsDefaulter)
            {
                int countOfPayments = 1;

                countOfPayments += loanEntity.TblRepayments.Count();

                DateOnly dtExpecetedPaymentDate = loanEntity.DisbursedDate.AddYears(countOfPayments);
                dtExpecetedPaymentDate = dtExpecetedPaymentDate.AddDays(1 - dtExpecetedPaymentDate.Day).AddMonths(1).AddDays(-1);

                loanEntity.IsDefaulter = data.RepaymentDate > dtExpecetedPaymentDate;
            }    

            var applicableInterestRate = loanEntity.IsDefaulter ? loanEntity.InterestRate :loanEntity.InterestRate - loanEntity.RebateInterest;
            var interestDueDate = loanEntity.TblRepayments.Any() ? loanEntity.TblRepayments.OrderByDescending(m => m.RepaymentDate).FirstOrDefault().RepaymentDate : loanEntity.DisbursedDate;

            decimal InterestAsOfNow = (((loanEntity.LoanAmount - existingPrincipalPaid) * ((applicableInterestRate) / 100)) / 365) * (data.RepaymentDate.DayNumber - interestDueDate.DayNumber);
            
          
            var paymentEntity = new TblRepayment
            {
                Id = Guid.NewGuid(),
                LoanId = data.LoanId,
                RepaymentDate = data.RepaymentDate,
                PrincipalPaid = data.PrincipalPaid,
                InterestPaid = data.InterestPaid,
                AccountHead = data.AccountHead,
                VendorNote = data.VendorNote,
                ChallanFileName = data.ChallanFileName,
                ChallanFileNo = data.ChallanFileNo,
                CreatedBy = UserId,
                CreatedDate = DateTime.Now,
                InterestDue = InterestAsOfNow,   
                InterestRate = applicableInterestRate
            };

            try
            {
                _context.TblRepayments.Add(paymentEntity);
                await _context.SaveChangesAsync().ConfigureAwait(false);

                try
                {
                    var userEntities = await _context.TblUsers.Include(m => m.Role).Where(m => m.IsActive && !string.IsNullOrEmpty(m.Email)).ToListAsync().ConfigureAwait(false);
                    var nonVendorUsers = userEntities.Where(m => m.Role.Alias != "VENDOR").ToList();
                    var vendorUser = userEntities.FirstOrDefault(m => m.Id == UserId);

                    var notificationEntity = new TblNotification
                    {
                        Id = Guid.NewGuid(),
                        Subject = string.Format("New Payment"),
                        Description = string.Format("A new payment has been received from loanee company {0} of Rs.{1} against loan sanction no. {2} on {3}", loanEntity.Loanee.Name, (data.PrincipalPaid + data.InterestPaid).ToString(), loanEntity.SanctionNo, DateTime.Now.ToString("dd/MM/yyyy")),
                        NotificationDate = DateTime.Now,
                        IsActive = true,
                    };

                    nonVendorUsers.ForEach((m) =>
                    {
                        notificationEntity.TblNotificationUsers.Add(new TblNotificationUser
                        {
                            Id = Guid.NewGuid(),
                            UserId = m.Id,
                            IsSeen = false,
                            NotificationId = notificationEntity.Id,
                            Route = m.Role.Alias == "PAO" ? "/secure/master/pao-validation" : "/secure/master/payment-list",
                            Parameter = m.Role.Alias == "PAO" ? null : data.LoanId.ToString()
                        });
                    });

                    _context.TblNotifications.Add(notificationEntity);
                    await _context.SaveChangesAsync().ConfigureAwait(false);

                    var emailConfiguration = new EmailConfiguration();

                    emailConfiguration.SmtpServer = _configuration["EmailConfiguration:SmtpServer"];
                    emailConfiguration.Port = Convert.ToInt32(_configuration["EmailConfiguration:Port"]);
                    emailConfiguration.UserName = _configuration["EmailConfiguration:Username"];
                    emailConfiguration.Password = _configuration["EmailConfiguration:Password"];
                    emailConfiguration.From = _configuration["EmailConfiguration:From"];


                    var FilePath = Path.Combine(HtmlPath, "PaymentReceive.html");
                    StreamReader str = new StreamReader(FilePath);
                    string MailText = str.ReadToEnd();

                    MailText = MailText.Replace("[company]", loanEntity.Loanee.Name);
                    MailText = MailText.Replace("[SanctionNo]", loanEntity.SanctionNo);
                    MailText = MailText.Replace("[Principal]", data.PrincipalPaid.ToString());
                    MailText = MailText.Replace("[Interest]", data.InterestPaid.ToString());
                    MailText = MailText.Replace("[date]", DateTime.Now.ToString("dd-MMM-yyyy"));

                    StringBuilder MailBody = new StringBuilder(MailText);

                    str.Close();

                    var mailStatus = _emailService.SendMailToMultipleUser(MailBody, "Payment Update", emailConfiguration, userEntities.Select(a => a.Email).ToList());

                    if(vendorUser != null)
                    {
                        FilePath = Path.Combine(HtmlPath, "PaymentAcknowledgment.html");
                        str = new StreamReader(FilePath);
                        MailText = str.ReadToEnd();

                        MailText = MailText.Replace("[userName]", vendorUser.FirstName);
                        MailText = MailText.Replace("[SanctionNo]", loanEntity.SanctionNo);
                        MailText = MailText.Replace("[Principal]", data.PrincipalPaid.ToString());
                        MailText = MailText.Replace("[Interest]", data.InterestPaid.ToString());
                        MailText = MailText.Replace("[date]", DateTime.Now.ToString("dd-MMM-yyyy"));

                        MailBody = new StringBuilder(MailText);

                        mailStatus = _emailService.SendMail(MailBody, "Payment Acknowledgement", emailConfiguration);
                        str.Close();
                    }
                   
                }
                catch(Exception ex)
                {
                    ;
                }              

                return string.Format(CultureInfo.InvariantCulture, "Payment received successfully");
            }
            catch
            {
                throw;
            }
        }

        public async Task<string> UpdatePayment(Payment data, Guid UserId)
        {
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data), string.Format("{0} is null", nameof(data)));
            }
            var duplicatePaymentEntity = await _context.TblRepayments.FirstOrDefaultAsync(m => m.Id != data.Id && m.LoanId == data.LoanId && m.RepaymentDate == data.RepaymentDate);

            if (duplicatePaymentEntity != null)
            {
                throw new Exception(string.Format("Already a payment has been received today"));
            }

            var loanEntity = await _context.TblLoans.Include(m => m.TblRepayments).FirstOrDefaultAsync(m => m.Id == data.LoanId) ?? throw new Exception(string.Format("No such loan found"));

            if (data.RepaymentDate < loanEntity.DisbursedDate)
            {
                throw new Exception(string.Format("Payment date cant be earlier than loan disbursal date"));
            }
            if (loanEntity.IsClosed)
            {
                throw new Exception(string.Format("Loan is already closed"));
            }
            if (loanEntity.IsWaived)
            {
                throw new Exception(string.Format("Loan is already waived off"));
            }
            if (loanEntity.IsClosed)
            {
                throw new Exception(string.Format("Loan is already marked as NCLT"));
            }
            if (loanEntity.TblRepayments.FirstOrDefault(m => m.Id != data.Id && m.RepaymentDate > data.RepaymentDate) != null)
            {
                throw new Exception(string.Format("This loan already has the payment ealier than {0}", data.RepaymentDate.ToString("dd/MMM/yyyy")));
            }

            var paymentEntity = await _context.TblRepayments.FirstOrDefaultAsync(m => m.Id == data.Id) ?? throw new Exception(string.Format("No record found"));

            if (!string.IsNullOrEmpty(paymentEntity.AuditorNote))
            {
                throw new Exception(string.Format("Payment is already validated by finance and auditor"));
            }
            if (!string.IsNullOrEmpty(paymentEntity.FinanceNote))
            {
                throw new Exception(string.Format("Payment is already validated by finance"));
            }


            decimal existingPrincipalPaid = loanEntity.TblRepayments.Where(m => m.Id != data.Id).Select(a => a.PrincipalPaid).Sum();
            decimal existingInterestPaid = loanEntity.TblRepayments.Where(m => m.Id != data.Id).Select(a => a.InterestPaid).Sum();

            if (loanEntity.LoanAmount < existingPrincipalPaid + data.PrincipalPaid)
            {
                throw new Exception(string.Format("Principal payment amount should not exceed loan amount"));
            }


            if (!loanEntity.IsDefaulter)
            {
                int countOfPayments = 1;

                countOfPayments += loanEntity.TblRepayments.Where(m => m.Id != data.Id).Count();

                DateOnly dtExpecetedPaymentDate = loanEntity.DisbursedDate.AddYears(countOfPayments);
                dtExpecetedPaymentDate = dtExpecetedPaymentDate.AddDays(1 - dtExpecetedPaymentDate.Day).AddMonths(1).AddDays(-1);

                loanEntity.IsDefaulter = data.RepaymentDate > dtExpecetedPaymentDate;
            }

            var applicableInterestRate = loanEntity.IsDefaulter ? loanEntity.InterestRate : loanEntity.InterestRate - loanEntity.RebateInterest;
       
            var interestDueDate = loanEntity.TblRepayments.Where(m => m.Id != data.Id).Any() ? loanEntity.TblRepayments.Where(m => m.Id != data.Id).OrderByDescending(m => m.RepaymentDate).FirstOrDefault().RepaymentDate : loanEntity.DisbursedDate;

            decimal InterestAsOfNow = (((loanEntity.LoanAmount - existingPrincipalPaid) * ((loanEntity.InterestRate) / 100)) / 365) * (data.RepaymentDate.DayNumber - interestDueDate.DayNumber);

            paymentEntity.RepaymentDate = data.RepaymentDate;
            paymentEntity.PrincipalPaid = data.PrincipalPaid;
            paymentEntity.InterestPaid = data.InterestPaid;
            paymentEntity.AccountHead = data.AccountHead;
            paymentEntity.VendorNote = data.VendorNote;
            paymentEntity.ChallanFileName = data.ChallanFileName;
            paymentEntity.ChallanFileNo = data.ChallanFileNo;
            paymentEntity.InterestDue = InterestAsOfNow;

            try
            {
                await _context.SaveChangesAsync().ConfigureAwait(false);
                return string.Format(CultureInfo.InvariantCulture, "Payment updated successfully");
            }
            catch
            {
                throw;
            }
        }

        public async Task<FilterResult<Payment>> FilterPaymentAsync(PaymentFilterParam filterParam, Guid UserId)
        {
            try
            {
                if (filterParam == null) return new FilterResult<Payment>();

                var userEntity = await _context.TblUsers.Include(m => m.Role).FirstOrDefaultAsync(m => m.Id == UserId);

                var skipCount = (filterParam.PageIndex - 1) * filterParam.PageSize;
                var filterEntitiesQuery = _context.TblRepayments.Include(m => m.Loan).ThenInclude(m => m.Loanee).AsNoTracking().AsQueryable();

                if (!string.IsNullOrEmpty(filterParam.FilterText))
                {
                    filterEntitiesQuery = filterEntitiesQuery.Where(m => !string.IsNullOrEmpty(m.AccountHead) && m.AccountHead.ToLower().Contains(filterParam.FilterText.Trim().ToLower())|| m.Loan.Loanee.Name.ToString().Contains(filterParam.FilterText.Trim().ToLower())|| m.Loan.SanctionNo.ToString().Contains(filterParam.FilterText.Trim().ToLower())
                                          || m.PrincipalPaid.ToString().Contains(filterParam.FilterText.Trim().ToLower()));
                }
                if (userEntity != null)
                {
                    if(userEntity.MappingId != null && userEntity.Role.Alias == "VENDOR")
                    {
                        filterEntitiesQuery = filterEntitiesQuery.Where(m => m.Loan.LoaneeId == userEntity.MappingId);
                    }                   
                }

                filterEntitiesQuery = (filterParam.SortOn.ToUpper()) switch
                {
                    _ => filterParam.SortDirection.ToUpper() == "DESC" ? filterEntitiesQuery.OrderByDescending(m => m.RepaymentDate) : filterEntitiesQuery.OrderBy(m => m.RepaymentDate),
                };

                var totalCount = await filterEntitiesQuery.CountAsync().ConfigureAwait(false);
                var filterEntities = await filterEntitiesQuery.Skip(skipCount).Take(filterParam.PageSize).ToListAsync().ConfigureAwait(false);

                return new FilterResult<Payment>
                {
                    Records = filterEntities.ConvertAll(m => new Payment
                    {
                        Id = m.Id,
                        LoanId = m.LoanId,
                        Loanee = m.Loan.Loanee.Name,
                        SanctionNo = m.Loan.SanctionNo,
                        LoanAmount = m.Loan.LoanAmount,
                        LoanDisbursalDate = m.Loan.DisbursedDate,
                        FinanceNote = m.FinanceNote,
                        FinanceNoteDate = m.FinanceNoteDate,
                        VendorNote = m.VendorNote,
                        AuditorNote = m.AuditorNote,
                        AuditorNoteDate = m.AuditorNoteDate,
                        AccountHead = m.AccountHead,
                        ChallanFileName = m.ChallanFileName,
                        ChallanFileNo = m.ChallanFileNo,
                        PrincipalPaid = m.PrincipalPaid,
                        InterestPaid = m.InterestPaid,
                        RepaymentDate = m.RepaymentDate,
                        FinanceComment = m.FinanceComment,
                        AuditorComment = m.AuditorComment
                    }),
                    TotalCount = totalCount
                };
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<InterestInfoModel> CalculateInterest(InterestModel model)
        {
            var loanEntity = await _context.TblLoans.Include(m => m.TblRepayments).FirstOrDefaultAsync(m => m.Id == model.LoanId) ?? throw new Exception(string.Format("No such loan found"));

            if(DateOnly.FromDateTime(model.PaymentDate) <  loanEntity.DisbursedDate)
            {
                throw new Exception(string.Format("Payment date cant be earlier than loan disbursal date"));
            }

            var lastPaymentEntity = loanEntity.TblRepayments.OrderByDescending(m => m.RepaymentDate).FirstOrDefault();

            var returnModel = new InterestInfoModel();
            returnModel.PreviousInterestDue = loanEntity.TblRepayments.Any() ? loanEntity.TblRepayments.Select(a => a.InterestDue - a.InterestPaid).Sum(): 0;

            decimal applicableInterestRate = 0;

            if (!loanEntity.IsDefaulter)
            {
                int countOfPayments = 1;

                countOfPayments += loanEntity.TblRepayments.Count();

                DateOnly dtExpecetedPaymentDate = loanEntity.DisbursedDate.AddYears(countOfPayments);
                dtExpecetedPaymentDate = dtExpecetedPaymentDate.AddDays(1 - dtExpecetedPaymentDate.Day).AddMonths(1).AddDays(-1);

                if(DateOnly.FromDateTime(model.PaymentDate) > dtExpecetedPaymentDate)
                {
                    applicableInterestRate = loanEntity.InterestRate;
                }
                else
                {
                    applicableInterestRate = loanEntity.InterestRate - loanEntity.RebateInterest;
                }
            }
            else
            {
                applicableInterestRate = loanEntity.InterestRate;
            }
            DateOnly lastPaymentDate = lastPaymentEntity != null ? lastPaymentEntity.RepaymentDate : loanEntity.DisbursedDate;
            
            decimal InterestAsOfNow = (((loanEntity.LoanAmount  - loanEntity.TblRepayments.Select(a => a.PrincipalPaid).Sum()) * (applicableInterestRate / 100)) / 365) * (DateOnly.FromDateTime(model.PaymentDate).DayNumber - lastPaymentDate.DayNumber + 1);
            
            returnModel.CurrentInterestDue = InterestAsOfNow;

            return returnModel;
        }
        public async Task<string> ValidatePayment(ValidatePayment model, Guid UserId, string HtmlPath)
        {
            var paymentEntity = await _context.TblRepayments.Include(m => m.Loan).FirstOrDefaultAsync(m => m.Id == model.PaymentId).ConfigureAwait(false) ?? throw new Exception("No payment found !");

            var userEntity = await _context.TblUsers.Include(m => m.Role).FirstOrDefaultAsync(m => m.Id == UserId);

            string Role = string.Empty;

            if (userEntity != null && userEntity.Role.Alias == "PAO")
            {
                if (!string.IsNullOrEmpty(paymentEntity.FinanceNote))
                {
                    throw new Exception("Note has already been submitted by you");
                }
                else if (!string.IsNullOrEmpty(paymentEntity.AuditorNote))
                {
                    throw new Exception("Note has already verified by auditor");
                }
                else
                {
                    Role = "Finance";
                    paymentEntity.FinanceComment = model.Comment;
                    paymentEntity.FinanceNote = model.Note;
                    paymentEntity.FinanceNoteDate = DateTime.Now;
                }
            }
            else if (userEntity != null && userEntity.Role.Alias == "AG")
            {
                if(string.IsNullOrEmpty(paymentEntity.FinanceNote))
                {
                    throw new Exception("Payment has yet not validated by finance");
                }
                if (!string.IsNullOrEmpty(paymentEntity.AuditorNote))
                {
                    throw new Exception("Note has already been given by you");
                }
                else
                {
                    Role = "Auditor";
                    paymentEntity.AuditorComment = model.Comment;
                    paymentEntity.AuditorNote = model.Note;
                    paymentEntity.AuditorNoteDate = DateTime.Now;
                }
            }
            else
            {
                throw new Exception("Invalid Request");
            }

            try
            {
                await _context.SaveChangesAsync();

                try
                {
                    var userEntities = await _context.TblUsers.Include(m => m.Role).Where(m => m.IsActive && !string.IsNullOrEmpty(m.Email) && (m.Role.Alias != "VENDOR" || m.Id == paymentEntity.CreatedBy)).ToListAsync().ConfigureAwait(false);

                    var notificationEntity = new TblNotification
                    {
                        Id = Guid.NewGuid(),
                        Subject = string.Format("{0} Payment Validation", Role),
                        Description = string.Format("A payment has been validated by {0} which was made on {1} against loan sanction no {2} of Rs.{3}", Role, paymentEntity.RepaymentDate.ToString("dd-MMM-yyyy"), paymentEntity.Loan.SanctionNo, (paymentEntity.PrincipalPaid + paymentEntity.InterestPaid).ToString()),
                        NotificationDate = DateTime.Now,
                        IsActive = true,
                    };

                    userEntities.ForEach((m) =>
                    {
                        notificationEntity.TblNotificationUsers.Add(new TblNotificationUser
                        {
                            Id = Guid.NewGuid(),
                            UserId = m.Id,
                            IsSeen = false,
                            NotificationId = notificationEntity.Id,
                            Route = m.Role.Alias == "AG" ? "/master/payment-validate" : m.Role.Alias == "PAO" ? "/secure/master/pao-validation" : ""
                        });
                    });

                    _context.TblNotifications.Add(notificationEntity);
                    await _context.SaveChangesAsync().ConfigureAwait(false);

                    var emailConfiguration = new EmailConfiguration();

                    emailConfiguration.SmtpServer = _configuration["EmailConfiguration:SmtpServer"];
                    emailConfiguration.Port = Convert.ToInt32(_configuration["EmailConfiguration:Port"]);
                    emailConfiguration.UserName = _configuration["EmailConfiguration:Username"];
                    emailConfiguration.Password = _configuration["EmailConfiguration:Password"];
                    emailConfiguration.From = _configuration["EmailConfiguration:From"];


                    var FilePath = Path.Combine(HtmlPath, "ValidatePayment.html");
                    StreamReader str = new StreamReader(FilePath);
                    string MailText = str.ReadToEnd();

                    MailText = MailText.Replace("[Amount]", (paymentEntity.PrincipalPaid + paymentEntity.InterestPaid).ToString());
                    MailText = MailText.Replace("[SanctionNo]", paymentEntity.Loan.SanctionNo);
                    MailText = MailText.Replace("[Principal]", paymentEntity.PrincipalPaid.ToString());
                    MailText = MailText.Replace("[Interest]", paymentEntity.InterestPaid.ToString());
                    MailText = MailText.Replace("[date]", DateTime.Now.ToString("dd-MMM-yyyy"));
                    MailText = MailText.Replace("[Interest]", paymentEntity.InterestPaid.ToString());
                    MailText = MailText.Replace("[Status]", model.Note);
                    MailText = MailText.Replace("[Note]", model.Comment);
                    MailText = MailText.Replace("[role]", Role);

                    StringBuilder MailBody = new StringBuilder(MailText);

                    str.Close();

                    var mailStatus = _emailService.SendMailToMultipleUser(MailBody, "Payment Verfication", emailConfiguration, userEntities.Select(a => a.Email).ToList());

                 
                }
                catch (Exception ex)
                {
                    ;
                }
                return string.Format("Payment note has been successfully saved");
            }
            catch(Exception ex)
            {
                throw;
            }
         
        }

        public async Task<string> UpdateLoanStatus(LoanStatusUpdate model, Guid UserId)
        {
            var loanEntity = await _context.TblLoans.FirstOrDefaultAsync(m => m.Id == model.LoanId).ConfigureAwait(false) ?? throw new Exception("No loan found !");

            var userEntity = await _context.TblUsers.Include(m => m.Role).FirstOrDefaultAsync(m => m.Id == UserId);

            if (userEntity != null && userEntity.Role.Alias != "ADMIN")
            {
                throw new Exception("Unauthorized request");
            }
            
            if(loanEntity.IsWaived)
            {
                throw new Exception("Loan is already waived off");
            }
            if (loanEntity.IsNclt)
            {
                throw new Exception("Loan is already marked as NCLT");
            }
            if (loanEntity.IsClosed)
            {
                throw new Exception("Loan is already closed");
            }

            if(model.IsWaived)
            {
                loanEntity.IsWaived = true;
            }
            else if(model.IsNclt)
            {
                loanEntity.IsNclt = true;
            }
            try
            {
                await _context.SaveChangesAsync();
                return string.Format("Loan status has been successfully updated");
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public async Task<string> UpdateAccountHead(ChangeAccountHead model, Guid UserId)
        {
            var paymentEntity = await _context.TblRepayments.FirstOrDefaultAsync(m => m.Id == model.PaymentId).ConfigureAwait(false) ?? throw new Exception("No payment found !");

            var userEntity = await _context.TblUsers.Include(m => m.Role).FirstOrDefaultAsync(m => m.Id == UserId);

            if (userEntity != null && userEntity.Role.Alias != "PAO")
            {
                throw new Exception("Unauthorized request");
            }
            if (!string.IsNullOrEmpty(paymentEntity.AuditorNote))
            {
                throw new Exception("Payment has already been verified by auditor");
            }

            try
            {
                paymentEntity.AccountHead = model.AccountHead;
                await _context.SaveChangesAsync();
                return string.Format("Payment's Account head has been successfully updated");
            }
            catch (Exception ex)
            {
                throw;
            }

        }
    }
    #endregion
}
