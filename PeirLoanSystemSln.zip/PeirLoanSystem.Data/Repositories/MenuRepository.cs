﻿using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using PeirLoanSystem.Core.Crypto;
using PeirLoanSystem.Core.Extensions;
using PeirLoanSystem.Core.Security;
using PeirLoanSystem.Data.Entities;
using PeirLoanSystem.Data.Models;
using PeirLoanSystem.Data.ViewModels;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace PeirLoanSystem.Data.Repositories
{
    public interface IMenuService
    {
        Task<bool> UpdateUserMenuPermissionToken(RoleWiseMenuPermissionCheckBox model, Guid UserId);
        Task<bool> UpdateRoleMenuPermissionToken(RoleWiseMenuPermissionCheckBox model);
        Task<bool> SaveUserMenuPermission(RoleUserMenuPermission model);
        Task<UserMenuPermissionModel> GetMenuPermissionsByMenu(Guid menuId);
        Task<IReadOnlyList<TblPermissionToken>> GetHeaderPermission();
        Task<RoleMenuPermissionModel> Get(Guid menuId);
        Task<bool> SaveRoleMenuPermission(RoleUserMenuPermission model);
        Task<IReadOnlyList<AuthorizedUserMenu>> GetAuthorizedUserMenu(Guid id);
        Task<string> UpdateAsync(Menu entity);
        Task<Menu?> GetByIdAsync(Guid id);
        Task<List<string>> GetPermissionTokens(Guid userId, string menuPath);

        Task<IReadOnlyList<TblMenu>> GetAllParentMenuAsync();

        Task<MenuPermissionModel> GetAllMenuWithPermission(Guid RoleId, Guid UserId);

        Task<IReadOnlyList<TblMenu>> GetAllAsync();

        Task<FilterResult<TblMenu>> FilterAsync(MenuFilterParam filter);

        Task<string> CreateAsync(Menu entity, Guid UserId);
        Task<List<Role>> GetAllRoleAsync();
        Task<Role?> GetRoleByIdAsync(Guid id);
        Task<List<User?>> GetUserByRoleIdAsync(Guid id);
        Task<string> CreateRoleAsync(Role data);
        Task<string> UpdateRoleAsync(Guid id, Role data);
    }
    public class MenuRepository : IMenuService
    {

        public readonly PeirloanDataContext _context;
        public MenuRepository(PeirloanDataContext context)
        {
            _context = context;
        }
        public async Task<string> CreateAsync(Menu entity, Guid UserId)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity), string.Format("{0} is null", nameof(entity)));
            }

            var existingEntity = await _context.TblMenus.FirstOrDefaultAsync(m => entity.Name == m.Name).ConfigureAwait(false);

            if (existingEntity != null)
            {
                return string.Format("{0} already exists", entity.Name);
            }

            var menuEntities = new TblMenu
            {
                Id = Guid.NewGuid(),
                Name = entity.Name,
                Icon = entity.Icon,
                TargetPath = entity.Target,
                IsActive = entity.IsActive,
                Position = entity.SortPosition,
                ParentMenuId = entity.ParentId,
                CreatedDate = DateTime.Now,
                CreatedBy = UserId
            };

            foreach (var permissionId in entity.Header)
            {
                menuEntities.TblMenuPermissionTokens.Add(new TblMenuPermissionToken
                {
                    Id = Guid.NewGuid(),
                    PermissionTokenId = permissionId,
                    MenuId = menuEntities.Id
                });
            }

            try
            {
                _context.TblMenus.Add(menuEntities);
                await _context.SaveChangesAsync().ConfigureAwait(false);
                return string.Format("{0} added successfully", entity.Name);
            }
            catch (Exception Ex)
            {
                throw;
            }
        }


        public async Task<FilterResult<TblMenu>> FilterAsync(MenuFilterParam filter)
        {
            if (filter == null) return new FilterResult<TblMenu>();

            var skip = (filter.PageIndex - 1) * filter.PageSize;

            var filterEntitiesQuery = await _context.TblMenus.ToListAsync().ConfigureAwait(false);

            if (filter.FilterText != null)
            {
                filterEntitiesQuery = filterEntitiesQuery.Where(m => m.Name.Contains(filter.FilterText.Trim(), StringComparison.OrdinalIgnoreCase)).ToList();
            }

            filterEntitiesQuery = filter.SortOn.ToLower() switch
            {
                _ => filter.SortDirection.StartsWith("-") ? filterEntitiesQuery.OrderByDescending(m => m.Name).ToList() : filterEntitiesQuery.OrderByDescending(m => m.Name).ToList(),
            };

            var totalCount = filterEntitiesQuery.Count;

            return new FilterResult<TblMenu>
            {
                Records = filterEntitiesQuery.ConvertAll(m => new TblMenu
                {
                    Id = m.Id,
                    Name = m.Name,
                    Icon = m.Icon,
                    TargetPath = m.TargetPath,
                    IsActive = m.IsActive,
                    ParentMenuId = m.ParentMenuId,
                    Position = m.Position,
                }).Skip(skip).Take(filter.PageSize).ToList(),
                TotalCount = totalCount
            };
        }

        public async Task<IReadOnlyList<TblMenu>> GetAllAsync()
        {
            var MenuEntities = await _context.TblMenus.ToListAsync().ConfigureAwait(false);
            return MenuEntities.ConvertAll(m => new TblMenu
            {
                Id = m.Id,
                Name = m.Name,
                Icon = m.Icon,
                TargetPath = m.TargetPath,
                IsActive = m.IsActive,
                ParentMenuId = m.ParentMenuId,
                Position = m.Position
            });
        }

        //public async Task<MenuPermissionModel> GetAllMenuWithPermission(Guid RoleId, Guid UserId)
        //{
        //    if (RoleId != Guid.Empty)
        //    {
        //        var MenuEntities = await _context.TblMenus.Include(m => m.TblMenuPermissionTokens).ThenInclude(m => m.PermissionToken).Where(m => !string.IsNullOrEmpty(m.TargetPath.Trim()) && m.TargetPath.Trim() != "#" && m.ParentMenuId != null && m.IsActive == true).OrderBy(m => m.Name).ToListAsync().ConfigureAwait(false);
        //        var rolePermissionTokenEntities = await _context.TblRoleMenuPermissionTokens.ToListAsync();

        //        var permissionTokens = await _context.TblPermissionTokens.ToListAsync().ConfigureAwait(false);

        //        var model = new MenuPermissionModel();
        //        var headers = new List<string>();
        //        model.RoleId = RoleId;
        //        headers.AddRange(permissionTokens.Select(p => p.Name).OrderBy(p => p).Distinct());
        //        model.Headers = headers;

        //        var permissionList = new List<MenuPermissionTokenModel>();
        //        foreach (var menu in MenuEntities)
        //        {
        //            var roleMenuPermissionEntites = rolePermissionTokenEntities.Where(m => m.RoleId == RoleId).ToList();

        //            permissionList.Add(new MenuPermissionTokenModel
        //            {
        //                MenuId = menu.Id,
        //                MenuName = menu.Name,
        //                PermissionTokens = menu.TblMenuPermissionTokens.OrderBy(m => m.PermissionToken.Name).Select(m => new PermissionTokenModel
        //                {
        //                    Id = m.Id,
        //                    Name = m.PermissionToken.Name,
        //                    IsSelected = roleMenuPermissionEntites.Any(p => p.MenuPermissionTokenId == m.Id)
        //                }).OrderBy(m => m.Name).ToList()
        //            });
        //        }

        //        model.Permissions = permissionList;
        //        return model;
        //    }
        //    else
        //    {
        //        var MenuEntities = await _context.TblMenus.Include(m => m.TblMenuPermissionTokens).ThenInclude(m => m.PermissionToken).Where(m => !string.IsNullOrEmpty(m.TargetPath.Trim()) && m.TargetPath.Trim() != "#" && m.ParentMenuId != null && m.IsActive == true).OrderBy(m => m.Name).ToListAsync().ConfigureAwait(false);

        //        var userEntity = await _context.TblUsers.Where(m => m.Id == UserId).Include(m => m.TblUserMenuPermissionTokens).FirstOrDefaultAsync().ConfigureAwait(false);
        //        var userPermissionTokenEntities = userEntity.TblUserMenuPermissionTokens.ToList();
        //        var rolePermissionTokenEntities = await _context.TblRoleMenuPermissionTokens.ToListAsync();

        //        var permissionTokens = await _context.TblPermissionTokens.ToListAsync().ConfigureAwait(false);

        //        var model = new MenuPermissionModel();
        //        var headers = new List<string>();

        //        headers.AddRange(permissionTokens.Select(p => p.Name).OrderBy(p => p).Distinct());
        //        model.Headers = headers;

        //        var permissionList = new List<MenuPermissionTokenModel>();
        //        foreach (var menu in MenuEntities)
        //        {
        //            var userMenuPermissionEntites = userPermissionTokenEntities.Where(m => m.UserId == UserId).ToList();
        //            var roleMenuPermissionEntites = rolePermissionTokenEntities.Where(m => m.RoleId == userEntity.RoleId).ToList();
        //            permissionList.Add(new MenuPermissionTokenModel
        //            {
        //                MenuId = menu.Id,
        //                MenuName = menu.Name,
        //                PermissionTokens = menu.TblMenuPermissionTokens.OrderBy(m => m.PermissionToken.Name).Select(m => new PermissionTokenModel
        //                {
        //                    Id = m.Id,
        //                    Name = m.PermissionToken.Name,
        //                    IsSelected = userMenuPermissionEntites.Where(u => u.MenuPermissionTokenId == m.Id).Count() > 0 ? true :
        //                            roleMenuPermissionEntites.Where(p => p.MenuPermissionTokenId == m.Id).Count() > 0 ? true : false,
        //                    IsDisabled = roleMenuPermissionEntites.Any(p => p.MenuPermissionTokenId == m.Id)
        //                }).OrderBy(m => m.Name).ToList()
        //            });
        //        }

        //        model.Permissions = permissionList;
        //        return model;
        //    }

        //}

        public async Task<IReadOnlyList<TblMenu>> GetAllParentMenuAsync()
        {
            var MenuEntities = await _context.TblMenus.Where(m => m.ParentMenuId == null).ToListAsync().ConfigureAwait(false);
            return MenuEntities.ConvertAll(m => new TblMenu
            {
                Id = m.Id,
                Name = m.Name,
                Icon = m.Icon,
                TargetPath = m.TargetPath,
                IsActive = m.IsActive,
                ParentMenuId = m.ParentMenuId,
                Position = m.Position
            });
        }

        public async Task<List<string>> GetPermissionTokens(Guid userId, string menuPath)
        {
            var userEntity = await _context.TblUsers.FirstOrDefaultAsync(m => m.Id == userId);

            menuPath = "/" + menuPath;

            var permissionTokenIdList = await _context.TblRoleMenuPermissionTokens.Include(m => m.MenuPermissionToken).ThenInclude(m => m.Menu).Include(m => m.MenuPermissionToken.PermissionToken).Where(m => m.RoleId == userEntity.RoleId && m.MenuPermissionToken.Menu.TargetPath.Equals(menuPath)).Select(m => m.MenuPermissionToken.PermissionToken.Name.Trim().ToLower()).ToListAsync();
            var userMenuPermissionTokenIds = await _context.TblUserMenuPermissionTokens.Include(m => m.MenuPermissionToken).ThenInclude(m => m.Menu).Include(m => m.MenuPermissionToken.PermissionToken).Where(m => m.UserId == userId && m.MenuPermissionToken.Menu.TargetPath.Equals(menuPath)).Select(m => m.MenuPermissionToken.PermissionToken.Name.Trim().ToLower()).ToListAsync();
            permissionTokenIdList.AddRange(userMenuPermissionTokenIds);

            return permissionTokenIdList.Distinct().ToList();
        }

        public async Task<Menu?> GetByIdAsync(Guid id)
        {
            var menuEntity = await _context.TblMenus.Include(m => m.ParentMenu).Include(m => m.TblMenuPermissionTokens).FirstOrDefaultAsync(m => m.Id == id).ConfigureAwait(false);
            return menuEntity == null ? null : new Menu
            {
                Id = menuEntity.Id,
                Name = menuEntity.Name,
                Icon = menuEntity.Icon,
                Target = menuEntity.TargetPath,
                IsActive = menuEntity.IsActive,
                SortPosition = menuEntity.Position.Value,
                Header = menuEntity.TblMenuPermissionTokens.Select(p => p.PermissionTokenId).ToList(),
                ParentId = menuEntity.ParentMenuId
            };
        }

        public async Task<string> UpdateAsync(Menu entity)
        {
            var existingEntity = await _context.TblMenus.FirstOrDefaultAsync(m => entity.Name.ToLower().Trim() == m.Name.ToLower().Trim() && m.Id != entity.Id).ConfigureAwait(false);

            if (existingEntity != null)
            {
                return string.Format("{0} Already Exists", entity.Name);
            }

            var menuEntity =
                        await _context.TblMenus.
                        Include(m => m.TblMenuPermissionTokens).
                        ThenInclude(m => m.TblRoleMenuPermissionTokens).
                          Include(m => m.TblMenuPermissionTokens).
                        ThenInclude(m => m.TblUserMenuPermissionTokens).
                        FirstOrDefaultAsync(m => m.Id == entity.Id).ConfigureAwait(false);
            if (menuEntity == null)
            {
                return string.Format("Menu not found for the given Id");
            }

            if (menuEntity != null && menuEntity.TblMenuPermissionTokens != null && menuEntity.TblMenuPermissionTokens.Count() > 0)
            {
                try
                {
                    _context.TblRoleMenuPermissionTokens.RemoveRange(menuEntity.TblMenuPermissionTokens.SelectMany(n => n.TblRoleMenuPermissionTokens));
                    _context.TblUserMenuPermissionTokens.RemoveRange(menuEntity.TblMenuPermissionTokens.SelectMany(n => n.TblUserMenuPermissionTokens));
                    _context.TblMenuPermissionTokens.RemoveRange(menuEntity.TblMenuPermissionTokens);
                    await _context.SaveChangesAsync();
                }
                catch (Exception Ex)
                {
                    throw Ex;
                }

            }

            if (menuEntity != null)
            {
                menuEntity.Name = entity.Name;
                menuEntity.Icon = entity.Icon;
                menuEntity.TargetPath = entity.Target;
                menuEntity.IsActive = entity.IsActive;
                menuEntity.ParentMenuId = entity.ParentId;
                menuEntity.Position = entity.SortPosition;
            }
            foreach (var permissionId in entity.Header)
            {
                menuEntity.TblMenuPermissionTokens.Add(new TblMenuPermissionToken
                {
                    Id = Guid.NewGuid(),
                    PermissionTokenId = permissionId,
                    MenuId = menuEntity.Id
                });
            }


            try
            {
                await _context.SaveChangesAsync().ConfigureAwait(false);
                return string.Format("{0} Updated Successfully", entity.Name);
            }
            catch
            {
                throw;
            }
        }

        public async Task<IReadOnlyList<AuthorizedUserMenu>> GetAuthorizedUserMenu(Guid id)
        {
            var userEntity = await _context.TblUsers.FirstOrDefaultAsync(m => m.Id == id).ConfigureAwait(false);
            var menuIds = await _context.TblUserMenuPermissionTokens.Include(m => m.MenuPermissionToken).ThenInclude(m => m.Menu).Where(m => m.UserId == id && m.MenuPermissionToken.Menu.IsActive).Select(m => m.MenuPermissionToken.MenuId).ToListAsync().ConfigureAwait(false);

            if (userEntity?.RoleId != null)
            {
                var rolePermissionMenuIds = await _context.TblRoleMenuPermissionTokens.Include(m => m.MenuPermissionToken).ThenInclude(m => m.Menu).Where(m => m.RoleId == userEntity.RoleId && m.MenuPermissionToken.Menu.IsActive).Select(m => m.MenuPermissionToken.MenuId).Distinct().ToListAsync().ConfigureAwait(false);
                menuIds.AddRange(rolePermissionMenuIds);
            }

            var menuEntities = await _context.TblMenus.Where(m => menuIds.Contains(m.Id)).Distinct().ToListAsync().ConfigureAwait(false);

            return menuEntities.ConvertAll(menu => new AuthorizedUserMenu
            {
                Id = menu.Id,
                label = menu.Name,
                Icon = menu.Icon,
                TargetPath = menu.TargetPath
            });
        }

        public async Task<bool> SaveRoleMenuPermission(RoleUserMenuPermission model)
        {
            List<TblRoleMenuPermissionToken> tokens = new();
            try
            {
                foreach (var item in model.Menu)
                {
                    foreach (var menuPermissionTokenId in item.MenuPermissionTokenIds)
                    {
                        tokens.Add(new TblRoleMenuPermissionToken { Id = Guid.NewGuid(), RoleId = model.UserRoleId, MenuPermissionTokenId = menuPermissionTokenId });
                    }
                }

                var roleAccessPermissions = await _context.TblRoleMenuPermissionTokens.Include(m => m.MenuPermissionToken).Where(m => m.RoleId == model.UserRoleId
                                                                                                                                   && model.Menu.Select(a => a.MenuId).ToList().Contains(m.MenuPermissionToken.MenuId)
                                                                                                                                ).ToListAsync();
                _context.TblRoleMenuPermissionTokens.RemoveRange(roleAccessPermissions);
                await _context.SaveChangesAsync();

                await _context.TblRoleMenuPermissionTokens.AddRangeAsync(tokens);
                await _context.SaveChangesAsync();

                return true;
            }
            catch
            {

                throw;
            }
        }
        //public async Task<RoleMenuPermissionModel> Get(Guid menuId)
        //{
        //    var menuEntity = await _context.TblMenus.Include(m => m.TblMenuPermissionTokens).ThenInclude(m => m.PermissionToken).FirstOrDefaultAsync(m => m.Id == menuId);
        //    var roleEntities = await _context.TblRoles.OrderBy(p => p.Name).ToListAsync();
        //    var rolePermissionTokenEntities = await _context.TblRoleMenuPermissionTokens.ToListAsync();

        //    var model = new RoleMenuPermissionModel();
        //    var headers = new List<string>();
        //    model.MenuId = menuId;
        //    headers.AddRange(menuEntity.TblMenuPermissionTokens.Select(p => p.PermissionToken.Name).OrderBy(p => p));
        //    model.Headers = headers;

        //    var permissionList = new List<RolePermissionTokenModel>();
        //    foreach (var role in roleEntities)
        //    {
        //        var roleMenuPermissionEntites = rolePermissionTokenEntities.Where(m => m.RoleId == role.Id).ToList();

        //        permissionList.Add(new RolePermissionTokenModel
        //        {
        //            RoleId = role.Id,
        //            RoleName = role.Name,
        //            PermissionTokens = menuEntity.TblMenuPermissionTokens.OrderBy(m => m.PermissionToken.Name).Select(m => new PermissionTokenModel
        //            {
        //                Id = m.Id,
        //                Name = m.PermissionToken.Name,
        //                IsSelected = roleMenuPermissionEntites.Any(p => p.MenuPermissionTokenId == m.Id)
        //            }).ToList()
        //        });
        //    }

        //    model.Permissions = permissionList;
        //    return model;
        //}

        public async Task<IReadOnlyList<TblPermissionToken>> GetHeaderPermission()
        {

            var permissioTokenEntity = await _context.TblPermissionTokens.ToListAsync().ConfigureAwait(false);
            return permissioTokenEntity.ConvertAll(m => new TblPermissionToken
            {
                Id = m.Id,
                Name = m.Name,
            });


        }
        public async Task<UserMenuPermissionModel> GetMenuPermissionsByMenu(Guid menuId)
        {
            var menuEntity = await _context.TblMenus.Include(m => m.TblMenuPermissionTokens).ThenInclude(m => m.PermissionToken).FirstOrDefaultAsync(m => m.Id == menuId);
            var userEntities = await _context.TblUsers.Include(u => u.Role).OrderBy(u => u.Id).ToListAsync();
            var rolePermissionTokenEntities = await _context.TblRoleMenuPermissionTokens.ToListAsync();
            var userMenuPermissionEntities = await _context.TblUserMenuPermissionTokens.ToListAsync().ConfigureAwait(false);

            var model = new UserMenuPermissionModel();
            var headers = new List<string>();
            model.MenuId = menuId;
            headers.AddRange(menuEntity.TblMenuPermissionTokens.Select(p => p.PermissionToken.Name).OrderBy(p => p));
            model.Headers = headers;

            var permissionList = new List<UserPermissionToken>();
            foreach (var user in userEntities)
            {
                var roleMenuPermissionEntites = rolePermissionTokenEntities.Where(m => m.RoleId == user.RoleId).ToList();
                var userMenuPermissions = userMenuPermissionEntities.Where(m => m.UserId == user.Id).ToList();

                permissionList.Add(new UserPermissionToken
                {
                    UserId = user.Id,
                    UserName = user.FirstName + " " + user.LastName,
                    RoleName = user?.Role?.Name,
                    PermissionTokens = menuEntity.TblMenuPermissionTokens.OrderBy(m => m.PermissionToken.Name).Select(m => new PermissionTokenModel
                    {
                        Id = m.Id,
                        Name = m.PermissionToken.Name,
                        IsSelected = userMenuPermissions.Where(u => u.MenuPermissionTokenId == m.Id).Count() > 0 ? true :
                                    roleMenuPermissionEntites.Where(p => p.MenuPermissionTokenId == m.Id).Count() > 0 ? true : false,
                        IsDisabled = roleMenuPermissionEntites.Any(p => p.MenuPermissionTokenId == m.Id)
                    }).ToList()
                });
            }
            model.Permissions = permissionList;
            return model;
        }

        public async Task<bool> SaveUserMenuPermission(RoleUserMenuPermission model)
        {
            List<TblUserMenuPermissionToken> tokens = new();
            try
            {
                foreach (var item in model.Menu)
                {
                    foreach (var menuPermissionTokenId in item.MenuPermissionTokenIds)
                    {
                        tokens.Add(new TblUserMenuPermissionToken { Id = Guid.NewGuid(), UserId = model.UserRoleId, MenuPermissionTokenId = menuPermissionTokenId });
                    }
                }

                var menuAccessPermissions = await _context.TblUserMenuPermissionTokens.Include(m => m.MenuPermissionToken).Where(m => m.UserId == model.UserRoleId
                      && model.Menu.Select(a => a.MenuId).ToList().Contains(m.MenuPermissionToken.MenuId)
                    ).ToListAsync();

                _context.TblUserMenuPermissionTokens.RemoveRange(menuAccessPermissions);
                await _context.SaveChangesAsync();

                await _context.TblUserMenuPermissionTokens.AddRangeAsync(tokens);
                await _context.SaveChangesAsync();

                return true;
            }
            catch (Exception ex)
            {

                throw;
            }
        }






        public async Task<List<Role>> GetAllRoleAsync()
        {
            var roleEntities = await _context.TblRoles.OrderBy(m => m.Name).ToListAsync();
            return roleEntities.Select(m => new Role
            {
                Id = m.Id,
                Name = m.Name,
                Alias = m.Alias,
            }).ToList();
        }

        public async Task<Role?> GetRoleByIdAsync(Guid id)
        {
            var roleEntity = await _context.TblRoles.FirstOrDefaultAsync(m => m.Id == id);
            return roleEntity == null ? null : new Role
            {
                Id = roleEntity.Id,
                Name = roleEntity.Name,
                Alias = roleEntity.Alias,
            };
        }

        public async Task<List<User?>> GetUserByRoleIdAsync(Guid id)
        {

            var roleEntity = await _context.TblUsers.Where(m => m.RoleId == id && m.IsActive == true).ToListAsync();

            return roleEntity.Select(m => new User
            {
                Id = m.Id,
                FullName = m.FullName

            }).ToList();
        }





        public async Task<string> CreateRoleAsync(Role data)
        {
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data), string.Format("{0} is null", nameof(data)));
            }
            var existingEntity = await _context.TblRoles.FirstOrDefaultAsync(m => data.Name.ToUpper(CultureInfo.InvariantCulture) == m.Name).ConfigureAwait(false);
            if (existingEntity != null)
            {
                throw new ArgumentException(string.Format("{0} {1} already exists", nameof(data), data.Name));
            }

            var roleEntity = new TblRole
            {
                Id = Guid.NewGuid(),
                Name = data.Name,
                Alias = data.Alias,

            };

            try
            {
                _context.TblRoles.Add(roleEntity);
                await _context.SaveChangesAsync().ConfigureAwait(false);
                return string.Format(CultureInfo.InvariantCulture, "{0} {1} added successfully", nameof(data), data.Name);
            }
            catch
            {
                throw;
            }
        }

        public async Task<string> UpdateRoleAsync(Guid id, Role data)
        {
            var existingEntity = await _context.TblRoles.FirstOrDefaultAsync(m => data.Name.ToUpper(CultureInfo.InvariantCulture) == m.Name && m.Id != id).ConfigureAwait(false);
            if (existingEntity != null)
            {
                return string.Format(CultureInfo.InvariantCulture, "{0} {1} already exists", nameof(data), data.Name);
            }

            var roleEntity = await _context.TblRoles.FirstOrDefaultAsync(m => m.Id == data.Id).ConfigureAwait(false);
            if (roleEntity == null)
            {
                return string.Format(CultureInfo.InvariantCulture, "{0} not found with the given id", nameof(data));
            }

            roleEntity.Name = data.Name;
            roleEntity.Alias = data.Alias;

            try
            {
                await _context.SaveChangesAsync().ConfigureAwait(false);
                return string.Format(CultureInfo.InvariantCulture, "{0} {1} updated successfully", nameof(data), data.Name);
            }
            catch
            {
                throw;
            }
        }


        public async Task<RoleMenuPermissionModel> Get(Guid menuId)
        {
            var menuEntity = await _context.TblMenus.Include(m => m.TblMenuPermissionTokens).ThenInclude(m => m.PermissionToken).FirstOrDefaultAsync(m => m.Id == menuId);
            var roleEntities = await _context.TblRoles.OrderBy(p => p.Name).ToListAsync();
            var rolePermissionTokenEntities = await _context.TblRoleMenuPermissionTokens.ToListAsync();

            var model = new RoleMenuPermissionModel();
            var headers = new List<string>();
            model.MenuId = menuId;
            headers.AddRange(menuEntity.TblMenuPermissionTokens.Select(p => p.PermissionToken.Name).OrderBy(p => p));
            model.Headers = headers;

            var permissionList = new List<RolePermissionTokenModel>();
            foreach (var role in roleEntities)
            {
                var roleMenuPermissionEntites = rolePermissionTokenEntities.Where(m => m.RoleId == role.Id).ToList();

                permissionList.Add(new RolePermissionTokenModel
                {
                    RoleId = role.Id,
                    RoleName = role.Name,
                    PermissionTokens = menuEntity.TblMenuPermissionTokens.OrderBy(m => m.PermissionToken.Name).Select(m => new PermissionTokenModel
                    {
                        Id = m.Id,
                        Name = m.PermissionToken.Name,
                        IsSelected = roleMenuPermissionEntites.Any(p => p.MenuPermissionTokenId == m.Id)
                    }).ToList()
                });
            }

            model.Permissions = permissionList;
            return model;
        }


        public async Task<MenuPermissionModel> GetAllMenuWithPermission(Guid RoleId, Guid UserId)
        {
            if (RoleId != Guid.Empty)
            {
                //var menuEntity = await _context.TblMenus.Include(m => m.TblMenuPermissionTokens).ThenInclude(m => m.PermissionToken).FirstOrDefaultAsync(m => m.Id == menuId);
                var MenuEntities = await _context.TblMenus.Include(m => m.TblMenuPermissionTokens).ThenInclude(m => m.PermissionToken).Where(m => !string.IsNullOrEmpty(m.TargetPath.Trim()) && m.TargetPath.Trim() != "#" && m.IsActive == true).OrderBy(m => m.Name).ToListAsync().ConfigureAwait(false);
                //var roleEntities = await _context.TblRoles.OrderBy(p => p.Name).ToListAsync();
                var rolePermissionTokenEntities = await _context.TblRoleMenuPermissionTokens.ToListAsync();

                var permissionTokens = await _context.TblPermissionTokens.ToListAsync().ConfigureAwait(false);

                var model = new MenuPermissionModel();
                var headers = new List<string>();
                model.RoleId = RoleId;
                headers.AddRange(permissionTokens.Select(p => p.Name).OrderBy(p => p).Distinct());
                model.Headers = headers;

                var permissionList = new List<MenuPermissionTokenModel>();
                foreach (var menu in MenuEntities)
                {
                    var roleMenuPermissionEntites = rolePermissionTokenEntities.Where(m => m.RoleId == RoleId).ToList();

                    permissionList.Add(new MenuPermissionTokenModel
                    {
                        MenuId = menu.Id,
                        MenuName = menu.Name,
                        PermissionTokens = menu.TblMenuPermissionTokens.OrderBy(m => m.PermissionToken.Name).Select(m => new PermissionTokenModel
                        {
                            Id = m.Id,
                            Name = m.PermissionToken.Name,
                            IsSelected = roleMenuPermissionEntites.Any(p => p.MenuPermissionTokenId == m.Id)
                        }).OrderBy(m => m.Name).ToList()
                    });
                }

                model.Permissions = permissionList;
                return model;
            }
            else
            {
                var MenuEntities = await _context.TblMenus.Include(m => m.TblMenuPermissionTokens).ThenInclude(m => m.PermissionToken).Where(m => !string.IsNullOrEmpty(m.TargetPath.Trim()) && m.TargetPath.Trim() != "#" && m.IsActive == true).OrderBy(m => m.Name).ToListAsync().ConfigureAwait(false);

                var userEntity = await _context.TblUsers.Where(m => m.Id == UserId).Include(m => m.TblUserMenuPermissionTokens).FirstOrDefaultAsync().ConfigureAwait(false);
                var userPermissionTokenEntities = userEntity.TblUserMenuPermissionTokens.ToList();
                var rolePermissionTokenEntities = await _context.TblRoleMenuPermissionTokens.ToListAsync();

                var permissionTokens = await _context.TblPermissionTokens.ToListAsync().ConfigureAwait(false);

                var model = new MenuPermissionModel();
                var headers = new List<string>();

                headers.AddRange(permissionTokens.Select(p => p.Name).OrderBy(p => p).Distinct());
                model.Headers = headers;

                var permissionList = new List<MenuPermissionTokenModel>();
                foreach (var menu in MenuEntities)
                {
                    var userMenuPermissionEntites = userPermissionTokenEntities.Where(m => m.UserId == UserId).ToList();
                    var roleMenuPermissionEntites = rolePermissionTokenEntities.Where(m => m.RoleId == userEntity.RoleId).ToList();
                    permissionList.Add(new MenuPermissionTokenModel
                    {
                        MenuId = menu.Id,
                        MenuName = menu.Name,
                        PermissionTokens = menu.TblMenuPermissionTokens.OrderBy(m => m.PermissionToken.Name).Select(m => new PermissionTokenModel
                        {
                            Id = m.Id,
                            Name = m.PermissionToken.Name,
                            IsSelected = userMenuPermissionEntites.Where(u => u.MenuPermissionTokenId == m.Id).Count() > 0 ? true :
                                    roleMenuPermissionEntites.Where(p => p.MenuPermissionTokenId == m.Id).Count() > 0 ? true : false,
                            IsDisabled = roleMenuPermissionEntites.Any(p => p.MenuPermissionTokenId == m.Id)
                        }).OrderBy(m => m.Name).ToList()
                    });
                }

                model.Permissions = permissionList;
                return model;
            }

        }

        public async Task<bool> UpdateRoleMenuPermissionToken(RoleWiseMenuPermissionCheckBox model)
        {
            if (model == null)
            {
                throw new ArgumentNullException(nameof(model), string.Format("{0} is null", nameof(model)));
            }
            if (model.IsChecked)
            {
                var roleMenuPermissionTokenCount = await _context.TblRoleMenuPermissionTokens.Where(m => m.RoleId == model.RoleId && m.MenuPermissionTokenId == model.MenuPermissionTokenId).CountAsync().ConfigureAwait(true);

                if (roleMenuPermissionTokenCount > 0)
                {
                    return false;
                }
                else
                {
                    var newRoleMenuPermissionTokenEntities = new List<TblRoleMenuPermissionToken>();

                    var menuPermissionTokenEntity = await _context.TblMenuPermissionTokens.Include(m => m.PermissionToken).FirstOrDefaultAsync(m => m.Id == model.MenuPermissionTokenId).ConfigureAwait(false);

                    if (menuPermissionTokenEntity != null && menuPermissionTokenEntity.PermissionToken.Name == "FULL")
                    {
                        var existingRoleMenuPermissionTokenEntites = await _context.TblRoleMenuPermissionTokens.Include(a => a.MenuPermissionToken).Where(a => a.RoleId == model.RoleId && a.MenuPermissionToken.MenuId == menuPermissionTokenEntity.MenuId).ToListAsync().ConfigureAwait(false);
                        var menuPermissionTokenEntites = await _context.TblMenuPermissionTokens.Where(a => a.MenuId == menuPermissionTokenEntity.MenuId).ToListAsync().ConfigureAwait(false);



                        foreach (var menuPermissionToken in menuPermissionTokenEntites)
                        {
                            if (existingRoleMenuPermissionTokenEntites.FirstOrDefault(a => a.RoleId == model.RoleId && a.MenuPermissionTokenId == menuPermissionToken.Id) == null)
                            {
                                newRoleMenuPermissionTokenEntities.Add(new TblRoleMenuPermissionToken
                                {
                                    Id = Guid.NewGuid(),
                                    RoleId = model.RoleId,
                                    MenuPermissionTokenId = menuPermissionToken.Id
                                });
                            }
                        }
                    }
                    else
                    {
                        newRoleMenuPermissionTokenEntities.Add(new TblRoleMenuPermissionToken
                        {
                            Id = Guid.NewGuid(),
                            RoleId = model.RoleId,
                            MenuPermissionTokenId = model.MenuPermissionTokenId,
                        });
                    }


                    try
                    {
                        _context.TblRoleMenuPermissionTokens.AddRange(newRoleMenuPermissionTokenEntities);
                        await _context.SaveChangesAsync();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        throw;
                    }
                }
            }
            else
            {
                var menuPermissionTokenEntity = await _context.TblRoleMenuPermissionTokens.Where(m => m.RoleId == model.RoleId && m.MenuPermissionTokenId == model.MenuPermissionTokenId).FirstOrDefaultAsync().ConfigureAwait(true);

                if (menuPermissionTokenEntity == null)
                {
                    return false;
                }
                else
                {
                    try
                    {
                        _context.TblRoleMenuPermissionTokens.Remove(menuPermissionTokenEntity);
                        await _context.SaveChangesAsync();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        throw;
                    }
                }
            }

        }


        public async Task<bool> UpdateUserMenuPermissionToken(RoleWiseMenuPermissionCheckBox model, Guid UserId)
        {
            if (model == null)
            {
                throw new ArgumentNullException(nameof(model), string.Format("{0} is null", nameof(model)));
            }
            if (model.IsChecked)
            {

                var userMenuPermissionTokenCount = await _context.TblUserMenuPermissionTokens.Where(m => m.UserId == model.RoleId && m.MenuPermissionTokenId == model.MenuPermissionTokenId).CountAsync().ConfigureAwait(true);


                if (userMenuPermissionTokenCount > 0)
                {
                    return false;
                }
                else
                {
                    List<TblUserMenuPermissionToken>? newUserMenuPermissionTokenEntities = new List<TblUserMenuPermissionToken>();

                    var menuPermissionTokenEntity = await _context.TblMenuPermissionTokens.Include(m => m.PermissionToken).FirstOrDefaultAsync(m => m.Id == model.MenuPermissionTokenId).ConfigureAwait(false);

                    if (menuPermissionTokenEntity != null && menuPermissionTokenEntity.PermissionToken.Name == "FULL")
                    {
                        var existingUserMenuPermissionTokenEntites = await _context.TblUserMenuPermissionTokens.Include(a => a.MenuPermissionToken).Where(a => a.UserId == model.RoleId && a.MenuPermissionToken.MenuId == menuPermissionTokenEntity.MenuId).ToListAsync().ConfigureAwait(false);
                        var menuPermissionTokenEntites = await _context.TblMenuPermissionTokens.Where(a => a.MenuId == menuPermissionTokenEntity.MenuId).ToListAsync().ConfigureAwait(false);



                        foreach (var menuPermissionToken in menuPermissionTokenEntites)
                        {
                            if (existingUserMenuPermissionTokenEntites.FirstOrDefault(a => a.UserId == model.RoleId && a.MenuPermissionTokenId == menuPermissionToken.Id) == null)
                            {
                                newUserMenuPermissionTokenEntities.Add(new TblUserMenuPermissionToken
                                {
                                    Id = Guid.NewGuid(),
                                    UserId = model.RoleId,
                                    MenuPermissionTokenId = menuPermissionToken.Id
                                });
                            }
                        }
                    }
                    else
                    {
                        newUserMenuPermissionTokenEntities.Add(new TblUserMenuPermissionToken
                        {
                            Id = Guid.NewGuid(),
                            UserId = model.RoleId,
                            MenuPermissionTokenId = model.MenuPermissionTokenId,
                        });
                    }


                    try
                    {
                        _context.TblUserMenuPermissionTokens.AddRange(newUserMenuPermissionTokenEntities);
                        await _context.SaveChangesAsync();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        throw;
                    }
                }
            }
            else
            {
                var menuPermissionTokenEntity = await _context.TblUserMenuPermissionTokens.Where(m => m.UserId == model.RoleId && m.MenuPermissionTokenId == model.MenuPermissionTokenId).FirstOrDefaultAsync().ConfigureAwait(true);

                if (menuPermissionTokenEntity == null)
                {
                    return false;
                }
                else
                {
                    try
                    {
                        _context.TblUserMenuPermissionTokens.Remove(menuPermissionTokenEntity);
                        await _context.SaveChangesAsync();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        throw;
                    }
                }
            }

        }




    }
}
