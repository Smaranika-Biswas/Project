﻿
using PeirLoanSystem.Data.Entities;
using PeirLoanSystem.Data.Models;
using PeirLoanSystem.Data.ViewModels;
using Microsoft.EntityFrameworkCore;
using System.Globalization;


namespace Binds.Repositories.Global
{
    #region --- Interface : ICommonRepository ---
    public interface ICommonRepository
    {
        Task<IReadOnlyList<DocumentType>> GetAllDocumentTypeAsync(string Category);
        Task<IReadOnlyList<SubDocumentType>> GetAllSubDocumentTypeAsync(Guid DocumentTypeId);
        Task<IReadOnlyList<State>> GetAllStateAsync();
        Task<IReadOnlyList<District>> GetAllDistrictAsync(Guid id);
    }
    #endregion

    #region --- Class : CommoneeRepository ---
    public class CommonRepository : ICommonRepository
    {
        public readonly PeirloanDataContext _context;

        public CommonRepository(PeirloanDataContext context) => _context = context;

     
        public async Task<IReadOnlyList<DocumentType>> GetAllDocumentTypeAsync(string Category)
        {
            try
            {
                var entities = await _context.TblDocumentTypes.OrderBy(m => m.Name).Where(m => m.IsActive && Category.Trim().ToLower().Equals(m.Category.Trim().ToLower())).ToListAsync();
                return entities.ConvertAll(m => new DocumentType
                {
                    Id = m.Id,
                    Name = m.Name,
                });
            }
            catch (Exception)
            {
                throw;
            }
        }



        public async Task<IReadOnlyList<SubDocumentType>> GetAllSubDocumentTypeAsync(Guid DocumentTypeId)
        {
            try
            {
                var entities = await _context.TblSubDocumentTypes.OrderBy(m => m.Name).Where(m => m.IsActive && m.DocumentTypeId == DocumentTypeId).ToListAsync();
                return entities.ConvertAll(m => new SubDocumentType
                {
                    Id = m.Id,
                    Name = m.Name,
                });
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<IReadOnlyList<State>> GetAllStateAsync()
        {
            try
            {
                var entities = await _context.TblStates.OrderBy(m => m.Name).Where(m => m.IsActive).ToListAsync();
                return entities.ConvertAll(m => new State
                {
                    Id = m.Id,
                    Name = m.Name,
                });
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IReadOnlyList<District>> GetAllDistrictAsync(Guid id)
        {
            try
            {
                var entities = await _context.TblDistricts.Where(m => m.StateId == id).OrderBy(m => m.Name).Where(m => m.IsActive).ToListAsync();
                return entities.ConvertAll(m => new District
                {
                    Id = m.Id,
                    Name = m.Name,
                });
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
    #endregion
}
