﻿using Binds.Repositories.Global;
using PeirLoanSystem.Data.Repositories;



namespace PeirLoanSystem.Data
{
    public interface IUnitOfWork
    {
        IUserRepository Users { get; }
        ILoaneeRepository Loanee { get; }
        ICommonRepository Common { get; }
        ILoanRepository Loan { get; }
        IDashboardRepository Dashboard { get; }
        IEmailService EmailService { get; }
        INotificationRepository Notification { get; }
        IMenuService MenuService { get; }
    }
    public class UnitOfWork : IUnitOfWork
    {
        public UnitOfWork(IMenuService menu, IUserRepository users, ILoaneeRepository loanee, ICommonRepository common, ILoanRepository loan, IDashboardRepository dashboard, IEmailService emailService, INotificationRepository notification)
        {
            Users = users;
            Loanee = loanee;
            Common = common;
            Loan = loan;
            Dashboard = dashboard;
            Notification = notification;
            EmailService = emailService;
            MenuService = menu;
        }

        public IUserRepository Users { get; }
        public ILoaneeRepository Loanee { get; }
        public ICommonRepository Common { get; }
        public ILoanRepository Loan { get; }
        public IDashboardRepository Dashboard { get; }
        public IEmailService EmailService { get; }
        public INotificationRepository Notification { get; }
        public IMenuService MenuService { get; }
    }
}