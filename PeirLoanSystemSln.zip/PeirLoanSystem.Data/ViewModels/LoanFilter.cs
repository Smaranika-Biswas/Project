﻿using PeirLoanSystem.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeirLoanSystem.Data.ViewModels
{

    #region --- Class : LoaneeFilterParam ---
    public class LoanFilterParam : FilterParam
    {
        public Guid? LoaneeId { get; set; }
        public string? Status { get; set; }
    }
    #endregion

    #region --- Class : RequisitionFilterResult ---
    public class LoanFilterResult : FilterResult<Loan>
    {
    }
    #endregion
}
