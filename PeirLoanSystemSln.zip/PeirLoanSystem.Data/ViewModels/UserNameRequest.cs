﻿namespace PeirLoanSystem.Data.ViewModels
{
    public class UserNameRequest
    {
        public string UserName { get; set; } = null!;
    }
}
