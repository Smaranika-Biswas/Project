﻿using PeirLoanSystem.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeirLoanSystem.Data.ViewModels
{

    #region --- Class : UserFilterParam ---
    public class UserFilterParam : FilterParam
    {
        public Guid? RoleId { get; set; }
        public string? FullName { get; set; }
        public int? tokenValidHours { get; set; }
    }
    #endregion

    #region --- Class : RequisitionFilterResult ---
    public class UserFilterResult : FilterResult<User>
    {
    }
    #endregion
}
