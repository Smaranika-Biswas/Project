﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeirLoanSystem.Data.ViewModels
{
    public class FilterParam
    {       
        public string FilterText { get; set; } = null!;
        public string SortOn { get; set; } = null!;
        public string SortDirection { get; set; } = null!;
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public string? RoleAlias { get; set; }
        public string? UserType { get; set; }
        public Guid? MappingId { get; set; }
    }
}
