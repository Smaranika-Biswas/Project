﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeirLoanSystem.Data.ViewModels
{
    public class OtpSessionResponse
    {
        public string FormattedMonile { get; set; } = null!;
        public DateTime OtpExpirationTime { get; set; }
        public int OtpValidTime { get; set; }
    }
}
