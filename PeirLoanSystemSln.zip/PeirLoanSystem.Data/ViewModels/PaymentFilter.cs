﻿using PeirLoanSystem.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeirLoanSystem.Data.ViewModels
{

    #region --- Class : LoaneeFilterParam ---
    public class PaymentFilterParam : FilterParam
    {
        public Guid? LoaneeId { get; set; }
        public Guid? LoanId { get; set; }
    }
    #endregion

    #region --- Class : RequisitionFilterResult ---
    public class PaymentFilterResult : FilterResult<Payment>
    {
    }
    #endregion
}
