﻿using PeirLoanSystem.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeirLoanSystem.Data.ViewModels
{

    public class NotificationFilterParam : FilterParam
    {
        public Guid? UserId { get; set; }
    }
    public class NotificationFilterResult : FilterResult<Notification>
    {
    }
}
