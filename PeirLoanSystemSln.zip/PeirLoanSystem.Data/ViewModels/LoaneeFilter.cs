﻿using PeirLoanSystem.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeirLoanSystem.Data.ViewModels
{

    #region --- Class : LoaneeFilterParam ---
    public class LoaneeFilterParam : FilterParam
    {
        public Guid? DistrictId { get; set; }
        public Guid? StateId { get; set; }
        public string? Category { get; set; }
    }
    #endregion

    #region --- Class : RequisitionFilterResult ---
    public class DistrictFilterResult : FilterResult<Loanee>
    {
    }
    #endregion
}
