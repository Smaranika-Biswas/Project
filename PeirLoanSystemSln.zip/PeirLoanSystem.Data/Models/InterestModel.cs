﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeirLoanSystem.Data.Models
{
    public class InterestModel
    {
        public Guid LoanId { get; set; }
        public DateTime PaymentDate { get; set; }
    }
    public class InterestInfoModel
    {
        public decimal PreviousInterestDue { get; set; }
        public decimal CurrentInterestDue { get; set; }
    }
}
