﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeirLoanSystem.Data.Models
{
    public class Dashboard
    {
        public int CountOfLoanee { get; set; }
        public List<Category> LoaneeCategories { get; set; } = null!;
        public int CountOfLoans { get; set; }
        public List<AmountModel> LoanCategories { get; set; } = null!;
        public decimal TotalLoanAmount { get; set; }
        public List<Category> LoanStatusCategories { get; set; } = null!;
        public decimal PaymentReceived { get; set; }
        public List<AmountModel> PaymentCategories { get; set; } = null!;
        public decimal TotalDueAmount { get; set; }
        public decimal TotalPrincipalDue { get; set; }
        public decimal TotalInterestDue { get; set; }
    }
    public class Category
    {
        public string Name { get; set; } = null!;
        public int Count { get; set; }
    }
    public class AmountModel
    {
        public string Name { get; set; } = null!;
        public decimal Amount { get; set; }
    }
}
