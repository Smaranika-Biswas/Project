﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeirLoanSystem.Data.Models
{
    public class Payment
    {
        public Guid? Id { get; set; }
        public Guid LoanId { get; set; }
        public string? SanctionNo { get; set; }
        public DateOnly? LoanDisbursalDate { get; set; }
        public DateOnly RepaymentDate { get; set; }
        public string? Loanee { get; set; }
        public decimal? LoanAmount { get; set; }
        public decimal PrincipalPaid { get; set; }

        public decimal InterestPaid { get; set; }

        public decimal? TotalPaid { get; set; }

        public decimal? InterestDue { get; set; }
        public string? VendorNote { get; set; }

        public string? FinanceNote { get; set; }

        public DateTime? FinanceNoteDate { get; set; }

        public string? AccountHead { get; set; }

        public string? AuditorNote { get; set; }

        public DateTime? AuditorNoteDate { get; set; }
        public string? ChallanFileNo { get; set; }

        public string? ChallanFileName { get; set; }
        public decimal? InterestDueAsOfNow { get; set; }
        public string? FinanceComment { get; set; }

        public string? AuditorComment { get; set; }
    }
    public class ValidatePayment
    {
        public Guid PaymentId {  get; set; }
        public string Note { get; set; } = null!;
        public string? Comment { get; set; }
    }
    public class ChangeAccountHead
    {
        public Guid PaymentId { get; set; }
        public string? AccountHead { get; set; }
    }
}
