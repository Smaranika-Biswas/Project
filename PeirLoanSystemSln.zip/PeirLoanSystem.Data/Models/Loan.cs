﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeirLoanSystem.Data.Models
{
    public class Loan
    {
        public Guid? Id { get; set; }

        public Guid LoaneeId { get; set; }
        public string? LoaneeName { get; set; }

        public string SanctionNo { get; set; } = null!;

        public decimal LoanAmount { get; set; }

        public decimal InterestRate { get; set; }
        public decimal? InterestDueAsOfNow { get; set; }

        public int LoanTenure { get; set; }

        public int MoratoriumPeriod { get; set; }

        public decimal RebateInterest { get; set; }

        public DateOnly DisbursedDate { get; set; }

        public string AccountHead { get; set; } = null!;

        public List<LoanDocument>? Documents { get; set; }
        public decimal? PrincipalPaidAsOfNow { get; set; }
        public decimal? InterestPaidAsOfNow { get; set; }
        public decimal? OutStandingAsOfNow { get; set; }
        public List<Payment>? Payments { get; set; }
        public bool IsNclt { get; set; }
        public bool IsWaived { get; set; }
        public bool IsClosed { get; set; }
        public string? Status { get; set; }
        public decimal? PrincipalDueAsOfNow { get; set; }
        public decimal? InterestAsOnDate { get; set; }
    }
    public class LoanDocument
    {
        public Guid? Id { get; set; }

        public Guid? LoaneeId { get; set; }

        public Guid DocumentTypeId { get; set; }
        public string? DocumentTypeName { get; set; }

        public Guid? SubDocumentTypeId { get; set; }
        public string? SubDocumentTypeName { get; set; }

        public string? DocFileName { get; set; }

        public string? DocFileSeq { get; set; }
    }
    public class LoanStatusUpdate
    {
        public bool IsWaived { get; set; }
        public bool IsNclt { get; set; }
        public Guid LoanId { get; set; }
    }
}
