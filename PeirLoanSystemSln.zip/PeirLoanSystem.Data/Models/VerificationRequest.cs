﻿using System.ComponentModel.DataAnnotations;

namespace PeirLoanSystem.Data.Models
{
    public class VerificationRequest
    {
        [Required]
        public string VerifyToken { get; set; } = null!;

        [Required]
        public string Otp { get; set; } = null!;
    }

    public class ForgotPasswordResponse
    {       
        public Guid UserId { get; set; }
        public bool Status { get; set; }
    }

}
