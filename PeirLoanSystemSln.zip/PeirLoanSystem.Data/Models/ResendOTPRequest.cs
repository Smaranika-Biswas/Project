﻿using System.ComponentModel.DataAnnotations;
namespace PeirLoanSystem.Data.Models
{
    public class ResendOTPRequest
    {
        [Required]
        public string VerifyToken { get; set; } = null!;
    }
}
