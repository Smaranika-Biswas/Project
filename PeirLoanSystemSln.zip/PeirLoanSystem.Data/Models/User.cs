﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeirLoanSystem.Data.Models
{
    public class User
    {
        public Guid Id { get; set; }

        public string? FirstName { get; set; }

        public string? MiddleName { get; set; }

        public string? LastName { get; set; }

        public string UserName { get; set; } = null!;

        public string? Password { get; set; } = null!;

        public Guid RoleId { get; set; }
        public string? RoleName { get; set; }

        public string? Mobile { get; set; }

        public string? Email { get; set; }

        public bool IsActive { get; set; }

        public string? FullName { get; set; }

        public bool IsLocked { get; set; }
        public bool IsUserLoggedIn { get; set; }

        public int FailedLoginAttemptCount { get; set; }

        public bool? IsUpdateByAdmin { get; set; }

        public Guid? MappingId { get; set; }
    }

    public class UserSession
    {
        public Guid Id { get; set; }

        public Guid UserId { get; set; }

        public string? VerificationMobile { get; set; }

        public decimal? VerificationOtp { get; set; }

        public DateTime? OtpGenerationTime { get; set; }

        public DateTime? OtpExpirationTime { get; set; }

        public string? VerificationToken { get; set; }

        public DateTime? LoginTime { get; set; }

        public DateTime? LogoutTime { get; set; }

        public bool IsOtpVerified { get; set; }
    }
}
