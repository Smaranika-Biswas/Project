﻿using PeirLoanSystem.Data.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeirLoanSystem.Data.Models
{
    public class Menu
    {
        public Guid? Id { get; set; }
        public string Name { get; set; } = null!;
        public string? Icon { get; set; }
        public string? Target { get; set; }
        public bool IsActive { get; set; }
        public int SortPosition { get; set; }
        public Guid? ParentId { get; set; }
        public Guid? SubGroupId { get; set; }
        public Guid? GroupId { get; set; }
        public Guid? CreatedBy { get; set; }
        public DateTime? CreateDate { get; set; }
        public List<Guid> Header { get; set; }
    }

    public class AuthorizedUserMenu
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Icon { get; set; }
        public string TargetPath { get; set; }
        public string? label { get; set; }
    }

    public class MenuFilterParam : FilterParam
    {
        public string? FilterText { get; set; }
    }

    public class MenuPermissionModel
    {
        public Guid RoleId { get; set; }
        public List<string>? Headers { get; set; }
        public List<MenuPermissionTokenModel> Permissions { get; set; }
    }
    public class MenuPermissionTokenModel
    {
        public Guid Id { get; set; }
        public Guid MenuId { get; set; }
        public string MenuName { get; set; }
        public List<PermissionTokenModel> PermissionTokens { get; set; }
    }

    public class PermissionTokenModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public bool IsSelected { get; set; }
        public bool IsDisabled { get; set; }
    }

    public class RoleMenuPermissionModel
    {
        public Guid MenuId { get; set; }
        public List<string>? Headers { get; set; }
        public List<RolePermissionTokenModel> Permissions { get; set; }
    }

    public class RoleUserMenuPermission
    {
        public Guid UserRoleId { get; set; }
        public List<MenuPermission> Menu { get; set; } = null!;
    }

    public class MenuPermission
    {
        public Guid MenuId { get; set; }
        public List<Guid> MenuPermissionTokenIds { get; set; } = null!;
    }

    public class RolePermissionTokenModel
    {
        public Guid Id { get; set; }
        public Guid RoleId { get; set; }
        public string? RoleName { get; set; }
        public List<PermissionTokenModel> PermissionTokens { get; set; }
    }

    public class UserMenuPermissionModel
    {
        public Guid MenuId { get; set; }
        public List<string>? Headers { get; set; }
        public List<UserPermissionToken> Permissions { get; set; }
    }

    public class UserPermissionToken
    {
        public Guid Id { get; set; }
        public Guid UserId { get; set; }
        public string? UserName { get; set; }
        public string? RoleName { get; set; }
        public List<PermissionTokenModel> PermissionTokens { get; set; }
    }

    public class RoleWiseMenuPermissionCheckBox
    {
        public Guid MenuId { get; set; }
        public Guid MenuPermissionTokenId { get; set; }
        public bool IsChecked { get; set; }
        public Guid RoleId { get; set; }
    }
}
