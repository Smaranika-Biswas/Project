﻿namespace PeirLoanSystem.Data.Models
{
    public class LoginResponse
    {
        public string VerifyToken { get; set; } = null!;
    }
}
