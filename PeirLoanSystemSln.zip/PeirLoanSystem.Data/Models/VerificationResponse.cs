﻿namespace PeirLoanSystem.Data.Models
{
    public class VerificationResponse
    {
        public string AuthToken { get; set; } = null!;
    }
}
