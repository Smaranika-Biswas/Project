﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeirLoanSystem.Data.Models
{
    public class AmmoritizationSchedule
    {
        public int Id { get; set; }
        public string PaymentDate { get; set; }
        public decimal OutStandingAmount { get; set; }
        public decimal InterestRate { get; set; }
        public decimal PrincipalAmount { get; set; }
        public decimal InterestAmount { get; set; }
    }
}
