﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeirLoanSystem.Data.Models
{
    public class Loanee
    {
        public Guid? Id { get; set; }

        public string Name { get; set; } = null!;

        public string? AddressLine1 { get; set; }

        public string? AddressLine2 { get; set; }

        public string? AddressLine3 { get; set; }

        public Guid? StateId { get; set; }
        public string? StateName { get; set; }  

        public Guid? DistrictId { get; set; }
        public string? DistrictName { get; set; }

        public string? City { get; set; }

        public string? PinCode { get; set; }

        public string? RegistrationNo { get; set; }

        public string? PanNo { get; set; }

        public int? LoanCount { get; set; } 
        public decimal? LoanAmount { get; set; }
        public string? GstNo { get; set; }
        public string Category { get; set; } = null!;
        public List<LoanDocument>? Documents { get; set; }
        public string? Email { get; set; }
        public string? ContactNo { get; set; }
        public string? Cin { get; set; }

        public string? CompanyStatus { get; set; }

        public decimal? AuthorizedCapital { get; set; }

        public decimal? PaidUpCapital { get; set; }
        public string? BriefDescription { get; set; }
        public bool LoanReflected { get; set; }
        public string? RegisteredOffice { get; set; }

        public string? FactoryAddress { get; set; }
        public List<Director>? Directors { get; set;}
        public decimal? OutStandingAmount { get; set; }
    }

    public class Director
    {
        public Guid? Id { get; set; }

        public string DirectorName { get; set; } = null!;

        public string? Din { get; set; }

        public string? Address { get; set; }

        public string? Mobile { get; set; }

        public string? Email { get; set; }

        public Guid LoaneeId { get; set; }
    }
}
