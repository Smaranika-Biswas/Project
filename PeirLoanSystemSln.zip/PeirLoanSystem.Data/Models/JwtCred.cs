﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeirLoanSystem.Data.ViewModels
{
    public class JwtCred
    {
        public string JwtIssuer { get; set; } = null!;
        public string JwtKey { get; set; } = null!;
    }
}
