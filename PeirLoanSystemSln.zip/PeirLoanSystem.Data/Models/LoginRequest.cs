﻿namespace PeirLoanSystem.Data.Models
{
    public class LoginRequest
    {
        public string UserName { get; set; } = null!;
        public string Password { get; set; } = null!;
        public Guid CaptchaId { get; set; }
        public string Captcha { get; set; } = null!;
    }
}
