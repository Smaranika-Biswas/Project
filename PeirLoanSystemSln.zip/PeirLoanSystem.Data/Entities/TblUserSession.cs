﻿using System;
using System.Collections.Generic;

namespace PeirLoanSystem.Data.Entities;

public partial class TblUserSession
{
    public Guid Id { get; set; }

    public Guid UserId { get; set; }

    public string VerificationMobile { get; set; } = null!;

    public DateTime OtpGenerationTime { get; set; }

    public DateTime OtpExpirationTime { get; set; }

    public string? VerificationToken { get; set; }

    public DateTime? LoginTime { get; set; }

    public DateTime? LogoutTime { get; set; }

    public string? VerificationOtp { get; set; }

    public bool IsOtpVerified { get; set; }

    public string? AuthToken { get; set; }

    public virtual TblUser User { get; set; } = null!;
}
