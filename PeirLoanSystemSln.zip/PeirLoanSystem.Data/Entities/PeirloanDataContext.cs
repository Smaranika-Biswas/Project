﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace PeirLoanSystem.Data.Entities;

public partial class PeirloanDataContext : DbContext
{
    public PeirloanDataContext()
    {
    }

    public PeirloanDataContext(DbContextOptions<PeirloanDataContext> options)
        : base(options)
    {
    }

    public virtual DbSet<TblCaptcha> TblCaptchas { get; set; }

    public virtual DbSet<TblDistrict> TblDistricts { get; set; }

    public virtual DbSet<TblDocumentType> TblDocumentTypes { get; set; }

    public virtual DbSet<TblLoan> TblLoans { get; set; }

    public virtual DbSet<TblLoanee> TblLoanees { get; set; }

    public virtual DbSet<TblLoaneeDirector> TblLoaneeDirectors { get; set; }

    public virtual DbSet<TblLoaneeDocument> TblLoaneeDocuments { get; set; }

    public virtual DbSet<TblMenu> TblMenus { get; set; }

    public virtual DbSet<TblMenuPermissionToken> TblMenuPermissionTokens { get; set; }

    public virtual DbSet<TblNotification> TblNotifications { get; set; }

    public virtual DbSet<TblNotificationUser> TblNotificationUsers { get; set; }

    public virtual DbSet<TblPermissionToken> TblPermissionTokens { get; set; }

    public virtual DbSet<TblRepayment> TblRepayments { get; set; }

    public virtual DbSet<TblRole> TblRoles { get; set; }

    public virtual DbSet<TblRoleMenuPermissionToken> TblRoleMenuPermissionTokens { get; set; }

    public virtual DbSet<TblState> TblStates { get; set; }

    public virtual DbSet<TblSubDocumentType> TblSubDocumentTypes { get; set; }

    public virtual DbSet<TblUser> TblUsers { get; set; }

    public virtual DbSet<TblUserMenuPermissionToken> TblUserMenuPermissionTokens { get; set; }

    public virtual DbSet<TblUserSession> TblUserSessions { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=52.66.204.56;Initial Catalog=PEIRLoanData;User Id=sa;Password=Qb3nt@21!;TrustServerCertificate=true;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<TblCaptcha>(entity =>
        {
            entity.ToTable("TblCaptcha");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.Captcha).HasMaxLength(6);
        });

        modelBuilder.Entity<TblDistrict>(entity =>
        {
            entity.ToTable("TblDistrict");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.Name).HasMaxLength(100);

            entity.HasOne(d => d.State).WithMany(p => p.TblDistricts)
                .HasForeignKey(d => d.StateId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TblDistrict_TblState");
        });

        modelBuilder.Entity<TblDocumentType>(entity =>
        {
            entity.ToTable("TblDocumentType");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.Category).HasMaxLength(100);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
        });

        modelBuilder.Entity<TblLoan>(entity =>
        {
            entity.ToTable("TblLoan");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.AccountHead).HasMaxLength(30);
            entity.Property(e => e.CreatedOn).HasColumnType("datetime");
            entity.Property(e => e.InterestRate).HasColumnType("numeric(9, 2)");
            entity.Property(e => e.IsNclt).HasColumnName("IsNCLT");
            entity.Property(e => e.LastModifiedOn).HasColumnType("datetime");
            entity.Property(e => e.LoanAmount).HasColumnType("numeric(18, 2)");
            entity.Property(e => e.RebateInterest).HasColumnType("numeric(9, 2)");
            entity.Property(e => e.SanctionNo).HasMaxLength(30);

            entity.HasOne(d => d.Loanee).WithMany(p => p.TblLoans)
                .HasForeignKey(d => d.LoaneeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TblLoan_TblLoanee");
        });

        modelBuilder.Entity<TblLoanee>(entity =>
        {
            entity.ToTable("TblLoanee");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.AddressLine1).HasMaxLength(50);
            entity.Property(e => e.AddressLine2).HasMaxLength(50);
            entity.Property(e => e.AddressLine3).HasMaxLength(50);
            entity.Property(e => e.AuthorizedCapital).HasColumnType("numeric(18, 2)");
            entity.Property(e => e.BriefDescription).HasMaxLength(2000);
            entity.Property(e => e.Catgeory).HasMaxLength(10);
            entity.Property(e => e.Cin)
                .HasMaxLength(50)
                .HasColumnName("CIN");
            entity.Property(e => e.City).HasMaxLength(50);
            entity.Property(e => e.CompanyStatus).HasMaxLength(100);
            entity.Property(e => e.ContactNo).HasMaxLength(20);
            entity.Property(e => e.CreatedOn).HasColumnType("datetime");
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.FactoryAddress).HasMaxLength(200);
            entity.Property(e => e.GstNo).HasMaxLength(20);
            entity.Property(e => e.LastModifiedOn).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(50);
            entity.Property(e => e.PaidUpCapital).HasColumnType("numeric(18, 2)");
            entity.Property(e => e.PanNo).HasMaxLength(20);
            entity.Property(e => e.Pincode).HasMaxLength(10);
            entity.Property(e => e.RegisteredOffice).HasMaxLength(200);
            entity.Property(e => e.RegistrationNo).HasMaxLength(30);

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.TblLoaneeCreatedByNavigations)
                .HasForeignKey(d => d.CreatedBy)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TblLoanee_TblUser1");

            entity.HasOne(d => d.District).WithMany(p => p.TblLoanees)
                .HasForeignKey(d => d.DistrictId)
                .HasConstraintName("FK_TblLoanee_TblDistrict");

            entity.HasOne(d => d.LastModifiedByNavigation).WithMany(p => p.TblLoaneeLastModifiedByNavigations)
                .HasForeignKey(d => d.LastModifiedBy)
                .HasConstraintName("FK_TblLoanee_TblUser");

            entity.HasOne(d => d.State).WithMany(p => p.TblLoanees)
                .HasForeignKey(d => d.StateId)
                .HasConstraintName("FK_TblLoanee_TblState");
        });

        modelBuilder.Entity<TblLoaneeDirector>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_Tbl_Loanee_Directors");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.Address).HasMaxLength(200);
            entity.Property(e => e.Din)
                .HasMaxLength(50)
                .HasColumnName("DIN");
            entity.Property(e => e.DirectorName).HasMaxLength(200);
            entity.Property(e => e.Email).HasMaxLength(50);
            entity.Property(e => e.Mobile).HasMaxLength(14);

            entity.HasOne(d => d.Loanee).WithMany(p => p.TblLoaneeDirectors)
                .HasForeignKey(d => d.LoaneeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TblLoaneeDirectors_TblLoanee");
        });

        modelBuilder.Entity<TblLoaneeDocument>(entity =>
        {
            entity.ToTable("TblLoaneeDocument");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.DocFileName).HasMaxLength(150);
            entity.Property(e => e.DocFileSeq).HasMaxLength(200);
            entity.Property(e => e.UploadedOn).HasColumnType("datetime");

            entity.HasOne(d => d.DocumentType).WithMany(p => p.TblLoaneeDocuments)
                .HasForeignKey(d => d.DocumentTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TblLoaneeDocument_TblDocumentType");

            entity.HasOne(d => d.Loan).WithMany(p => p.TblLoaneeDocuments)
                .HasForeignKey(d => d.LoanId)
                .HasConstraintName("FK_TblLoaneeDocument_TblLoan");

            entity.HasOne(d => d.Loanee).WithMany(p => p.TblLoaneeDocuments)
                .HasForeignKey(d => d.LoaneeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TblLoaneeDocument_TblLoanee");

            entity.HasOne(d => d.SubDocumentType).WithMany(p => p.TblLoaneeDocuments)
                .HasForeignKey(d => d.SubDocumentTypeId)
                .HasConstraintName("FK_TblLoaneeDocument_TblSubDocumentType");
        });

        modelBuilder.Entity<TblMenu>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__TblMenu__3214EC07EC7DADD6");

            entity.ToTable("TblMenu");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Icon).HasMaxLength(50);
            entity.Property(e => e.Name).HasMaxLength(50);
            entity.Property(e => e.Position).HasDefaultValue(0);
            entity.Property(e => e.TargetPath)
                .HasMaxLength(50)
                .HasDefaultValue("#");

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.TblMenus)
                .HasForeignKey(d => d.CreatedBy)
                .HasConstraintName("FK_Menu_User");

            entity.HasOne(d => d.ParentMenu).WithMany(p => p.InverseParentMenu)
                .HasForeignKey(d => d.ParentMenuId)
                .HasConstraintName("FK_Menu_Menu");
        });

        modelBuilder.Entity<TblMenuPermissionToken>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__TblMenuP__3214EC073AA7CA28");

            entity.ToTable("TblMenuPermissionToken");

            entity.Property(e => e.Id).ValueGeneratedNever();

            entity.HasOne(d => d.Menu).WithMany(p => p.TblMenuPermissionTokens)
                .HasForeignKey(d => d.MenuId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MenuPermissionToken_Menu");

            entity.HasOne(d => d.PermissionToken).WithMany(p => p.TblMenuPermissionTokens)
                .HasForeignKey(d => d.PermissionTokenId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MenuPermissionToken_PermissionToken");
        });

        modelBuilder.Entity<TblNotification>(entity =>
        {
            entity.ToTable("TblNotification");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.Description).HasMaxLength(500);
            entity.Property(e => e.NotificationDate).HasColumnType("datetime");
            entity.Property(e => e.Subject).HasMaxLength(250);
        });

        modelBuilder.Entity<TblNotificationUser>(entity =>
        {
            entity.ToTable("TblNotificationUser");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.Parameter).HasMaxLength(200);
            entity.Property(e => e.Route).HasMaxLength(100);
            entity.Property(e => e.SeenDate).HasColumnType("datetime");

            entity.HasOne(d => d.Notification).WithMany(p => p.TblNotificationUsers)
                .HasForeignKey(d => d.NotificationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TblNotificationUser_TblNotification");

            entity.HasOne(d => d.User).WithMany(p => p.TblNotificationUsers)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TblNotificationUser_TblUser");
        });

        modelBuilder.Entity<TblPermissionToken>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__TblPermi__3214EC07DD0EAE28");

            entity.ToTable("TblPermissionToken");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.Name).HasMaxLength(50);
        });

        modelBuilder.Entity<TblRepayment>(entity =>
        {
            entity.ToTable("TblRepayment");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.AccountHead).HasMaxLength(100);
            entity.Property(e => e.AuditorComment)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.AuditorNote).HasMaxLength(200);
            entity.Property(e => e.AuditorNoteDate).HasColumnType("datetime");
            entity.Property(e => e.ChallanFileName).HasMaxLength(200);
            entity.Property(e => e.ChallanFileNo).HasMaxLength(100);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.FinanceComment)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.FinanceNote).HasMaxLength(200);
            entity.Property(e => e.FinanceNoteDate).HasColumnType("datetime");
            entity.Property(e => e.InterestDue).HasColumnType("numeric(18, 2)");
            entity.Property(e => e.InterestPaid).HasColumnType("numeric(18, 2)");
            entity.Property(e => e.InterestRate).HasColumnType("numeric(18, 2)");
            entity.Property(e => e.LastModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.PrincipalPaid).HasColumnType("numeric(18, 2)");
            entity.Property(e => e.TotalPaid)
                .HasComputedColumnSql("([PrincipalPaid]+[InterestPaid])", false)
                .HasColumnType("numeric(19, 2)");
            entity.Property(e => e.VendorNote).HasMaxLength(200);

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.TblRepaymentCreatedByNavigations)
                .HasForeignKey(d => d.CreatedBy)
                .HasConstraintName("FK_TblRepayment_TblUser");

            entity.HasOne(d => d.LastModifiedByNavigation).WithMany(p => p.TblRepaymentLastModifiedByNavigations)
                .HasForeignKey(d => d.LastModifiedBy)
                .HasConstraintName("FK_TblRepayment_TblUser1");

            entity.HasOne(d => d.Loan).WithMany(p => p.TblRepayments)
                .HasForeignKey(d => d.LoanId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TblRepayment_TblLoan");
        });

        modelBuilder.Entity<TblRole>(entity =>
        {
            entity.ToTable("TblRole");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.Alias).HasMaxLength(10);
            entity.Property(e => e.Name).HasMaxLength(50);
        });

        modelBuilder.Entity<TblRoleMenuPermissionToken>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__TblRoleM__3214EC07114E9C11");

            entity.ToTable("TblRoleMenuPermissionToken");

            entity.Property(e => e.Id).ValueGeneratedNever();

            entity.HasOne(d => d.MenuPermissionToken).WithMany(p => p.TblRoleMenuPermissionTokens)
                .HasForeignKey(d => d.MenuPermissionTokenId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RoleMenuPermissionToken_MenuPermissionToken");

            entity.HasOne(d => d.Role).WithMany(p => p.TblRoleMenuPermissionTokens)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RoleMenuPermissionToken_Role");
        });

        modelBuilder.Entity<TblState>(entity =>
        {
            entity.ToTable("TblState");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.Name).HasMaxLength(100);
        });

        modelBuilder.Entity<TblSubDocumentType>(entity =>
        {
            entity.ToTable("TblSubDocumentType");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(100);
        });

        modelBuilder.Entity<TblUser>(entity =>
        {
            entity.ToTable("TblUser");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.Email).HasMaxLength(50);
            entity.Property(e => e.FirstName).HasMaxLength(50);
            entity.Property(e => e.FullName)
                .HasMaxLength(152)
                .HasComputedColumnSql("((([FirstName]+' ')+isnull([MiddleName]+' ',''))+[LastName])", false);
            entity.Property(e => e.LastName).HasMaxLength(50);
            entity.Property(e => e.MiddleName).HasMaxLength(50);
            entity.Property(e => e.Mobile).HasMaxLength(20);
            entity.Property(e => e.Password).HasMaxLength(200);
            entity.Property(e => e.UserName).HasMaxLength(50);

            entity.HasOne(d => d.Role).WithMany(p => p.TblUsers)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TblUser_TblRole");
        });

        modelBuilder.Entity<TblUserMenuPermissionToken>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__TblUserM__3214EC07B6284231");

            entity.ToTable("TblUserMenuPermissionToken");

            entity.Property(e => e.Id).ValueGeneratedNever();

            entity.HasOne(d => d.MenuPermissionToken).WithMany(p => p.TblUserMenuPermissionTokens)
                .HasForeignKey(d => d.MenuPermissionTokenId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserMenuPermissionToken_MenuPermissionToken");

            entity.HasOne(d => d.User).WithMany(p => p.TblUserMenuPermissionTokens)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_UserMenuPermissionToken_User");
        });

        modelBuilder.Entity<TblUserSession>(entity =>
        {
            entity.ToTable("TblUserSession");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.AuthToken).HasMaxLength(2000);
            entity.Property(e => e.LoginTime).HasColumnType("datetime");
            entity.Property(e => e.LogoutTime).HasColumnType("datetime");
            entity.Property(e => e.OtpExpirationTime).HasColumnType("datetime");
            entity.Property(e => e.OtpGenerationTime).HasColumnType("datetime");
            entity.Property(e => e.VerificationMobile).HasMaxLength(20);
            entity.Property(e => e.VerificationOtp).HasMaxLength(20);
            entity.Property(e => e.VerificationToken).HasMaxLength(200);

            entity.HasOne(d => d.User).WithMany(p => p.TblUserSessions)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TblUserSession_TblUser");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
