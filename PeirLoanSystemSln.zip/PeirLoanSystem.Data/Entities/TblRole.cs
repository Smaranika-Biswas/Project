﻿using System;
using System.Collections.Generic;

namespace PeirLoanSystem.Data.Entities;

public partial class TblRole
{
    public Guid Id { get; set; }

    public string Name { get; set; } = null!;

    public string Alias { get; set; } = null!;

    public virtual ICollection<TblRoleMenuPermissionToken> TblRoleMenuPermissionTokens { get; set; } = new List<TblRoleMenuPermissionToken>();

    public virtual ICollection<TblUser> TblUsers { get; set; } = new List<TblUser>();
}
