﻿using System;
using System.Collections.Generic;

namespace PeirLoanSystem.Data.Entities;

public partial class TblLoaneeDirector
{
    public Guid Id { get; set; }

    public string DirectorName { get; set; } = null!;

    public string? Din { get; set; }

    public string? Address { get; set; }

    public string? Mobile { get; set; }

    public string? Email { get; set; }

    public Guid LoaneeId { get; set; }

    public virtual TblLoanee Loanee { get; set; } = null!;
}
