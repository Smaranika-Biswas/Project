﻿using System;
using System.Collections.Generic;

namespace PeirLoanSystem.Data.Entities;

public partial class TblRoleMenuPermissionToken
{
    public Guid Id { get; set; }

    public Guid RoleId { get; set; }

    public Guid MenuPermissionTokenId { get; set; }

    public virtual TblMenuPermissionToken MenuPermissionToken { get; set; } = null!;

    public virtual TblRole Role { get; set; } = null!;
}
