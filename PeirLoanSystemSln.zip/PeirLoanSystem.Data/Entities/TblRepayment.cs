﻿using System;
using System.Collections.Generic;

namespace PeirLoanSystem.Data.Entities;

public partial class TblRepayment
{
    public Guid Id { get; set; }

    public Guid LoanId { get; set; }

    public DateOnly RepaymentDate { get; set; }

    public decimal PrincipalPaid { get; set; }

    public decimal InterestPaid { get; set; }

    public decimal? TotalPaid { get; set; }

    public decimal InterestDue { get; set; }

    public string? VendorNote { get; set; }

    public string? FinanceNote { get; set; }

    public DateTime? FinanceNoteDate { get; set; }

    public string? AccountHead { get; set; }

    public string? AuditorNote { get; set; }

    public DateTime? AuditorNoteDate { get; set; }

    public string? ChallanFileNo { get; set; }

    public string? ChallanFileName { get; set; }

    public Guid? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public Guid? LastModifiedBy { get; set; }

    public DateTime? LastModifiedDate { get; set; }

    public string? FinanceComment { get; set; }

    public string? AuditorComment { get; set; }

    public decimal InterestRate { get; set; }

    public virtual TblUser? CreatedByNavigation { get; set; }

    public virtual TblUser? LastModifiedByNavigation { get; set; }

    public virtual TblLoan Loan { get; set; } = null!;
}
