﻿using System;
using System.Collections.Generic;

namespace PeirLoanSystem.Data.Entities;

public partial class TblDocumentType
{
    public Guid Id { get; set; }

    public string Name { get; set; } = null!;

    public bool IsActive { get; set; }

    public Guid? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string Category { get; set; } = null!;

    public virtual ICollection<TblLoaneeDocument> TblLoaneeDocuments { get; set; } = new List<TblLoaneeDocument>();
}
