﻿using System;
using System.Collections.Generic;

namespace PeirLoanSystem.Data.Entities;

public partial class TblUser
{
    public Guid Id { get; set; }

    public string? FirstName { get; set; }

    public string? MiddleName { get; set; }

    public string? LastName { get; set; }

    public string UserName { get; set; } = null!;

    public string Password { get; set; } = null!;

    public Guid RoleId { get; set; }

    public string? Mobile { get; set; }

    public string? Email { get; set; }

    public bool IsActive { get; set; }

    public string? FullName { get; set; }

    public bool IsLocked { get; set; }

    public int FailedLoginAttemptCount { get; set; }

    public bool? IsUpdateByAdmin { get; set; }

    public Guid? MappingId { get; set; }

    public virtual TblRole Role { get; set; } = null!;

    public virtual ICollection<TblLoanee> TblLoaneeCreatedByNavigations { get; set; } = new List<TblLoanee>();

    public virtual ICollection<TblLoanee> TblLoaneeLastModifiedByNavigations { get; set; } = new List<TblLoanee>();

    public virtual ICollection<TblMenu> TblMenus { get; set; } = new List<TblMenu>();

    public virtual ICollection<TblNotificationUser> TblNotificationUsers { get; set; } = new List<TblNotificationUser>();

    public virtual ICollection<TblRepayment> TblRepaymentCreatedByNavigations { get; set; } = new List<TblRepayment>();

    public virtual ICollection<TblRepayment> TblRepaymentLastModifiedByNavigations { get; set; } = new List<TblRepayment>();

    public virtual ICollection<TblUserMenuPermissionToken> TblUserMenuPermissionTokens { get; set; } = new List<TblUserMenuPermissionToken>();

    public virtual ICollection<TblUserSession> TblUserSessions { get; set; } = new List<TblUserSession>();
}
