﻿using System;
using System.Collections.Generic;

namespace PeirLoanSystem.Data.Entities;

public partial class TblLoaneeDocument
{
    public Guid Id { get; set; }

    public Guid LoaneeId { get; set; }

    public string DocFileName { get; set; } = null!;

    public string DocFileSeq { get; set; } = null!;

    public Guid UploadedBy { get; set; }

    public DateTime UploadedOn { get; set; }

    public Guid? LoanId { get; set; }

    public Guid DocumentTypeId { get; set; }

    public Guid? SubDocumentTypeId { get; set; }

    public virtual TblDocumentType DocumentType { get; set; } = null!;

    public virtual TblLoan? Loan { get; set; }

    public virtual TblLoanee Loanee { get; set; } = null!;

    public virtual TblSubDocumentType? SubDocumentType { get; set; }
}
