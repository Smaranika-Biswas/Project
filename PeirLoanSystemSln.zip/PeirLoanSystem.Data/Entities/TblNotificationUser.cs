﻿using System;
using System.Collections.Generic;

namespace PeirLoanSystem.Data.Entities;

public partial class TblNotificationUser
{
    public Guid Id { get; set; }

    public Guid NotificationId { get; set; }

    public Guid UserId { get; set; }

    public bool IsSeen { get; set; }

    public DateTime? SeenDate { get; set; }

    public string? Route { get; set; }

    public string? Parameter { get; set; }

    public virtual TblNotification Notification { get; set; } = null!;

    public virtual TblUser User { get; set; } = null!;
}
