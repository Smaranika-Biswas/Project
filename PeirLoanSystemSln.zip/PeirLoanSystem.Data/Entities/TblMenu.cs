﻿using System;
using System.Collections.Generic;

namespace PeirLoanSystem.Data.Entities;

public partial class TblMenu
{
    public string Name { get; set; } = null!;

    public string? Icon { get; set; }

    public string? TargetPath { get; set; }

    public int? Position { get; set; }

    public bool IsActive { get; set; }

    public Guid Id { get; set; }

    public Guid? ParentMenuId { get; set; }

    public Guid? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public virtual TblUser? CreatedByNavigation { get; set; }

    public virtual ICollection<TblMenu> InverseParentMenu { get; set; } = new List<TblMenu>();

    public virtual TblMenu? ParentMenu { get; set; }

    public virtual ICollection<TblMenuPermissionToken> TblMenuPermissionTokens { get; set; } = new List<TblMenuPermissionToken>();
}
