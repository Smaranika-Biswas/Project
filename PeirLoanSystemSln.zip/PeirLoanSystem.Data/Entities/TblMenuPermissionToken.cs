﻿using System;
using System.Collections.Generic;

namespace PeirLoanSystem.Data.Entities;

public partial class TblMenuPermissionToken
{
    public Guid Id { get; set; }

    public Guid MenuId { get; set; }

    public Guid PermissionTokenId { get; set; }

    public virtual TblMenu Menu { get; set; } = null!;

    public virtual TblPermissionToken PermissionToken { get; set; } = null!;

    public virtual ICollection<TblRoleMenuPermissionToken> TblRoleMenuPermissionTokens { get; set; } = new List<TblRoleMenuPermissionToken>();

    public virtual ICollection<TblUserMenuPermissionToken> TblUserMenuPermissionTokens { get; set; } = new List<TblUserMenuPermissionToken>();
}
