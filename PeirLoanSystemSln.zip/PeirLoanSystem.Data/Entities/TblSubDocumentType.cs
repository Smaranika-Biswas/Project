﻿using System;
using System.Collections.Generic;

namespace PeirLoanSystem.Data.Entities;

public partial class TblSubDocumentType
{
    public Guid Id { get; set; }

    public string Name { get; set; } = null!;

    public bool IsActive { get; set; }

    public Guid? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public Guid DocumentTypeId { get; set; }

    public virtual ICollection<TblLoaneeDocument> TblLoaneeDocuments { get; set; } = new List<TblLoaneeDocument>();
}
