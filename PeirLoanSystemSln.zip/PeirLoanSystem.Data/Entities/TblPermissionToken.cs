﻿using System;
using System.Collections.Generic;

namespace PeirLoanSystem.Data.Entities;

public partial class TblPermissionToken
{
    public string Name { get; set; } = null!;

    public long Seq { get; set; }

    public Guid Id { get; set; }

    public virtual ICollection<TblMenuPermissionToken> TblMenuPermissionTokens { get; set; } = new List<TblMenuPermissionToken>();
}
