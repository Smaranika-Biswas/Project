﻿using System;
using System.Collections.Generic;

namespace PeirLoanSystem.Data.Entities;

public partial class TblLoan
{
    public Guid Id { get; set; }

    public Guid LoaneeId { get; set; }

    public string SanctionNo { get; set; } = null!;

    public decimal LoanAmount { get; set; }

    public decimal InterestRate { get; set; }

    public int LoanTenure { get; set; }

    public int MoratoriumPeriod { get; set; }

    public decimal RebateInterest { get; set; }

    public DateOnly DisbursedDate { get; set; }

    public string AccountHead { get; set; } = null!;

    public Guid CreatedBy { get; set; }

    public DateTime CreatedOn { get; set; }

    public Guid? LastModifiedBy { get; set; }

    public DateTime? LastModifiedOn { get; set; }

    public bool IsClosed { get; set; }

    public bool IsWaived { get; set; }

    public bool IsNclt { get; set; }

    public bool IsDefaulter { get; set; }

    public virtual TblLoanee Loanee { get; set; } = null!;

    public virtual ICollection<TblLoaneeDocument> TblLoaneeDocuments { get; set; } = new List<TblLoaneeDocument>();

    public virtual ICollection<TblRepayment> TblRepayments { get; set; } = new List<TblRepayment>();
}
