﻿using System;
using System.Collections.Generic;

namespace PeirLoanSystem.Data.Entities;

public partial class TblLoanee
{
    public Guid Id { get; set; }

    public string Name { get; set; } = null!;

    public string? AddressLine1 { get; set; }

    public string? AddressLine2 { get; set; }

    public string? AddressLine3 { get; set; }

    public Guid? StateId { get; set; }

    public Guid? DistrictId { get; set; }

    public string? City { get; set; }

    public string? Pincode { get; set; }

    public string? RegistrationNo { get; set; }

    public string? PanNo { get; set; }

    public string? GstNo { get; set; }

    public Guid CreatedBy { get; set; }

    public DateTime CreatedOn { get; set; }

    public Guid? LastModifiedBy { get; set; }

    public DateTime? LastModifiedOn { get; set; }

    public string Catgeory { get; set; } = null!;

    public string? Email { get; set; }

    public string? Cin { get; set; }

    public string? CompanyStatus { get; set; }

    public decimal? AuthorizedCapital { get; set; }

    public decimal? PaidUpCapital { get; set; }

    public string? BriefDescription { get; set; }

    public bool LoanReflected { get; set; }

    public string? RegisteredOffice { get; set; }

    public string? FactoryAddress { get; set; }

    public string? ContactNo { get; set; }

    public virtual TblUser CreatedByNavigation { get; set; } = null!;

    public virtual TblDistrict? District { get; set; }

    public virtual TblUser? LastModifiedByNavigation { get; set; }

    public virtual TblState? State { get; set; }

    public virtual ICollection<TblLoaneeDirector> TblLoaneeDirectors { get; set; } = new List<TblLoaneeDirector>();

    public virtual ICollection<TblLoaneeDocument> TblLoaneeDocuments { get; set; } = new List<TblLoaneeDocument>();

    public virtual ICollection<TblLoan> TblLoans { get; set; } = new List<TblLoan>();
}
