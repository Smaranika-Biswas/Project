﻿using System;
using System.Collections.Generic;

namespace PeirLoanSystem.Data.Entities;

public partial class TblNotification
{
    public Guid Id { get; set; }

    public string Subject { get; set; } = null!;

    public string? Description { get; set; }

    public DateTime NotificationDate { get; set; }

    public bool IsActive { get; set; }

    public virtual ICollection<TblNotificationUser> TblNotificationUsers { get; set; } = new List<TblNotificationUser>();
}
