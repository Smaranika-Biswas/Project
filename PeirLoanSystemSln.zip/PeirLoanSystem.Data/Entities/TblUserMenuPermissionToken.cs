﻿using System;
using System.Collections.Generic;

namespace PeirLoanSystem.Data.Entities;

public partial class TblUserMenuPermissionToken
{
    public Guid Id { get; set; }

    public Guid UserId { get; set; }

    public Guid MenuPermissionTokenId { get; set; }

    public virtual TblMenuPermissionToken MenuPermissionToken { get; set; } = null!;

    public virtual TblUser User { get; set; } = null!;
}
