﻿using System;
using System.Collections.Generic;

namespace PeirLoanSystem.Data.Entities;

public partial class TblCaptcha
{
    public Guid Id { get; set; }

    public string Captcha { get; set; } = null!;
}
