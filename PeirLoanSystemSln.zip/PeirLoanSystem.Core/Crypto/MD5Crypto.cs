﻿using System.Security.Cryptography;
using System.Text;

namespace PeirLoanSystem.Core.Crypto
{
    public static class MD5Crypto
    {
        public static string CreateHash(string plainText)
        {
            byte[] asciiBytes = Encoding.ASCII.GetBytes(plainText);
            byte[] hashedBytes = MD5.Create().ComputeHash(asciiBytes);
            string hashedText = BitConverter.ToString(hashedBytes).Replace("-", "").ToUpper();
            return hashedText;
        }
    }
}
