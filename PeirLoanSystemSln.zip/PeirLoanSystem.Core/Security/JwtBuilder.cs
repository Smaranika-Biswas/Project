﻿using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace PeirLoanSystem.Core.Security
{
    public static class JwtBuilder
    {
        public static string BuildToken(string fullName, string userName, Guid userId, Guid roleId, string roleName, string roleAlias,string jwtIssuer, string jwtKey,int TokenValidHours)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, userName),
                new Claim("FullName", fullName.ToString()),
                new Claim("UserId", userId.ToString()),
                new Claim("RoleId", roleId.ToString()),
                new Claim("RoleName", roleName ?? ""),
                new Claim("RoleAlias", roleAlias ?? ""),
                new Claim("UserName", userName ?? "")

            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: jwtIssuer,
                audience: jwtIssuer,
                claims: claims,
                expires: DateTime.Now.AddHours(TokenValidHours),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
