﻿using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Text;

namespace PeirLoanSystem.Core.Security
{
    public class JwtParser
    {
        public static Guid GetUserId(string token, string jwtIssuer, string jwtKey)
        {
            var key = Encoding.UTF8.GetBytes(jwtKey);
            var handler = new JwtSecurityTokenHandler();
            var validations = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(key),
                ValidateIssuer = true,
                ValidIssuer = jwtIssuer,
                ValidateAudience = true,
                ValidAudience = jwtIssuer
            };
            var claims = handler.ValidateToken(token, validations, out var tokenSecure);
            var userIdClaim = claims.Claims.FirstOrDefault(c => c.Type == "UserId");
            return userIdClaim == null ? Guid.Empty : Guid.Parse(userIdClaim.Value);
        }

        public static Guid GetUserMappingId(string token, string jwtIssuer, string jwtKey)
        {
            var key = Encoding.UTF8.GetBytes(jwtKey);
            var handler = new JwtSecurityTokenHandler();
            var validations = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(key),
                ValidateIssuer = true,
                ValidIssuer = jwtIssuer,
                ValidateAudience = true,
                ValidAudience = jwtIssuer
            };
            var claims = handler.ValidateToken(token, validations, out var tokenSecure);
            var mappingIdClaim = claims.Claims.FirstOrDefault(c => c.Type == "MappingId");
            return mappingIdClaim == null ? Guid.Empty : Guid.Parse(mappingIdClaim.Value);
        }

        public static Guid GetUserRoleId(string token, string jwtIssuer, string jwtKey)
        {
            var key = Encoding.UTF8.GetBytes(jwtKey);
            var handler = new JwtSecurityTokenHandler();
            var validations = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(key),
                ValidateIssuer = true,
                ValidIssuer = jwtIssuer,
                ValidateAudience = true,
                ValidAudience = jwtIssuer
            };
            var claims = handler.ValidateToken(token, validations, out var tokenSecure);
            var roleIdClaim = claims.Claims.FirstOrDefault(c => c.Type == "RoleId");
            return roleIdClaim == null ? Guid.Empty : Guid.Parse(roleIdClaim.Value);
        }

        public static string GetUserType(string token, string jwtIssuer, string jwtKey)
        {
            var key = Encoding.UTF8.GetBytes(jwtKey);
            var handler = new JwtSecurityTokenHandler();
            var validations = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(key),
                ValidateIssuer = true,
                ValidIssuer = jwtIssuer,
                ValidateAudience = true,
                ValidAudience = jwtIssuer
            };
            var claims = handler.ValidateToken(token, validations, out var tokenSecure);
            var userTypeClaim = claims.Claims.FirstOrDefault(c => c.Type == "UserType");
            return userTypeClaim == null ? "" : userTypeClaim.Value;
        }

        public static string GetRoleAlias(string token, string jwtIssuer, string jwtKey)
        {
            var key = Encoding.UTF8.GetBytes(jwtKey);
            var handler = new JwtSecurityTokenHandler();
            var validations = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(key),
                ValidateIssuer = true,
                ValidIssuer = jwtIssuer,
                ValidateAudience = true,
                ValidAudience = jwtIssuer
            };
            var claims = handler.ValidateToken(token, validations, out var tokenSecure);
            var roleAliasClaim = claims.Claims.FirstOrDefault(c => c.Type == "RoleAlias");
            return roleAliasClaim == null ? "" : roleAliasClaim.Value;
        }

        public static string GetUserFullName(string token, string jwtIssuer, string jwtKey)
        {
            var key = Encoding.UTF8.GetBytes(jwtKey);
            var handler = new JwtSecurityTokenHandler();
            var validations = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(key),
                ValidateIssuer = true,
                ValidIssuer = jwtIssuer,
                ValidateAudience = true,
                ValidAudience = jwtIssuer
            };
            var claims = handler.ValidateToken(token, validations, out var tokenSecure);
            var fullNameClaim = claims.Claims.FirstOrDefault(c => c.Type == "FullName");
            return fullNameClaim == null ? "" : fullNameClaim.Value;
        }

        public static string GetUserOrganizationName(string token, string jwtIssuer, string jwtKey)
        {
            var key = Encoding.UTF8.GetBytes(jwtKey);
            var handler = new JwtSecurityTokenHandler();
            var validations = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(key),
                ValidateIssuer = true,
                ValidIssuer = jwtIssuer,
                ValidateAudience = true,
                ValidAudience = jwtIssuer
            };
            var claims = handler.ValidateToken(token, validations, out var tokenSecure);
            var organizationNameClaim = claims.Claims.FirstOrDefault(c => c.Type == "OrganizationName");
            return organizationNameClaim == null ? "" : organizationNameClaim.Value;
        }
    }
}
